# MPF - Mobile Penetration Testing Framework

<div align="center">

```
███╗   ███╗██████╗ ███████╗
████╗ ████║██╔══██╗██╔════╝
██╔████╔██║██████╔╝█████╗  
██║╚██╔╝██║██╔═══╝ ██╔══╝  
██║ ╚═╝ ██║██║     ██║     
╚═╝     ╚═╝╚═╝     ╚═╝     
```

**Advanced Mobile Application Security Testing**

[![Version](https://img.shields.io/badge/version-2.0.0-blue.svg)](https://github.com/your-org/mpf)
[![Platform](https://img.shields.io/badge/platform-Android-green.svg)](https://www.android.com/)
[![License](https://img.shields.io/badge/license-Research-orange.svg)](LICENSE)

[Features](#features) • [Installation](#installation) • [Quick Start](#quick-start) • [Documentation](#documentation) • [Contributing](#contributing)

</div>

---

## Overview

MPF is a **Metasploit-inspired framework** for mobile application penetration testing. Unlike traditional mobile security tools that focus solely on static analysis, MPF provides a comprehensive exploit-payload architecture for app-level security testing.

### Why MPF?

- 🎯 **Exploit-Payload Architecture** - Modular exploitation with customizable payloads
- 🔗 **Attack-Chain Reasoning** - Intelligent vulnerability correlation and exploitation paths
- 🎓 **Educational Focus** - Designed for learning and understanding mobile security
- 🛡️ **Ethical Testing** - Built-in safety features and check-only modes
- 🚀 **Metasploit-Style CLI** - Familiar interface for penetration testers
- 📊 **Comprehensive Reporting** - Detailed JSON reports with impact assessment

---

## Features

### Core Capabilities

#### 1. Exploit Modules
- **Exported ContentProvider Exploitation** - Extract sensitive data from unprotected providers
- **Exported Activity Hijacking** - Access restricted application screens
- **Exported BroadcastReceiver Exploitation** - Trigger unauthorized functionality
- **WebView Remote Code Execution** - Exploit JavaScript bridge vulnerabilities (CVE-2012-6636, CVE-2013-4710)
- **Exported Service Exploitation** - Manipulate background services *(coming soon)*
- **Deeplink Injection** - Exploit deeplink vulnerabilities *(coming soon)*

#### 2. Payload System

**Singles** - Standalone payloads for immediate exploitation:
- Intent Injection
- ContentProvider Query
- Deeplink Trigger
- Data Exfiltration (complete app data extraction)
- Permission Escalation (SMS, Camera, Location, Contacts)

**Stagers** - First-stage payloads for advanced exploitation:
- Frida Injector

**Stages** - Second-stage payloads requiring a stager:
- SSL Unpinning

**Meterpreter** - Interactive app-level shells:
- App Shell (10+ interactive commands)

#### 3. Auxiliary Modules
- Static Analysis (APK decompilation and vulnerability detection)
- Dynamic Analysis (runtime behavior monitoring and crash detection)
- Attack-Chain Analysis (intelligent vulnerability correlation)

#### 4. Advanced Features
- **Automated Exploitation** - One-command full penetration test (`auto` command)
- **Payload Generator** - MSFVenom-style standalone payload generation (`mpf-generate`)
- **Tab Completion** - Smart completion for modules and options
- **Search Filters** - Advanced module search with CVE and severity filtering
- **Check Mode** - Safe vulnerability validation without exploitation

---

## Installation

### Prerequisites

```bash
# Ruby 2.7 or higher
ruby --version

# Android Debug Bridge (ADB)
adb version

# APKTool (for static analysis)
apktool --version

# Optional: Frida (for advanced payloads)
frida --version
```

### Setup

```bash
# Clone repository
git clone https://github.com/your-org/mpf.git
cd mpf

# Install Ruby dependencies
gem install readline json rexml

# Make MPF executable
chmod +x bin/mpf

# Run MPF
./bin/mpf
```

---

## Emulator Integration 🆕

MPF now includes **integrated Android emulator management** for fully self-contained, headless testing!

### Quick Start with Emulator

```bash
# Start MPF
ruby bin/mpf

# List available emulators
mpf > emulator list

# Start QEMU emulator (headless)
mpf > emulator start qemu-api30-x86

# Check status
mpf > emulator status

# Run analysis with managed emulator
mpf > use auxiliary/dynamic_analysis
mpf > set APK target.apk
mpf > set EMULATOR qemu-api30-x86
mpf > run

# Stop emulator
mpf > emulator stop
```

### Benefits

✅ **Self-Contained** - No external emulator setup required  
✅ **Headless Operation** - Perfect for CI/CD and servers  
✅ **Automated Lifecycle** - Start/stop emulators programmatically  
✅ **Snapshot Support** - Save and restore emulator states  
✅ **Multi-Emulator** - Manage multiple configurations  

### Documentation

- **[Emulator Integration Design](EMULATOR_INTEGRATION_DESIGN.md)** - Complete architecture and design
- **[Emulator Quick Start](EMULATOR_README.md)** - Getting started guide
- **[Windows Setup Guide](WINDOWS_EMULATOR_SETUP.md)** - Windows-specific setup instructions
- **[Integration Summary](EMULATOR_INTEGRATION_SUMMARY.md)** - Implementation details

---

## Quick Start

### Automated Analysis (Recommended)

The fastest way to analyze any APK:

```bash
# Verify setup
bash verify_setup.sh

# Run complete analysis on any APK
bash mpf_analyze.sh DivaApplication.apk
bash mpf_analyze.sh /path/to/your/app.apk

# Results will be in: mpf_analysis_<timestamp>/
# - static_analysis.json       (vulnerability findings)
# - generated_payloads.json    (exploitation payloads)
# - REPORT.txt                 (human-readable report)
# - payloads/*.sh              (executable payload scripts)
```

See [TESTING_GUIDE.md](TESTING_GUIDE.md) for detailed instructions.

### Interactive CLI

For manual testing and exploration:

### Example 1: Exploit Exported ContentProvider

```bash
# Start MPF
./bin/mpf

# Load exploit module
mpf > use exploit/android/exported_provider

# Configure target
mpf exported_provider > set TARGET_PACKAGE com.example.vulnerable
mpf exported_provider > set PROVIDER_AUTHORITY com.example.provider

# Select payload
mpf exported_provider > set PAYLOAD payload/android/singles/provider_query

# Check vulnerability
mpf exported_provider > check
[+] Target appears to be VULNERABLE

# Exploit
mpf exported_provider > exploit
[+] Exploitation successful!
[*] Results saved to: reports/exploit/exploit_1234567890.json
```

### Example 2: Interactive App Shell

```bash
# Load meterpreter payload
mpf > use payload/android/meterpreter/app_shell

# Configure target
mpf app_shell > set TARGET_PACKAGE com.example.app
mpf app_shell > set DEVICE emulator-5554

# Execute
mpf app_shell > run

# Interactive shell
app_shell > help
app_shell > list_activities
app_shell > dump_data /data/data/com.example.app
app_shell > screenshot
app_shell > exit
```

### Example 3: SSL Pinning Bypass

```bash
# Step 1: Inject Frida stager
mpf > use payload/android/stagers/frida_injector
mpf frida_injector > set TARGET_PACKAGE com.banking.app
mpf frida_injector > set FRIDA_SCRIPT scripts/base_hook.js
mpf frida_injector > run
[+] Frida injected successfully (PID: 12345)

# Step 2: Deploy SSL unpinning stage
mpf > use payload/android/stages/ssl_unpinning
mpf ssl_unpinning > set STAGER_PID 12345
mpf ssl_unpinning > run
[+] SSL unpinning stage deployed
```

---

## Documentation

### Comprehensive Guides

- **[User Guide](MPF_USER_GUIDE.md)** - Complete usage documentation
- **[Architecture](MPF_V2_ARCHITECTURE.md)** - Technical architecture and design
- **[Module Development](docs/MODULE_DEVELOPMENT.md)** - Creating custom modules *(coming soon)*
- **[Research Paper](docs/RESEARCH.md)** - Academic contributions *(coming soon)*

### Command Reference

```bash
# Core Commands
help                    # Display help menu
use <module>            # Load a module
back                    # Return to main context
exit                    # Exit MPF

# Information
info                    # Show module information
show exploits           # List all exploits
show payloads           # List all payloads
show options            # Display current options
search <term>           # Search modules

# Configuration
set <option> <value>    # Set module option
setg <option> <value>   # Set global option
unset <option>          # Clear option

# Execution
check                   # Check vulnerability
exploit                 # Execute exploit
run                     # Alias for exploit
generate                # Generate payload
```

---

## Architecture

### Module Structure

```
MPF v2.0
├── Core Framework
│   ├── Console (CLI Interface)
│   ├── Module Manager (Dynamic Loading)
│   ├── Exploit Base (Abstract Class)
│   └── Payload Base (Abstract Class)
├── Exploit Modules
│   └── Android
│       ├── Exported Provider
│       └── Exported Activity
├── Payload System
│   ├── Singles (Standalone)
│   ├── Stagers (First Stage)
│   ├── Stages (Second Stage)
│   └── Meterpreter (Interactive)
└── Auxiliary Modules
    └── Static Analysis
```

### Design Philosophy

1. **Separation of Concerns** - Exploits define *what* to exploit, payloads define *how*
2. **Modularity** - Easy to extend with new modules
3. **Analyst-Guided** - Human-in-the-loop decision making
4. **Educational** - Clear explanations and learning-focused
5. **Ethical** - Built-in safety features and responsible disclosure

---

## Comparison with Other Tools

| Feature | MPF | MobSF | Drozer | Objection |
|---------|-----|-------|--------|-----------|
| Exploit Modules | ✓ | ✗ | Limited | ✗ |
| Payload System | ✓ | ✗ | ✗ | Limited |
| Attack Chains | ✓ | ✗ | ✗ | ✗ |
| Interactive Shell | ✓ | ✗ | ✓ | ✓ |
| Static Analysis | ✓ | ✓ | ✗ | ✗ |
| Metasploit-style | ✓ | ✗ | ✗ | ✗ |
| Educational Focus | ✓ | Limited | ✗ | Limited |

---

## Research Contributions

MPF introduces several novel concepts to mobile security testing:

### 1. Exploit-Payload Architecture for Mobile Apps
First framework to implement Metasploit-style separation for mobile application testing.

### 2. Payload Type Classification
Adapted Metasploit payload types (singles, stagers, stages, meterpreter) for mobile app context.

### 3. App-Level Meterpreter
Interactive shell for app-level control (not OS-level), enabling safe exploration.

### 4. Attack-Chain Reasoning
Intelligent correlation of vulnerabilities to construct exploitation paths.

### Academic Publications
- Research paper in preparation for submission to security conferences
- Methodology suitable for IEEE S&P, USENIX Security, ACM CCS

---

## Use Cases

### 1. Penetration Testing
- Authorized security assessments
- Vulnerability validation
- Exploitation proof-of-concept

### 2. Security Research
- Mobile security research
- Vulnerability discovery
- Exploitation technique development

### 3. Education
- Mobile security training
- University courses
- Security certifications

### 4. Bug Bounty
- Vulnerability demonstration
- Impact assessment
- Proof-of-concept development

---

## Roadmap

### Version 2.1 (Q2 2024)
- [ ] Additional exploit modules (Service, Receiver)
- [ ] Enhanced payload generation
- [ ] Session management
- [ ] Workspace support

### Version 2.2 (Q3 2024)
- [ ] iOS support
- [ ] Automated report generation
- [ ] CVE-based module search
- [ ] Integration with vulnerability databases

### Version 3.0 (Q4 2024)
- [ ] Web interface
- [ ] Collaborative testing
- [ ] Cloud integration
- [ ] Machine learning-based vulnerability detection

---

## Contributing

We welcome contributions from the security community!

### How to Contribute

1. **Fork the repository**
2. **Create a feature branch** (`git checkout -b feature/new-exploit`)
3. **Commit your changes** (`git commit -am 'Add new exploit module'`)
4. **Push to the branch** (`git push origin feature/new-exploit`)
5. **Create a Pull Request**

### Contribution Areas

- New exploit modules
- Additional payloads
- Auxiliary modules
- Documentation improvements
- Bug fixes
- Testing and validation

### Module Development

See [Module Development Guide](docs/MODULE_DEVELOPMENT.md) for creating custom modules.

---

## Legal & Ethical Use

### Authorized Use Only

MPF is designed for:
- ✓ Authorized penetration testing
- ✓ Security research with permission
- ✓ Educational purposes
- ✓ Bug bounty programs

MPF must NOT be used for:
- ✗ Unauthorized access to applications
- ✗ Malicious activities
- ✗ Privacy violations
- ✗ Illegal activities

### Responsible Disclosure

- Report vulnerabilities to vendors
- Follow coordinated disclosure timelines
- Provide remediation guidance
- Respect user privacy

---

## License

MPF is released under the **Research License** for academic and educational use.

For commercial use, please contact: security@your-org.com

---

## Support

### Community

- **GitHub Issues**: [Report bugs or request features](https://github.com/your-org/mpf/issues)
- **Discussions**: [Ask questions and share ideas](https://github.com/your-org/mpf/discussions)
- **Email**: security@your-org.com

### Documentation

- [User Guide](MPF_USER_GUIDE.md)
- [Architecture Documentation](MPF_V2_ARCHITECTURE.md)
- [API Reference](docs/API.md) *(coming soon)*

---

## Acknowledgments

MPF is inspired by:
- **Metasploit Framework** - Exploit-payload architecture
- **Drozer** - Mobile security testing concepts
- **Frida** - Runtime instrumentation
- **MobSF** - Static analysis techniques

Special thanks to the mobile security research community.

---

## Citation

If you use MPF in your research, please cite:

```bibtex
@software{mpf2024,
  title = {MPF: Mobile Penetration Testing Framework},
  author = {Your Name},
  year = {2024},
  url = {https://github.com/your-org/mpf},
  version = {2.0.0}
}
```

---

## Authors

- **Your Name** - *Initial work and research* - [GitHub](https://github.com/yourusername)

See also the list of [contributors](https://github.com/your-org/mpf/contributors).

---

<div align="center">

**MPF v2.0 - Advanced Mobile Application Security Testing**

Made with ❤️ for the security community

[⬆ Back to Top](#mpf---mobile-penetration-testing-framework)

</div>
