#!/usr/bin/env bash

set -e

MPF_INSTALL_DIR="/opt/mpf"
LAUNCHER="/usr/local/bin/mpf"

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}"
echo "======================================="
echo "     MPF Installer"
echo " Mobile Penetration Framework"
echo "======================================="
echo -e "${NC}"

if [ "$EUID" -ne 0 ]; then
echo -e "${RED}[!] Please run as root:${NC}"
echo "sudo ./install.sh"
exit 1
fi

echo -e "${GREEN}[+] Updating package lists...${NC}"
apt-get update

install_if_missing() {
local cmd=$1
local pkg=$2

```
if ! command -v "$cmd" >/dev/null 2>&1; then
    echo -e "${YELLOW}[!] Installing $pkg...${NC}"
    apt-get install -y "$pkg"
else
    echo -e "${GREEN}[+] $pkg already installed${NC}"
fi
```

}

install_if_missing git git
install_if_missing ruby ruby-full
install_if_missing java default-jdk
install_if_missing adb adb
install_if_missing apktool apktool

echo -e "${GREEN}[+] Installing Bundler...${NC}"

if ! command -v bundler >/dev/null 2>&1; then
gem install bundler
fi

echo -e "${GREEN}[+] Creating installation directory...${NC}"

mkdir -p "$MPF_INSTALL_DIR"

echo -e "${GREEN}[+] Copying framework files...${NC}"

cp -r . "$MPF_INSTALL_DIR"

mkdir -p "$MPF_INSTALL_DIR/reports"
mkdir -p "$MPF_INSTALL_DIR/workspace"
mkdir -p "$MPF_INSTALL_DIR/logs"

if [ -f "$MPF_INSTALL_DIR/Gemfile" ]; then
echo -e "${GREEN}[+] Installing Ruby dependencies...${NC}"
cd "$MPF_INSTALL_DIR"
bundle install
fi

echo -e "${GREEN}[+] Creating global launcher...${NC}"

cat > "$LAUNCHER" << EOF
#!/usr/bin/env bash
cd $MPF_INSTALL_DIR
ruby $MPF_INSTALL_DIR/bin/mpf "$@"
EOF

chmod +x "$LAUNCHER"

echo -e "${GREEN}[+] Running installation validation...${NC}"

echo "---------------------------------------"
echo "Ruby:"
ruby --version || true

echo
echo "Java:"
java -version || true

echo
echo "APKTool:"
apktool --version || true

echo
echo "ADB:"
adb version || true
echo "---------------------------------------"

echo -e "${GREEN}[+] Testing MPF launcher...${NC}"

if mpf help >/dev/null 2>&1; then
echo -e "${GREEN}[+] MPF launcher validated successfully${NC}"
else
echo -e "${YELLOW}[!] MPF installed but self-test returned warnings${NC}"
fi

echo
echo -e "${GREEN}=======================================${NC}"
echo -e "${GREEN} MPF Installation Complete${NC}"
echo -e "${GREEN}=======================================${NC}"

echo
echo "Run MPF from anywhere using:"
echo
echo "    mpf"
echo
echo "Examples:"
echo
echo "    mpf help"
echo "    mpf show modules"
echo "    mpf use auxiliary/intel_analysis"
echo
