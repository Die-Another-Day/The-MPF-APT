require 'json'

module MPF
  class AttackChainEngine
    def initialize
      @findings = []
      @attack_paths = []
      @risk_matrix = {}
    end

    # Core innovation: Build logical attack chains from static findings
    def analyze_attack_surface(static_findings)
      @findings = static_findings
      
      # Step 1: Categorize findings by attack vector
      vectors = categorize_vectors(@findings)
      
      # Step 2: Build attack chains using logical reasoning
      @attack_paths = build_attack_chains(vectors)
      
      # Step 3: Calculate exploitability scores
      @risk_matrix = calculate_risk_matrix(@attack_paths)
      
      {
        attack_surface: vectors,
        attack_chains: @attack_paths,
        risk_assessment: @risk_matrix,
        recommended_tests: generate_test_recommendations()
      }
    end

    private

    def categorize_vectors(findings)
      vectors = {
        entry_points: [],
        privilege_escalation: [],
        data_exposure: [],
        configuration_weaknesses: []
      }

      findings.each do |finding|
        case finding['id']
        when /exported_/
          vectors[:entry_points] << {
            type: 'component_exposure',
            component: finding['component'],
            severity: finding['severity'],
            exploitability: assess_component_exploitability(finding)
          }
        when 'debuggable_enabled'
          vectors[:privilege_escalation] << {
            type: 'debug_access',
            impact: 'runtime_manipulation',
            exploitability: 'high'
          }
        when 'allow_backup_enabled'
          vectors[:data_exposure] << {
            type: 'backup_extraction',
            impact: 'data_theft',
            exploitability: 'medium'
          }
        when 'hardcoded_secret'
          vectors[:data_exposure] << {
            type: 'credential_exposure',
            file: finding['file'],
            exploitability: 'high'
          }
        end
      end

      vectors
    end

    def build_attack_chains(vectors)
      chains = []

      # Chain 1: Entry Point → Privilege Escalation
      if vectors[:entry_points].any? && vectors[:privilege_escalation].any?
        chains << {
          id: 'entry_to_privilege',
          steps: [
            'Exploit exported component for initial access',
            'Leverage debuggable flag for privilege escalation',
            'Execute arbitrary code with app privileges'
          ],
          risk_score: calculate_chain_risk(['high', 'high']),
          feasibility: 'high'
        }
      end

      # Chain 2: Entry Point → Data Exposure
      if vectors[:entry_points].any? && vectors[:data_exposure].any?
        chains << {
          id: 'entry_to_data',
          steps: [
            'Access exported component without authentication',
            'Extract sensitive data or credentials',
            'Escalate to broader system compromise'
          ],
          risk_score: calculate_chain_risk(['high', 'medium']),
          feasibility: 'medium'
        }
      end

      # Chain 3: Configuration Weakness Exploitation
      if vectors[:data_exposure].length > 1
        chains << {
          id: 'config_weakness_chain',
          steps: [
            'Extract hardcoded credentials from APK',
            'Use backup extraction to access app data',
            'Combine data sources for complete profile'
          ],
          risk_score: calculate_chain_risk(['high', 'medium']),
          feasibility: 'high'
        }
      end

      chains
    end

    def calculate_chain_risk(severities)
      risk_values = { 'low' => 1, 'medium' => 2, 'high' => 3 }
      total = severities.sum { |s| risk_values[s] || 0 }
      
      case total
      when 0..2 then 'low'
      when 3..4 then 'medium'
      else 'high'
      end
    end

    def assess_component_exploitability(finding)
      # Research contribution: Smart exploitability assessment
      component_type = finding['id'].split('_').last
      
      case component_type
      when 'activity'
        'high' # Activities are easily exploitable via intents
      when 'provider'
        'high' # Content providers often expose sensitive data
      when 'service'
        'medium' # Services require more sophisticated exploitation
      when 'receiver'
        'medium' # Broadcast receivers have limited attack surface
      else
        'low'
      end
    end

    def calculate_risk_matrix(attack_paths)
      {
        total_paths: attack_paths.length,
        high_risk_paths: attack_paths.count { |p| p[:risk_score] == 'high' },
        exploitable_chains: attack_paths.count { |p| p[:feasibility] == 'high' },
        overall_risk: determine_overall_risk(attack_paths)
      }
    end

    def determine_overall_risk(paths)
      return 'low' if paths.empty?
      
      high_risk_count = paths.count { |p| p[:risk_score] == 'high' }
      
      if high_risk_count > 0
        'critical'
      elsif paths.any? { |p| p[:risk_score] == 'medium' }
        'high'
      else
        'medium'
      end
    end

    def generate_test_recommendations
      recommendations = []

      @attack_paths.each do |path|
        case path[:id]
        when 'entry_to_privilege'
          recommendations << {
            module: 'exploit/exported_component_hijack',
            priority: 'high',
            rationale: 'High-impact attack chain identified'
          }
        when 'entry_to_data'
          recommendations << {
            module: 'auxiliary/data_extraction_test',
            priority: 'medium',
            rationale: 'Data exposure risk detected'
          }
        when 'config_weakness_chain'
          recommendations << {
            module: 'auxiliary/credential_validation',
            priority: 'high',
            rationale: 'Multiple configuration weaknesses found'
          }
        end
      end

      recommendations
    end
  end
end