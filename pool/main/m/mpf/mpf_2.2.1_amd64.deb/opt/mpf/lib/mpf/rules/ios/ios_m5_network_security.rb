require_relative '../../analysis/rules/base_rule'
require 'pathname'

module MPF
  module Analysis
    module Rules
      class IOSM5NetworkSecurityRule < BaseRule
        def initialize
          super(
            id: 'IOS-M5-NETWORK-SECURITY',
            name: 'iOS Network Security / Insecure Communication',
            owasp_category: 'M5',
            severity: :high,
            description: 'Validates App Transport Security (ATS) options in Info.plist and audits cleartext HTTP endpoints in source code.',
            remediation: 'Keep ATS enabled globally. Do not set NSAllowsArbitraryLoads to true. Migrate all endpoints to HTTPS.',
            detection_logic: ->(context) { detect(context) }
          )
        end

        def detect(context)
          findings = []
          info_plist = context[:info_plist] || {}
          decoded_dir = context[:decoded_dir]

          # 1. Info.plist ATS Auditing
          ats = info_plist['NSAppTransportSecurity']
          if ats.is_a?(Hash)
            # Global Bypass
            if ats['NSAllowsArbitraryLoads'] == true
              findings << {
                id: "ios_ats_disabled",
                owasp: 'M5',
                severity: :high,
                description: "App Transport Security (ATS) is globally disabled via NSAllowsArbitraryLoads=true",
                component: "Info.plist",
                evidence: "NSAllowsArbitraryLoads: true",
                confidence: 100
              }
            end

            # Media / WebContent Bypass
            if ats['NSAllowsArbitraryLoadsForMedia'] == true
              findings << {
                id: "ios_ats_media_disabled",
                owasp: 'M5',
                severity: :medium,
                description: "ATS is bypassed for media loading (NSAllowsArbitraryLoadsForMedia=true)",
                component: "Info.plist",
                evidence: "NSAllowsArbitraryLoadsForMedia: true",
                confidence: 95
              }
            end

            if ats['NSAllowsArbitraryLoadsInWebContent'] == true
              findings << {
                id: "ios_ats_webcontent_disabled",
                owasp: 'M5',
                severity: :medium,
                description: "ATS is bypassed for WebViews (NSAllowsArbitraryLoadsInWebContent=true)",
                component: "Info.plist",
                evidence: "NSAllowsArbitraryLoadsInWebContent: true",
                confidence: 95
              }
            end

            # Domain Exceptions
            exception_domains = ats['NSExceptionDomains']
            if exception_domains.is_a?(Hash)
              exception_domains.each do |domain, config|
                next unless config.is_a?(Hash)
                if config['NSExceptionAllowsInsecureHTTPLoads'] == true
                  findings << {
                    id: "ios_ats_exception_allows_insecure_http",
                    owasp: 'M5',
                    severity: :high,
                    description: "ATS domain exception allows cleartext HTTP for domain: #{domain}",
                    component: "Info.plist",
                    evidence: "#{domain} -> NSExceptionAllowsInsecureHTTPLoads: true",
                    confidence: 100
                  }
                end

                min_tls = config['NSExceptionMinimumTLSVersion']
                if min_tls && ['TLSv1.0', 'TLSv1.1'].include?(min_tls)
                  findings << {
                    id: "ios_ats_exception_minimum_tls_version",
                    owasp: 'M5',
                    severity: :medium,
                    description: "ATS exception allows outdated TLS version (#{min_tls}) for domain: #{domain}",
                    component: "Info.plist",
                    evidence: "#{domain} -> NSExceptionMinimumTLSVersion: #{min_tls}",
                    confidence: 100
                  }
                end
              end
            end
          end

          # 2. Source Code Scan for HTTP Endpoint References
          if decoded_dir
            Dir.glob("#{decoded_dir}/**/*.{swift,m,h,json,txt}") do |file|
              next if File.directory?(file)
              content = BaseRule.safe_read(file)
              next if content.empty?

              # Search for http:// URLs (exclude localhost/127.0.0.1 and common namespaces/schemas)
              http_urls = content.scan(/http:\/\/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,}(?:\/[^\s"']*)?/)
              http_urls.each do |url|
                next if url.include?('localhost') || url.include?('127.0.0.1') || url.include?('w3.org') || url.include?('apple.com')
                relative_path = Pathname.new(file).relative_path_from(Pathname.new(decoded_dir)).to_s
                findings << {
                  id: "ios_http_url_usage",
                  owasp: 'M5',
                  severity: :medium,
                  description: "Insecure cleartext HTTP URL detected in code: #{url}",
                  component: relative_path,
                  evidence: url,
                  confidence: 80
                }
              end
            end
          end

          findings
        end
      end
    end
  end
end
