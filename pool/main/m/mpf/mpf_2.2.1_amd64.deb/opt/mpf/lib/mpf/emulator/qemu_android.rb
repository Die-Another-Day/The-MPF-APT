# frozen_string_literal: true

require_relative 'emulator_base'

module MPF
  module Emulator
    ##
    # QEMU-based Android emulator provider
    # Uses Android SDK emulator with QEMU backend
    ##
    class QemuAndroid < EmulatorBase
      attr_reader :avd_name, :emulator_port

      def initialize(name, config = {})
        super(name, config)
        @avd_name = config[:avd_name] || "mpf_#{name}"
        @emulator_port = config[:port] || find_available_port
        @emulator_process = nil
        @sdk_path = find_android_sdk
      end

      ##
      # Start QEMU Android emulator
      ##
      def start
        return { success: false, message: "Emulator already running" } if running?
        
        # Validate SDK and binaries
        unless @sdk_path
          return { 
            success: false, 
            message: "Android SDK not configured. Set ANDROID_SDK_ROOT environment variable to your SDK path (e.g., C:\\Users\\#{ENV['USERNAME']}\\AppData\\Local\\Android\\Sdk)"
          }
        end

        emulator_bin = emulator_binary
        unless emulator_bin
          return { 
            success: false, 
            message: "Emulator binary not found at: #{File.join(@sdk_path, 'emulator', windows? ? 'emulator.exe' : 'emulator')}"
          }
        end

        @state = STATE_STARTING

        # Check if AVD exists (do not create automatically)
        unless avd_exists?
          return { 
            success: false, 
            message: "AVD '#{@avd_name}' not found. Create it using Android Studio Device Manager or run: emulator -list-avds to see available AVDs"
          }
        end

        # Build emulator command
        emulator_cmd = build_emulator_command

        # Start emulator process
        @start_time = Time.now
        @emulator_process = spawn_emulator(emulator_cmd)

        if @emulator_process
          @state = STATE_BOOTING
          @adb_device_id = "emulator-#{@emulator_port}"

          # Wait for boot
          if wait_for_boot(@config[:boot_timeout])
            @state = STATE_READY
            { success: true, message: "Emulator started successfully", adb_device_id: @adb_device_id }
          else
            stop
            @state = STATE_ERROR
            { success: false, message: "Emulator failed to boot within timeout" }
          end
        else
          @state = STATE_ERROR
          { success: false, message: "Failed to start emulator process" }
        end
      end


      ##
      # Stop QEMU Android emulator
      ##
      def stop
        return { success: true, message: "Emulator not running" } unless running?

        @state = STATE_STOPPING

        # Try graceful shutdown via ADB
        if @adb_device_id && adb_binary
          adb_cmd = windows? ? "\"#{adb_binary}\" -s #{@adb_device_id} emu kill" : "#{adb_binary} -s #{@adb_device_id} emu kill"
          execute_command(adb_cmd, 10)
        end

        # Wait for process to terminate
        sleep 2

        # Force kill if still running
        if @emulator_process && process_running?(@emulator_process)
          begin
            Process.kill('TERM', @emulator_process)
            sleep 1
            Process.kill('KILL', @emulator_process) if process_running?(@emulator_process)
          rescue Errno::ESRCH, Errno::EINVAL
            # Process already dead or invalid
          end
        end

        @state = STATE_STOPPED
        @adb_device_id = nil
        @emulator_process = nil

        { success: true, message: "Emulator stopped successfully" }
      end

      ##
      # Create snapshot of emulator state
      ##
      def snapshot(snapshot_name)
        return { success: false, message: "Emulator not running" } unless running?
        return { success: false, message: "ADB not available" } unless adb_binary

        adb_cmd = windows? ? "\"#{adb_binary}\" -s #{@adb_device_id} emu avd snapshot save #{snapshot_name}" : "#{adb_binary} -s #{@adb_device_id} emu avd snapshot save #{snapshot_name}"
        result = execute_command(adb_cmd, 30)
        
        if result[:success]
          { success: true, message: "Snapshot '#{snapshot_name}' created successfully" }
        else
          { success: false, message: "Failed to create snapshot: #{result[:error]}" }
        end
      end

      ##
      # Restore from snapshot
      ##
      def restore(snapshot_name)
        # Stop current instance
        stop if running?

        # Start with snapshot
        @config[:snapshot] = snapshot_name
        start
      end

      ##
      # Wait for emulator to fully boot
      ##
      def wait_for_boot(timeout = 120)
        return false unless @adb_device_id
        return false unless adb_binary

        start_time = Time.now
        boot_completed = false

        while (Time.now - start_time) < timeout
          # Check if ADB can connect
          adb_cmd = windows? ? "\"#{adb_binary}\" -s #{@adb_device_id} shell getprop sys.boot_completed" : "#{adb_binary} -s #{@adb_device_id} shell getprop sys.boot_completed"
          result = execute_command(adb_cmd, 5)
          
          if result[:success] && result[:output].strip == "1"
            boot_completed = true
            break
          end

          sleep 2
        end

        boot_completed
      end

      private

      ##
      # Find Android SDK installation
      ##
      def find_android_sdk
        # Check environment variables
        sdk_root = ENV['ANDROID_SDK_ROOT'] || ENV['ANDROID_HOME']
        
        if sdk_root && Dir.exist?(sdk_root)
          return sdk_root
        end

        # Check common locations
        common_paths = [
          File.expand_path('~/Android/Sdk'),
          File.expand_path('~/Library/Android/sdk'),
          '/usr/local/android-sdk',
          'C:/Users/' + ENV['USERNAME'].to_s + '/AppData/Local/Android/Sdk'
        ]

        common_paths.find { |path| Dir.exist?(path) }
      end

      ##
      # Check if AVD exists
      ##
      def avd_exists?
        emulator_bin = emulator_binary
        return false unless emulator_bin
        
        # Use proper quoting for Windows paths
        cmd = windows? ? "\"#{emulator_bin}\" -list-avds" : "#{emulator_bin} -list-avds"
        result = execute_command(cmd, 10)
        result[:success] && result[:output].include?(@avd_name)
      end

      ##
      ##
      # Build emulator command
      ##
      def build_emulator_command
        emulator_bin = emulator_binary
        
        # Build command with proper quoting for Windows
        cmd_parts = []
        
        if windows?
          cmd_parts << "\"#{emulator_bin}\""
        else
          cmd_parts << emulator_bin
        end
        
        cmd_parts << "-avd #{@avd_name}"
        cmd_parts << "-port #{@emulator_port}"
        cmd_parts << "-no-window" if @config[:headless]
        cmd_parts << "-no-audio"
        cmd_parts << "-no-boot-anim"
        cmd_parts << "-memory #{@config[:memory]}"
        cmd_parts << "-gpu off" if @config[:headless]
        cmd_parts << "-snapshot #{@config[:snapshot]}" if @config[:snapshot]
        cmd_parts << "-wipe-data" if @config[:wipe_data]

        cmd_parts.join(' ')
      end

      ##
      # Get emulator binary path
      ##
      def emulator_binary
        return nil unless @sdk_path
        
        # Determine binary name based on platform
        binary_name = windows? ? 'emulator.exe' : 'emulator'
        binary_path = File.join(@sdk_path, 'emulator', binary_name)
        
        # Verify binary exists
        File.exist?(binary_path) ? binary_path : nil
      end

      ##
      # Get ADB binary path
      ##
      def adb_binary
        return nil unless @sdk_path
        
        # Determine binary name based on platform
        binary_name = windows? ? 'adb.exe' : 'adb'
        binary_path = File.join(@sdk_path, 'platform-tools', binary_name)
        
        # Verify binary exists
        File.exist?(binary_path) ? binary_path : nil
      end

      ##
      # Get AVD manager binary path
      ##
      def avdmanager_binary
        return nil unless @sdk_path
        
        # Determine binary name based on platform
        binary_name = windows? ? 'avdmanager.bat' : 'avdmanager'
        binary_path = File.join(@sdk_path, 'cmdline-tools', 'latest', 'bin', binary_name)
        
        # Verify binary exists
        File.exist?(binary_path) ? binary_path : nil
      end

      ##
      # Check if running on Windows
      ##
      def windows?
        RUBY_PLATFORM =~ /mswin|mingw|cygwin/
      end

      ##
      # List available AVDs
      ##
      def list_available_avds
        emulator_bin = emulator_binary
        return [] unless emulator_bin
        
        cmd = windows? ? "\"#{emulator_bin}\" -list-avds" : "#{emulator_bin} -list-avds"
        result = execute_command(cmd, 10)
        
        if result[:success]
          result[:output].split("\n").map(&:strip).reject(&:empty?)
        else
          []
        end
      end

      ##
      # Spawn emulator process
      ##
      def spawn_emulator(command)
        # On Windows, we need to handle the command differently
        if windows?
          # Use system spawn with proper shell handling
          pid = Process.spawn(command, out: 'NUL', err: 'NUL')
        else
          pid = Process.spawn(command, out: '/dev/null', err: '/dev/null')
        end
        
        Process.detach(pid)
        pid
      rescue => e
        puts "Failed to spawn emulator: #{e.message}"
        nil
      end

      ##
      # Check if process is running
      ##
      def process_running?(pid)
        Process.getpgid(pid)
        true
      rescue Errno::ESRCH
        false
      end

      ##
      # Find available port for emulator
      ##
      def find_available_port
        (5554..5584).step(2).find do |port|
          !port_in_use?(port)
        end || 5554
      end

      ##
      # Check if port is in use
      ##
      def port_in_use?(port)
        adb_bin = adb_binary
        return false unless adb_bin
        
        cmd = windows? ? "\"#{adb_bin}\" devices" : "#{adb_bin} devices"
        result = execute_command(cmd, 5)
        result[:success] && result[:output].include?("emulator-#{port}")
      end
    end
  end
end
