# Android Rules (moved to rules/android/)
require_relative '../../rules/android/m1_secrets'
require_relative '../../rules/android/m3_exported_components'
require_relative '../../rules/android/m4_input_validation'
require_relative '../../rules/android/m5_network_security'
require_relative '../../rules/android/m6_privacy'
require_relative '../../rules/android/m7_binary_protection'
require_relative '../../rules/android/m9_insecure_storage'
require_relative '../../rules/android/m10_cryptography'

# iOS Rules (rules/ios/)
require_relative '../../rules/ios/ios_m1_insecure_architecture'
require_relative '../../rules/ios/ios_m2_insecure_storage'
require_relative '../../rules/ios/ios_m3_weak_crypto'
require_relative '../../rules/ios/ios_m4_authentication'
require_relative '../../rules/ios/ios_m5_network_security'
require_relative '../../rules/ios/ios_m6_privacy'
require_relative '../../rules/ios/ios_m7_binary_protection'
require_relative '../../rules/ios/ios_m8_runtime_integrity'
require_relative '../../rules/ios/ios_m9_reverse_engineering'
require_relative '../../rules/ios/ios_m10_logging'

module MPF
  module Analysis
    module Rules
      class RuleRegistry
        def initialize
          @rules = []
          load_defaults
        end

        def register(rule)
          @rules << rule
        end

        def get_rules_by_category(category)
          @rules.select { |r| r.owasp_category == category }
        end

        def all_rules
          @rules
        end

        def load_defaults
          # Android rules registration
          register(M1SecretsRule.new)
          register(M3ExportedComponentsRule.new)
          register(M4InputValidationRule.new)
          register(M5NetworkSecurityRule.new)
          register(M6PrivacyRule.new)
          register(M7BinaryProtectionRule.new)
          register(M9InsecureStorageRule.new)
          register(M10CryptographyRule.new)

          # iOS rules registration
          register(IOSM1InsecureArchitectureRule.new)
          register(IOSM2InsecureStorageRule.new)
          register(IOSM3WeakCryptoRule.new)
          register(IOSM4AuthenticationRule.new)
          register(IOSM5NetworkSecurityRule.new)
          register(IOSM6PrivacyRule.new)
          register(IOSM7BinaryProtectionRule.new)
          register(IOSM8RuntimeIntegrityRule.new)
          register(IOSM9ReverseEngineeringRule.new)
          register(IOSM10LoggingRule.new)
        end
      end
    end
  end
end
