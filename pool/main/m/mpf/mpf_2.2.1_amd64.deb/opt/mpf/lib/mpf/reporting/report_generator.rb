require 'json'
require 'time'

module MPF
  module Reporting
    class ReportGenerator
      def self.generate_owasp_text_report(report)
        output = []
        output << "\n" + "=" * 60
        output << "OWASP MOBILE SECURITY ASSESSMENT REPORT"
        output << "=" * 60
        output << "Generated: #{Time.now.strftime('%Y-%m-%d %H:%M:%S %Z')}"
        output << "Overall Compliance Score: #{report[:compliance_score]}/100"

        risk_level = case (report[:compliance_score] || 0)
                     when 0..30
                       'CRITICAL'
                     when 31..60
                       'HIGH'
                     when 61..80
                       'MEDIUM'
                     else
                       'ACCEPTABLE'
                     end

        output << "Risk Level: #{risk_level}"
        output << "=" * 60

        output << "\nExecutive Summary"
        output << "-" * 60
        output << "Critical Risks:         #{report[:critical_risks] || 0}"
        output << "High Risks:             #{report[:high_risks] || 0}"
        output << "Medium Risks:           #{report[:medium_risks] || 0}"
        output << "Low Risks:              #{report[:low_risks] || 0}"
        output << "Categories Affected:    #{report[:categories_affected] || 0}/#{report[:total_categories] || 10}"

        output << "\nDetailed Findings by OWASP Category"
        output << "-" * 60

        (report[:details] || {}).each do |id, detail|
          next if detail[:risk] == "NONE"

          output << "\n[#{id}] #{detail[:name]}"
          output << "Risk Level: #{detail[:risk]}"
          output << "Findings Identified: #{(detail[:findings] || []).size}"

          (detail[:findings] || []).each do |f|
            output << "  • [#{(f['severity'] || 'UNKNOWN').upcase}] #{f['description']}"
            output << "    Component: #{f['component'] || 'N/A'}"
            output << "    Rule ID: #{f['rule_id'] || 'N/A'}"
            output << "    OWASP: #{f['owasp_category'] || 'N/A'}"
            output << "    Confidence: #{f['confidence'] || 'N/A'}%"
            if f['evidence']
              evidence_text = f['evidence'].is_a?(Array) ? f['evidence'].first.to_s : f['evidence'].to_s
              output << "    Evidence: #{evidence_text[0, 120]}"
            end
          end
        end

        output << "\n" + "=" * 60
        output << "Remediation Priority"
        output << "=" * 60
        output << "1. Address #{report[:critical_risks] || 0} critical vulnerabilities immediately"
        output << "2. Schedule remediation for #{report[:high_risks] || 0} high-risk issues"
        output << "3. Plan medium-risk fixes within next release cycle"
        output << "=" * 60 + "\n"

        output.join("\n")
      end

      def self.generate_enriched_report(json_path)
        return { success: false, error: 'File not found' } unless File.exist?(json_path)

        begin
          report = JSON.parse(File.read(json_path))
          summary = build_summary(report)
          { success: true, data: summary }
        rescue JSON::ParserError => e
          { success: false, error: "Invalid JSON: #{e.message}" }
        rescue => e
          { success: false, error: e.message }
        end
      end

      def self.build_summary(report)
        findings = report['findings'] || []

        summary_by_severity = { 'critical' => 0, 'high' => 0, 'medium' => 0, 'low' => 0, 'none' => 0 }
        findings.each do |f|
          severity = (f['severity'] || 'none').to_s.downcase
          summary_by_severity[severity] += 1
        end

        summary_by_owasp = {}
        findings.each do |f|
          category = f['owasp_category'] || 'N/A'
          summary_by_owasp[category] ||= 0
          summary_by_owasp[category] += 1
        end

        {
          id: report['id'],
          package: report['package'],
          total_findings: findings.size,
          findings_by_severity: summary_by_severity,
          findings_by_owasp: summary_by_owasp,
          avg_confidence: findings.any? ? (findings.map { |f| f['confidence'] || 50 }.sum.to_f / findings.size).round(2) : 0,
          timestamp: report['timestamp'],
          generated_at: report.dig('scan_metadata', 'generated_at')
        }
      end

      def self.save_report(content, format, path)
        File.write(path, content)
        File.exist?(path) ? path : nil
      end
    end
  end
end
