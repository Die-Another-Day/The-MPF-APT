require_relative '../core/auxiliary_base'
require_relative '../reporting/report_manager'
require 'json'
require 'time'
require 'fileutils'
require 'open3'
require 'rexml/document'
require 'pathname'

module MPF
  module Modules
    class StaticAnalysis < MPF::Core::AuxiliaryBase

      def register_info
        @info = {
          name: 'Android Static Analysis',
          module: 'auxiliary/static_analysis',
          description: 'Performs comprehensive static analysis of Android APK files. ' \
                      'Decompiles APK, parses AndroidManifest.xml, identifies exported components, ' \
                      'and detects common security vulnerabilities.',
          authors: ['MPF Research Team']
        }
      end

      def register_options
        add_option('TARGET', 'Path to APK or IPA file for analysis', required: false)
        add_option('APK', 'Path to APK file for analysis (legacy)', required: false)
        add_option('OUTPUT_DIR', 'Output directory for results', default: 'reports/static')
        add_option('WORKSPACE', 'Workspace directory for temporary files', default: 'workspace')
      end

      def run(target_info = {})
        target = get_option('TARGET') || get_option('APK')
        output_dir = get_option('OUTPUT_DIR')
        workspace = get_option('WORKSPACE')

        unless target
          return { "summary" => "No target file provided. Use: set TARGET <path>" }
        end

        unless File.exist?(target)
          return { "summary" => "Target file not found: #{target}" }
        end

        # Automatically detect target type and route to the correct pipeline
        if target.downcase.end_with?('.ipa')
          print_status("Automatically detected iOS IPA input.")
          require_relative '../analysis/ios/analyzer'
          analyzer = MPF::Analysis::IOS::Analyzer.new
          result = analyzer.run(target, output_dir, workspace)
          return result
        end

        # Default/legacy APK analysis flow
        apk = target
        print_status("Starting Android static analysis...")
        print_status("Target APK: #{apk}")

        timestamp = Time.now.to_i
        workdir = "#{workspace}/static_#{timestamp}"
        decoded_dir = "#{workdir}/decoded"

        FileUtils.mkdir_p(workdir)
        FileUtils.mkdir_p(output_dir)

        # 1. Run apktool
        print_status("Decompiling APK with apktool...")
        stdout, stderr, status = Open3.capture3("apktool d -f \"#{apk}\" -o \"#{decoded_dir}\"")

        unless status.success?
          print_error("apktool failed: #{stderr}")
          return {
            "summary" => "apktool failed",
            "error" => stderr.strip
          }
        end

        print_good("APK decompiled successfully")

        findings = []
        evidence = {}

        manifest_path = File.join(decoded_dir, "AndroidManifest.xml")

        # 2. Parse decoded AndroidManifest.xml
        if File.exist?(manifest_path)
          print_status("Parsing AndroidManifest.xml...")
          manifest_xml = File.read(manifest_path, mode: 'rb').force_encoding('UTF-8').encode('UTF-8', 'UTF-8', invalid: :replace, undef: :replace, replace: '')
          doc = REXML::Document.new(manifest_xml)

          package = doc.root.attributes["package"]
          evidence["package"] = package
          print_good("Package: #{package}")

          app = doc.root.elements["application"]

          if app
            # Check debuggable flag
            if app.attributes["android:debuggable"] == "true"
              findings << {
                "id" => "debuggable_enabled",
                "severity" => "medium",
                "description" => "Application has android:debuggable=true, allowing runtime debugging",
                "component" => "Application"
              }
            end

            # Check allowBackup flag
            if app.attributes["android:allowBackup"] == "true"
              findings << {
                "id" => "allow_backup_enabled",
                "severity" => "medium",
                "description" => "Application allows backup via ADB, potentially exposing sensitive data",
                "component" => "Application"
              }
            end

            # Check exported components
            check_exported_components(app, findings)
          end

          # Check permissions
          check_permissions(doc, findings, evidence)

          # Check for Network Security Config (M5)
          check_network_security(doc, decoded_dir, findings)

        else
          print_error("AndroidManifest.xml not found")
          return {
            "summary" => "AndroidManifest.xml not found in decoded APK"
          }
        end

          # Check for Secrets (M1)
        check_secrets(decoded_dir, findings)

        # Check for Binary Protections (M7)
        check_binary_protection(decoded_dir, findings)

        # Check for Insecure Storage (M9)
        check_insecure_storage(decoded_dir, findings)

        # Check for Cryptography (M10)
        check_cryptography(decoded_dir, findings)

        # Check for Input Validation (M4)
        check_input_validation(decoded_dir, findings)

        # Check for Privacy (M6)
        check_privacy(decoded_dir, findings)

        # 3. Generate results
        result = {
          "summary" => "Static analysis completed",
          "timestamp" => Time.now.iso8601,
          "apk" => apk,
          "findings" => findings,
          "evidence" => evidence,
          "workspace" => workdir
        }

        # Save results
        output_file = File.join(output_dir, "static_analysis_#{timestamp}.json")
        File.write(output_file, JSON.pretty_generate(result))

        # Generate HTML using unified ReportManager
        MPF::Reporting::ReportManager.generate_reports(output_file, "static", result["evidence"]["package"])

        print_good("Static analysis complete")
        print_status("Findings: #{findings.length}")
        print_status("Results saved to: #{output_file}")

        result
      end

      private

      def check_exported_components(app, findings)
        # Check Activities
        app.elements.each("activity") do |activity|
          name = activity.attributes["android:name"]
          exported = activity.attributes["android:exported"]
          permission = activity.attributes["android:permission"]
          has_intent_filter = !activity.elements["intent-filter"].nil?

          if (exported == "true" || (exported.nil? && has_intent_filter)) && permission.nil?
            findings << {
              "id" => "exported_activity_without_permission",
              "severity" => "high",
              "description" => "Exported Activity without permission protection (M3)",
              "component" => name
            }
          end
        end

        # Check Services
        app.elements.each("service") do |service|
          name = service.attributes["android:name"]
          exported = service.attributes["android:exported"]
          permission = service.attributes["android:permission"]
          has_intent_filter = !service.elements["intent-filter"].nil?

          if (exported == "true" || (exported.nil? && has_intent_filter)) && permission.nil?
            findings << {
              "id" => "exported_service_without_permission",
              "severity" => "high",
              "description" => "Exported Service without permission protection (M3)",
              "component" => name
            }
          end
        end

        # Check Broadcast Receivers
        app.elements.each("receiver") do |receiver|
          name = receiver.attributes["android:name"]
          exported = receiver.attributes["android:exported"]
          permission = receiver.attributes["android:permission"]
          has_intent_filter = !receiver.elements["intent-filter"].nil?

          if (exported == "true" || (exported.nil? && has_intent_filter)) && permission.nil?
            findings << {
              "id" => "exported_receiver_without_permission",
              "severity" => "high",
              "description" => "Exported BroadcastReceiver without permission protection (M3)",
              "component" => name
            }
          end
        end

        # Check Content Providers
        app.elements.each("provider") do |provider|
          name = provider.attributes["android:name"]
          exported = provider.attributes["android:exported"]
          permission = provider.attributes["android:permission"]
          authorities = provider.attributes["android:authorities"]

          if exported == "true" && permission.nil?
            findings << {
              "id" => "exported_provider_without_permission",
              "severity" => "critical",
              "description" => "Exported ContentProvider without permission protection (M3)",
              "component" => authorities || name
            }
          end
        end
      end

      def check_permissions(doc, findings, evidence)
        permissions = []
        dangerous_permissions = []

        doc.root.elements.each("uses-permission") do |perm|
          name = perm.attributes["android:name"]
          permissions << name

          # Check for dangerous permissions
          if is_dangerous_permission(name)
            dangerous_permissions << name
          end
        end

        evidence["permissions"] = permissions
        evidence["dangerous_permissions"] = dangerous_permissions

        if dangerous_permissions.any?
          findings << {
            "id" => "dangerous_permissions_requested",
            "severity" => "medium",
            "description" => "Application requests dangerous permissions: #{dangerous_permissions.join(', ')}",
            "component" => "Permissions"
          }
        end
      end

      def is_dangerous_permission(permission)
        dangerous = [
          "android.permission.READ_CONTACTS",
          "android.permission.WRITE_CONTACTS",
          "android.permission.READ_SMS",
          "android.permission.SEND_SMS",
          "android.permission.RECEIVE_SMS",
          "android.permission.READ_CALL_LOG",
          "android.permission.WRITE_CALL_LOG",
          "android.permission.CAMERA",
          "android.permission.RECORD_AUDIO",
          "android.permission.ACCESS_FINE_LOCATION",
          "android.permission.ACCESS_COARSE_LOCATION",
          "android.permission.READ_EXTERNAL_STORAGE",
          "android.permission.WRITE_EXTERNAL_STORAGE"
        ]

        dangerous.include?(permission)
      end

      def check_secrets(decoded_dir, findings)
        print_status("Scanning for hardcoded secrets (M1)...")
        
        patterns = {
          "google_api_key" => /AIza[0-9A-Za-z\\-_]{35}/,
          "aws_access_key" => /AKIA[0-9A-Z]{16}/,
          "firebase_url" => /https:\/\/.*\.firebaseio\.com/,
          "private_key" => /-----BEGIN PRIVATE KEY-----/,
          "generic_api_key" => /api_key\s*=\s*['"][a-zA-Z0-9\-_]{20,}['"]/i,
          "jwt_token" => /eyJ[a-zA-Z0-9\-_]+\.eyJ[a-zA-Z0-9\-_]+\.[a-zA-Z0-9\-_]+/
        }

        # Walk through smali and xml files
        Dir.glob("#{decoded_dir}/**/*.{smali,xml,java,kt}") do |file|
          next if File.directory?(file)
          
          begin
            content = File.read(file, mode: 'rb').force_encoding('UTF-8').encode('UTF-8', 'UTF-8', invalid: :replace, undef: :replace, replace: '')
            
            patterns.each do |id, regex|
              begin
                if content.match?(regex)
                  relative_path = Pathname.new(file).relative_path_from(Pathname.new(decoded_dir)).to_s
                  
                  findings << {
                    "id" => "hardcoded_#{id}",
                    "severity" => "high",
                    "description" => "Potential hardcoded secret found: #{id}",
                    "component" => relative_path,
                    "evidence" => content.match(regex).to_s[0..50] + "..." 
                  }
                end
              rescue => e
                # Skip pattern matching errors
                next
              end
            end
          rescue => e
            # Skip files that can't be read
            next
          end
        end
      end

      def check_network_security(doc, decoded_dir, findings)
        print_status("Checking Network Security Config (M5)...")
        
        # Check Manifest for networkSecurityConfig
        app = doc.root.elements["application"]
        return unless app

        ns_config = app.attributes["android:networkSecurityConfig"]
        
        if ns_config
          # Parse the config file
          # usually @xml/network_security_config -> res/xml/network_security_config.xml
          config_name = ns_config.split('/').last
          config_path = Dir.glob("#{decoded_dir}/res/xml/#{config_name}.xml").first
          
          if config_path && File.exist?(config_path)
            xml_content = File.read(config_path, mode: 'rb').force_encoding('UTF-8').encode('UTF-8', 'UTF-8', invalid: :replace, undef: :replace, replace: '')
            config_doc = REXML::Document.new(xml_content)
            
            # Check base-config for cleartextTrafficPermitted
            base_config = config_doc.root.elements["base-config"]
            if base_config && base_config.attributes["cleartextTrafficPermitted"] == "true"
              findings << {
                "id" => "cleartext_traffic_allowed",
                "severity" => "high",
                "description" => "Network Security Config explicitly allows cleartext traffic (HTTP)",
                "component" => "NetworkSecurityConfig"
              }
            end
          end
        else
          # If target SDK >= 28, cleartext is disabled by default, but we should check usesCleartextTraffic in manifest
          if app.attributes["android:usesCleartextTraffic"] == "true"
             findings << {
                "id" => "cleartext_traffic_allowed",
                "severity" => "high",
                "description" => "Manifest allows cleartext traffic globally",
                "component" => "AndroidManifest.xml"
              }
          end
        end
      end

      def check_binary_protection(decoded_dir, findings)
        print_status("Checking Binary Protections (M7)...")
        
        # Root Detection Checks
        root_indicators = [
          "test-keys",
          "/system/app/Superuser.apk",
          "/system/xbin/su",
          "RootTools"
        ]
        
        found_root_checks = false
        
        # Anti-Debugging Checks
        anti_debug_indicators = [
          "android.os.Debug.isDebuggerConnected",
          "android.os.Debug.waitForDebugger"
        ]
        
        found_anti_debug = false

        Dir.glob("#{decoded_dir}/**/*.smali") do |file|
          begin
            content = File.read(file, mode: 'rb').force_encoding('UTF-8').encode('UTF-8', 'UTF-8', invalid: :replace, undef: :replace, replace: '')
          rescue => e
            next
          end
          
          root_indicators.each do |indicator|
            if content.include?(indicator)
              found_root_checks = true
            end
          end
          
          anti_debug_indicators.each do |indicator|
            if content.include?(indicator)
              found_anti_debug = true
            end
          end
        end
        
        unless found_root_checks
          findings << {
            "id" => "root_detection_missing",
            "severity" => "medium",
            "description" => "No common root detection mechanisms found",
            "component" => "Application Logic"
          }
        end
        
        unless found_anti_debug
          findings << {
            "id" => "anti_debug_missing",
            "severity" => "low",
            "description" => "No anti-debugging checks found",
            "component" => "Application Logic"
          }
        end
      end

      def check_insecure_storage(decoded_dir, findings)
        print_status("Checking Insecure Data Storage (M9)...")
        
        # Check for World Readable/Writeable usage
        Dir.glob("#{decoded_dir}/**/*.smali") do |file|
          begin
            content = File.read(file, mode: 'rb').force_encoding('UTF-8').encode('UTF-8', 'UTF-8', invalid: :replace, undef: :replace, replace: '')
          rescue => e
            next
          end
          
          # MODE_WORLD_READABLE = 1
          # MODE_WORLD_WRITEABLE = 2
          if content.match?(/getSharedPreferences.*0x1/) || content.match?(/openFileOutput.*0x1/)
            relative_path = Pathname.new(file).relative_path_from(Pathname.new(decoded_dir)).to_s
            findings << {
              "id" => "world_readable_files",
              "severity" => "high",
              "description" => "Code creates world-readable files (MODE_WORLD_READABLE)",
              "component" => relative_path
            }
          end
          
          if content.match?(/getSharedPreferences.*0x2/) || content.match?(/openFileOutput.*0x2/)
             relative_path = Pathname.new(file).relative_path_from(Pathname.new(decoded_dir)).to_s
             findings << {
              "id" => "world_writeable_files",
              "severity" => "high",
              "description" => "Code creates world-writeable files (MODE_WORLD_WRITEABLE)",
              "component" => relative_path
            }
          end
          
          # Check for external storage usage
          if content.include?("getExternalStorageDirectory") || content.include?("getExternalFilesDir")
             relative_path = Pathname.new(file).relative_path_from(Pathname.new(decoded_dir)).to_s
             findings << {
              "id" => "insecure_external_storage",
              "severity" => "medium",
              "description" => "App writes to external storage (SD Card), which is not secure",
              "component" => relative_path
            }
          end
        end
      end

      def check_cryptography(decoded_dir, findings)
        print_status("Checking Cryptography (M10)...")
        
        crypto_patterns = {
          "weak_algorithm_usage" => /MessageDigest\.getInstance\(\s*"(MD5|SHA-1)"\s*\)/i,
          "ecb_mode_usage" => /Cipher\.getInstance\(\s*"[A-Z]+\/ECB\/[A-Z]+"\s*\)/i,
          "des_usage" => /Cipher\.getInstance\(\s*"DES"\s*\)/i,
          "hardcoded_iv" => /IvParameterSpec\(\s*new\s+byte\[\]\s*\{/
        }

        Dir.glob("#{decoded_dir}/**/*.smali") do |file|
          begin
            content = File.read(file, mode: 'rb').force_encoding('UTF-8').encode('UTF-8', 'UTF-8', invalid: :replace, undef: :replace, replace: '')
          rescue => e
            next
          end
          
          crypto_patterns.each do |id, regex|
            if content.match?(regex)
               relative_path = Pathname.new(file).relative_path_from(Pathname.new(decoded_dir)).to_s
               findings << {
                "id" => id,
                "severity" => "high",
                "description" => "Weak cryptography detected: #{id}",
                "component" => relative_path
              }
            end
          end
        end
      end

      def check_input_validation(decoded_dir, findings)
        print_status("Checking Input Validation (M4)...")
        
        patterns = {
          "sql_injection" => /(execSQL|rawQuery)\(\s*.*(\+|append).*\)/,
          "webview_js_enabled" => /setJavaScriptEnabled\(\s*true\s*\)/,
          "webview_add_js_interface" => /addJavascriptInterface/,
          "path_traversal" => /new\s+File\(\s*.*(\+|append).*\)/
        }

        Dir.glob("#{decoded_dir}/**/*.smali") do |file|
          begin
            content = File.read(file, mode: 'rb').force_encoding('UTF-8').encode('UTF-8', 'UTF-8', invalid: :replace, undef: :replace, replace: '')
          rescue => e
            next
          end
          
          patterns.each do |id, regex|
            if content.match?(regex)
               relative_path = Pathname.new(file).relative_path_from(Pathname.new(decoded_dir)).to_s
               findings << {
                "id" => id,
                "severity" => "medium",
                "description" => "Potential Input Validation issue: #{id}",
                "component" => relative_path
              }
            end
          end
        end
      end

      def check_privacy(decoded_dir, findings)
        print_status("Checking Privacy Controls (M6)...")
        
        patterns = {
          "pii_device_id" => /getDeviceId|getImei|getMeid/,
          "pii_sim_serial" => /getSimSerialNumber/,
          "pii_phone_number" => /getLine1Number/,
          "pii_location" => /getLastKnownLocation|requestLocationUpdates/,
          "pii_mac_address" => /getMacAddress/
        }

        Dir.glob("#{decoded_dir}/**/*.smali") do |file|
          begin
            content = File.read(file, mode: 'rb').force_encoding('UTF-8').encode('UTF-8', 'UTF-8', invalid: :replace, undef: :replace, replace: '')
          rescue => e
            next
          end
          
          patterns.each do |id, regex|
            if content.match?(regex)
               relative_path = Pathname.new(file).relative_path_from(Pathname.new(decoded_dir)).to_s
               findings << {
                "id" => id,
                "severity" => "medium",
                "description" => "Potential PII access: #{id.gsub('pii_', '')}",
                "component" => relative_path
              }
            end
          end
        end
      end

      def print_status(msg)
        puts "[*] #{msg}"
      end

      def print_good(msg)
        puts "[+] #{msg}"
      end

      def print_error(msg)
        puts "[-] #{msg}"
      end
    end
  end
end