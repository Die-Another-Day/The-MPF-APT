require_relative 'base_rule'
require 'pathname'

module MPF
  module Analysis
    module Rules
      class M4InputValidationRule < BaseRule
        def initialize
          super(
            id: 'M4-INPUT-VALIDATION',
            name: 'Insufficient Input/Output Validation',
            owasp_category: 'M4',
            severity: :medium,
            description: 'Detection of potential SQL Injection, Path Traversal, and unsafe WebView configurations.',
            remediation: 'Validate all input, use parameterized queries, and configure WebViews securely.',
            detection_logic: ->(context) { detect(context) }
          )
        end

        def detect(context)
          decoded_dir = context[:decoded_dir]
          return [] unless decoded_dir

          findings = []

          patterns = {
            "sql_injection" => /(execSQL|rawQuery)\(\s*.*(\+|append).*\)/,
            "webview_js_enabled" => /setJavaScriptEnabled\(\s*true\s*\)/,
            "webview_add_js_interface" => /addJavascriptInterface/,
            "path_traversal" => /new\s+File\(\s*.*(\+|append).*\)/
          }

          Dir.glob("#{decoded_dir}/**/*.{smali,java,kt}") do |file|
            next if File.directory?(file)
            content = BaseRule.safe_read(file)
            next if content.empty?

            patterns.each do |key, regex|
              if content.match?(regex)
                relative_path = Pathname.new(file).relative_path_from(Pathname.new(decoded_dir)).to_s
                findings << {
                  id: key,
                  owasp: 'M4',
                  severity: :medium,
                  description: "Potential Input Validation issue: #{key.gsub('_', ' ')}",
                  component: relative_path,
                  evidence: content.match(regex).to_s[0..50] + "..."
                }
              end
            end
          end

          findings
        end
      end
    end
  end
end
