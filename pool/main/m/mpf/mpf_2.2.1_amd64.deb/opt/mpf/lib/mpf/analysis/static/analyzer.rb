require_relative '../../core/auxiliary_base'
require 'json'
require 'time'
require 'fileutils'
require 'open3'
require 'rexml/document'
require_relative '../../analysis/rules/rule_registry'

module MPF
  module Analysis
    module Static
      class Analyzer < MPF::Core::AuxiliaryBase

        def register_info
          @info = {
            name: 'Android Static Analysis',
            module: 'auxiliary/static_analysis',
            description: 'Performs comprehensive static analysis of Android APK files. ' \
                        'Decompiles APK, parses AndroidManifest.xml, identifies exported components, ' \
                        'and detects common security vulnerabilities.',
            authors: ['MPF Research Team']
          }
        end

        def register_options
          add_option('TARGET', 'Path to APK or IPA file for analysis', required: false)
          add_option('APK', 'Path to APK file for analysis (legacy)', required: false)
          add_option('OUTPUT_DIR', 'Output directory for results', default: 'reports/static')
          add_option('WORKSPACE', 'Workspace directory for temporary files', default: 'workspace')
        end

        def run(target_info = {})
          target = get_option('TARGET') || get_option('APK')
          output_dir = get_option('OUTPUT_DIR')
          workspace = get_option('WORKSPACE')

          unless target
            return { "summary" => "No target file provided. Use: set TARGET <path>" }
          end

          unless File.exist?(target)
            return { "summary" => "Target file not found: #{target}" }
          end

          # Automatically route to iOS static analyzer if the target is an IPA
          if target.downcase.end_with?('.ipa')
            print_status("Automatically detected iOS IPA input.")
            require_relative '../ios/analyzer'
            analyzer = MPF::Analysis::IOS::Analyzer.new
            result = analyzer.run(target, output_dir, workspace)
            return result
          end

          apk = target
          print_status("Starting static analysis...")
          print_status("Target APK: #{apk}")

          timestamp = Time.now.to_i
          workdir = "#{workspace}/static_#{timestamp}"
          decoded_dir = "#{workdir}/decoded"

          FileUtils.mkdir_p(workdir)
          FileUtils.mkdir_p(output_dir)

          # 1. Run apktool
          print_status("Decompiling APK with apktool... (this may take a few minutes)")
          
          # Fantastic animated spinner
          spinner_chars = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']
          animation_thread = Thread.new do
            i = 0
            loop do
              print "\r\e[38;5;82m[\e[38;5;51m#{spinner_chars[i]}\e[38;5;82m]\e[0m \e[38;5;253mAnalyzing binary structures: \e[38;5;245m#{apk}\e[0m"
              i = (i + 1) % spinner_chars.length
              sleep 0.1
            end
          end

          stdout, stderr, status = Open3.capture3("apktool d -f \"#{apk}\" -o \"#{decoded_dir}\"")
          
          animation_thread.kill
          print "\r\e[K" # Clear the spinner line

          unless status.success?
            print_error("apktool failed: #{stderr}")
            return {
              "summary" => "apktool failed",
              "error" => stderr.strip
            }
          end

          print_good("APK decompiled successfully")

          findings = []
          evidence = {}

          manifest_path = File.join(decoded_dir, "AndroidManifest.xml")

          # Context for rules
          context = {
            decoded_dir: decoded_dir,
            manifest_path: manifest_path,
            manifest_doc: nil,
            manifest_app: nil
          }

          # 2. Parse decoded AndroidManifest.xml
          if File.exist?(manifest_path)
            print_status("Parsing AndroidManifest.xml...")
            manifest_xml = File.read(manifest_path, mode: 'rb').force_encoding('UTF-8').encode('UTF-8', 'UTF-8', invalid: :replace, undef: :replace, replace: '')
            doc = REXML::Document.new(manifest_xml)
            context[:manifest_doc] = doc

            package = doc.root.attributes["package"]
            evidence["package"] = package
            print_good("Package: #{package}")

            app = doc.root.elements["application"]
            context[:manifest_app] = app

            if app
               # Basic Manifest Checks (Non-Rule for now, or could be a General Rule)
               # keeping legacy checks for debuggable/backup here for now or moving later
               check_manifest_basics(app, findings)
            end
            
            check_permissions(doc, findings, evidence)
          else
            print_error("AndroidManifest.xml not found")
            return {
              "summary" => "AndroidManifest.xml not found in decoded APK"
            }
          end

          # 3. Execute Rule Engine
          print_status("Executing OWASP Rule Engine...")
          registry = MPF::Analysis::Rules::RuleRegistry.new
          
          registry.all_rules.each do |rule|
            print_status("Running rule: #{rule.name} (#{rule.owasp_category})")
            begin
              rule_findings = rule.run(context)
              findings.concat(rule_findings)
            rescue => e
              print_error("Rule #{rule.name} failed: #{e.message}")
            end
          end

          # 4. Generate results
          result = {
            "summary" => "Static analysis completed",
            "timestamp" => Time.now.iso8601,
            "apk" => apk,
            "findings" => findings,
            "evidence" => evidence,
            "workspace" => workdir
          }

          # Save results
          output_file = File.join(output_dir, "static_analysis_#{timestamp}.json")
          File.write(output_file, JSON.pretty_generate(result))

          print_good("Static analysis complete")
          print_status("Findings: #{findings.length}")
          print_status("Results saved to: #{output_file}")

          result
        end

        private
        
        def check_manifest_basics(app, findings)
            # Check debuggable flag
            if app.attributes["android:debuggable"] == "true"
              findings << {
                "id" => "debuggable_enabled",
                "severity" => "medium",
                "description" => "Application has android:debuggable=true, allowing runtime debugging",
                "component" => "Application"
              }
            end

            # Check allowBackup flag
            if app.attributes["android:allowBackup"] == "true"
              findings << {
                "id" => "allow_backup_enabled",
                "severity" => "medium",
                "description" => "Application allows backup via ADB, potentially exposing sensitive data",
                "component" => "Application"
              }
            end
        end

        def check_permissions(doc, findings, evidence)
          permissions = []
          dangerous_permissions = []

          doc.root.elements.each("uses-permission") do |perm|
            name = perm.attributes["android:name"]
            permissions << name

            # Check for dangerous permissions
            if is_dangerous_permission(name)
              dangerous_permissions << name
            end
          end

          evidence["permissions"] = permissions
          evidence["dangerous_permissions"] = dangerous_permissions

          if dangerous_permissions.any?
            findings << {
              "id" => "dangerous_permissions_requested",
              "severity" => "medium",
              "description" => "Application requests dangerous permissions: #{dangerous_permissions.join(', ')}",
              "component" => "Permissions"
            }
          end
        end

        def is_dangerous_permission(permission)
          dangerous = [
            "android.permission.READ_CONTACTS",
            "android.permission.WRITE_CONTACTS",
            "android.permission.READ_SMS",
            "android.permission.SEND_SMS",
            "android.permission.RECEIVE_SMS",
            "android.permission.READ_CALL_LOG",
            "android.permission.WRITE_CALL_LOG",
            "android.permission.CAMERA",
            "android.permission.RECORD_AUDIO",
            "android.permission.ACCESS_FINE_LOCATION",
            "android.permission.ACCESS_COARSE_LOCATION",
            "android.permission.READ_EXTERNAL_STORAGE",
            "android.permission.WRITE_EXTERNAL_STORAGE"
          ]

          dangerous.include?(permission)
        end

        def print_status(msg)
          puts "[*] #{msg}"
        end

        def print_good(msg)
          puts "[+] #{msg}"
        end

        def print_error(msg)
          puts "[-] #{msg}"
        end
      end
    end
  end
end
