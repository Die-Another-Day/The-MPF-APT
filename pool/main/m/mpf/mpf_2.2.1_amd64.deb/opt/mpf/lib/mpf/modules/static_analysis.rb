require_relative 'module_base'
require 'json'
require 'time'
require 'fileutils'
require 'open3'
require 'rexml/document'

module MPF
  class StaticAnalysis < ModuleBase

    def run(target)
      apk = target[:apk]
      return { "summary" => "No APK provided. Use: set APK <path>" } unless apk && File.exist?(apk)

      timestamp = Time.now.to_i
      workdir = "workspace/static_#{timestamp}"
      decoded_dir = "#{workdir}/decoded"

      FileUtils.mkdir_p(workdir)

      # 1️⃣ Run apktool
      stdout, stderr, status = Open3.capture3("apktool d -f \"#{apk}\" -o \"#{decoded_dir}\"")

      unless status.success?
        return {
          "summary" => "apktool failed",
          "error" => stderr.strip
        }
      end

      findings = []
      evidence = {}

      manifest_path = File.join(decoded_dir, "AndroidManifest.xml")

      # 2️⃣ Parse decoded AndroidManifest.xml
      if File.exist?(manifest_path)
        manifest_xml = File.read(manifest_path, mode: 'rb').force_encoding('UTF-8').encode('UTF-8', 'UTF-8', invalid: :replace, undef: :replace, replace: '')
        doc = REXML::Document.new(manifest_xml)

        package = doc.root.attributes["package"]
        evidence["package"] = package

        app = doc.root.elements["application"]

        if app
          if app.attributes["android:debuggable"] == "true"
            findings << {
              "id" => "debuggable_enabled",
              "severity" => "medium",
              "description" => "Application debuggable flag is enabled"
            }
          end

          if app.attributes["android:allowBackup"] == "true"
            findings << {
              "id" => "allow_backup_enabled",
              "severity" => "medium",
              "description" => "Application allows backup of app data"
            }
          end
        end

        # 3️⃣ Detect exported components with detailed analysis
        %w(activity service receiver provider).each do |type|
          doc.root.elements.each("//#{type}") do |el|
            exported = el.attributes["android:exported"]
            name = el.attributes["android:name"]
            permission = el.attributes["android:permission"]

            if exported == "true"
              severity = permission ? "medium" : "high"
              description = "Exported #{type}"
              description += permission ? " with permission control" : " without access restriction"
              
              findings << {
                "id" => "exported_#{type}",
                "severity" => severity,
                "component" => name,
                "permission" => permission,
                "description" => description,
                "exploitability" => assess_exploitability(type, permission)
              }
            end
          end
        end

      else
        evidence["manifest"] = "AndroidManifest.xml not found"
      end

      # 4️⃣ Scan only relevant decoded files for secrets
      Dir.glob("#{decoded_dir}/**/*.{xml,json,properties,smali}").each do |file|
        next if file.include?("/res/anim/")
        next if file.include?("/res/drawable/")

        begin
          content = File.read(file, mode: 'rb').force_encoding('UTF-8').encode('UTF-8', 'UTF-8', invalid: :replace, undef: :replace, replace: '')

          if content =~ /(api[_-]?key|secret|password|token)\s*[:=]\s*["'][^"']{8,}/i
            findings << {
              "id" => "hardcoded_secret",
              "severity" => "medium",
              "file" => file.sub(decoded_dir + "/", ""),
              "description" => "Possible hardcoded secret detected"
            }
          end
        rescue
          next
        end
      end

      {
        "summary"  => "Static analysis completed",
        "apk"      => apk,
        "workspace"=> decoded_dir,
        "findings" => findings,
        "evidence" => evidence,
        "analysis_metadata" => {
          "timestamp" => Time.now.iso8601,
          "total_findings" => findings.length,
          "high_severity" => findings.count { |f| f["severity"] == "high" },
          "medium_severity" => findings.count { |f| f["severity"] == "medium" }
        }
      }
    end

    private

    def assess_exploitability(component_type, permission)
      if permission
        case component_type
        when "activity" then "medium"
        when "provider" then "medium" 
        when "service" then "low"
        when "receiver" then "low"
        end
      else
        case component_type
        when "activity" then "high"
        when "provider" then "critical"
        when "service" then "high"
        when "receiver" then "medium"
        end
      end
    end
  end
end
