require 'readline'
require 'json'
require 'fileutils'
require_relative 'module_manager'
require_relative 'exploit_base'
require_relative 'auxiliary_base'
require_relative '../modules/static_analysis_v2'
require_relative '../modules/dynamic_analysis_v2'
require_relative '../emulator/manager'
# Reports handled by unified ReportManager

module MPF
  module Core
    class Console
      attr_reader :current_module, :module_manager

      def initialize
        @module_manager = ModuleManager.new
        @emulator_manager = MPF::Emulator::Manager.new
        @current_module = nil
        @current_payload = nil
        @options = {}
        @prompt = "mpf"

        # Ensure report directories exist
        FileUtils.mkdir_p('reports/static')
        FileUtils.mkdir_p('reports/dynamic')
        FileUtils.mkdir_p('reports/exploit')
        FileUtils.mkdir_p('reports/payload')
        FileUtils.mkdir_p('reports/attack_chains')
        FileUtils.mkdir_p('reports/auxiliary')
        FileUtils.mkdir_p('reports/intel')
      end

      def start
        run_startup_diagnostics rescue nil

        display_banner
        puts "\e[38;5;250mType '\e[38;5;82mhelp\e[38;5;250m' for main menu commands\e[0m"
        puts "\e[38;5;250mType '\e[38;5;82mhelp auxiliary\e[38;5;250m', '\e[38;5;82mhelp exploit\e[38;5;250m', or '\e[38;5;82mhelp payload\e[38;5;250m' for context-specific help\e[0m"
        puts "\e[38;5;250mUse TAB for auto-completion\n\n\e[0m"

        # Setup tab completion
        setup_tab_completion

        while true
          begin
            input = Readline.readline("\e[38;5;51m#{@prompt} > \e[0m", true)
            break if input.nil?
            
            next if input.strip.empty?
            
            handle_command(input.strip)
          rescue Interrupt
            puts "\n\e[38;5;208m[*] Interrupt: use 'exit' to quit\e[0m"
          rescue => e
            puts "\e[38;5;196m[-] Error: #{e.message}\e[0m"
            puts "\e[38;5;240m#{e.backtrace.first(3).join("\n")}\e[0m" if ENV['DEBUG']
          end
        end

        puts "\n\e[38;5;82m[*] Exiting MPF... Goodbye!\e[0m"
      end

      def setup_tab_completion
        # Get all available modules
        all_modules = []
        all_modules += @module_manager.list_modules(:exploits).keys
        all_modules += @module_manager.list_modules(:payloads).keys
        all_modules += @module_manager.list_modules(:auxiliary).keys

        # Define completion proc
        comp = proc do |s|
          # Get the full line being typed
          line = Readline.line_buffer
          words = line.split(/\s+/)
          
          # Context-aware completion based on command
          case words[0]&.downcase
          when 'use'
            # Complete module paths
            if words.length == 1 || (words.length == 2 && !line.end_with?(' '))
              # User is typing: use <module>
              all_modules.grep(/^#{Regexp.escape(s)}/i)
            else
              []
            end
            
          when 'set'
            # Complete option names or values
            if words.length == 1 || (words.length == 2 && !line.end_with?(' '))
              # User is typing: set <option>
              if @current_module && @current_module.respond_to?(:options)
                @current_module.options.keys.map(&:to_s).grep(/^#{Regexp.escape(s)}/i)
              elsif @current_payload
                @current_payload.options.keys.map(&:to_s).grep(/^#{Regexp.escape(s)}/i)
              else
                []
              end
            elsif words.length == 2 || (words.length == 3 && !line.end_with?(' '))
              # User is typing: set <option> <value>
              option = words[1]&.upcase
              
              # Special completion for PAYLOAD option
              if option == 'PAYLOAD'
                payloads = @module_manager.list_modules(:payloads).keys
                payloads.grep(/^#{Regexp.escape(s)}/i)
              # Special completion for DEVICE option
              elsif option == 'DEVICE'
                devices = get_connected_devices
                devices.grep(/^#{Regexp.escape(s)}/i)
              # Special completion for file paths (APK, TARGET, OUTPUT_DIR, etc.)
              elsif option =~ /APK|TARGET|FILE|DIR|PATH/
                # File path completion
                Dir.glob("#{s}*").map { |f| File.directory?(f) ? "#{f}/" : f }
              else
                []
              end
            else
              []
            end
            
          when 'show'
            # Complete show options
            if words.length == 1 || (words.length == 2 && !line.end_with?(' '))
              options = ['exploits', 'payloads', 'auxiliary', 'options', 'targets', 'all']
              
              # Add context-specific options
              if @current_module && defined?(MPF::Core::ExploitBase) && @current_module.is_a?(MPF::Core::ExploitBase)
                options += ['payloads']
              end
              
              options.grep(/^#{Regexp.escape(s)}/i)
            else
              []
            end
            
          when 'help'
            # Complete help contexts
            if words.length == 1 || (words.length == 2 && !line.end_with?(' '))
              ['auxiliary', 'exploit', 'payload'].grep(/^#{Regexp.escape(s)}/i)
            else
              []
            end
            
          when 'report'
            ['owasp', 'html', 'preview', '--dry-run', '--preview'].grep(/^#{Regexp.escape(s)}/i)
          when 'standards'
            ['owasp', 'mapping'].grep(/^#{Regexp.escape(s)}/i)
          when 'coverage'
            ['owasp'].grep(/^#{Regexp.escape(s)}/i)
          when 'attack-chain'
            ['generate', 'load', 'export'].grep(/^#{Regexp.escape(s)}/i)
          when 'emulator'
            ['list', 'connect', 'devices'].grep(/^#{Regexp.escape(s)}/i)
          when 'analyze'
            Dir.glob("#{s}*").map { |f| File.directory?(f) ? "#{f}/" : f }
            
          when 'search'
            # Complete search filters
            if s.include?(':')
              # User is typing a filter
              filter_type = s.split(':')[0]
              case filter_type
              when 'type'
                ['type:exploit', 'type:payload', 'type:auxiliary'].grep(/^#{Regexp.escape(s)}/i)
              when 'platform'
                ['platform:android'].grep(/^#{Regexp.escape(s)}/i)
              else
                []
              end
            else
              # Suggest common search terms
              common_terms = ['provider', 'activity', 'service', 'broadcast', 'webview', 
                            'sql', 'injection', 'traversal', 'deeplink', 'exported',
                            'type:', 'platform:']
              common_terms.grep(/^#{Regexp.escape(s)}/i)
            end
            
          when 'unset'
            # Complete option names
            if words.length == 1 || (words.length == 2 && !line.end_with?(' '))
              if @current_module && @current_module.respond_to?(:options)
                @current_module.options.keys.map(&:to_s).grep(/^#{Regexp.escape(s)}/i)
              elsif @current_payload
                @current_payload.options.keys.map(&:to_s).grep(/^#{Regexp.escape(s)}/i)
              else
                []
              end
            else
              []
            end
            
          else
            # Complete command names at the start of line
            if words.length <= 1
              commands = get_available_commands
              commands.grep(/^#{Regexp.escape(s)}/i)
            else
              []
            end
          end
        end

        Readline.completion_append_character = " "
        Readline.completion_proc = comp
      end
      
      def get_available_commands
        # Base commands always available
        base_commands = ['help', 'about', 'exit', 'quit', 'use', 'back', 'show', 'search', 
                        'sessions', 'workspace', 'auto', 'autopwn', 'standards', 'coverage', 'emulator', 'attack-chain', 'report', 'analyze']
        
        # Add context-specific commands
        if @current_module || @current_payload
          base_commands += ['info', 'options', 'set', 'unset', 'setg']
        end
        
        if @current_module && defined?(MPF::Core::ExploitBase) && @current_module.is_a?(MPF::Core::ExploitBase)
          base_commands += ['check', 'exploit', 'run']
        elsif @current_payload
          base_commands += ['generate', 'run']
        elsif @current_module
          base_commands += ['run']
        end
        
        base_commands.uniq.sort
      end
      
      def get_connected_devices
        # Get list of connected ADB devices
        begin
          output = `adb devices 2>&1`
          devices = output.lines[1..-1]&.map do |line|
            line.split(/\s+/)[0]
          end&.compact || []
          devices << 'emulator-5554' if devices.empty? # Default
          devices
        rescue
          ['emulator-5554']
        end
      end

      private

      def run_startup_diagnostics
        print "\e[?25l" # hide cursor
        tasks = [
          "Initializing core engine",
          "Loading attack signatures",
          "Verifying compliance modules",
          "Bootstrapping UI subsystems",
          "Mounting virtual filesystem"
        ]
        
        puts ""
        tasks.each do |t|
          print "\e[38;5;245m[*] #{t}...\e[0m"
          sleep(0.12)
          print "\r\e[K"
          puts "\e[38;5;82m[+] #{t} - OK\e[0m"
        end
        puts "\e[38;5;82m[*] Framework ready.\e[0m\n"
        print "\e[?25h" # show cursor
      end

      def display_banner
        banner = <<~BANNER

          \e[38;5;82m███╗   ███╗\e[38;5;118m██████╗ \e[38;5;46m███████╗\e[0m
          \e[38;5;82m████╗ ████║\e[38;5;118m██╔══██╗\e[38;5;46m██╔════╝\e[0m
          \e[38;5;82m██╔████╔██║\e[38;5;118m██████╔╝\e[38;5;46m█████╗  \e[0m
          \e[38;5;82m██║╚██╔╝██║\e[38;5;118m██╔═══╝ \e[38;5;46m██╔══╝  \e[0m
          \e[38;5;82m██║ ╚═╝ ██║\e[38;5;118m██║     \e[38;5;46m██║     \e[0m
          \e[38;5;82m╚═╝     ╚═╝\e[38;5;118m╚═╝     \e[38;5;46m╚═╝     \e[0m

          \e[38;5;253mMobile Penetration Testing Framework\e[0m
          \e[38;5;245mVersion: 2.1.0 | Project Antigravity Edition\e[0m
          \e[38;5;240m========================================\e[0m
          \e[38;5;51mAdvanced Mobile Application Security Platform\e[0m
          \e[38;5;240m========================================\e[0m

        BANNER
        puts banner
      end

      def handle_command(input)
        parts = input.split(/\s+/, 2)
        command = parts[0].downcase
        args = parts[1]

        case command
        when 'help'
          show_help(args)
        when 'exit', 'quit'
          exit(0)
        when 'use'
          use_module(args)
        when 'back'
          back_to_main
        when 'show'
          show_command(args)
        when 'set'
          set_option(args)
        when 'unset'
          unset_option(args)
        when 'setg'
          set_global_option(args)
        when 'search'
          search_modules(args)
        when 'info'
          show_info
        when 'options'
          show_options
        when 'check'
          check_exploit
        when 'exploit', 'run'
          run_exploit
        when 'generate'
          generate_payload
        when 'sessions'
          show_sessions(args)
        when 'workspace'
          manage_workspace(args)
        when 'auto', 'autopwn'
          auto_exploit(args)
        when 'emulator'
          handle_emulator_command(args)
        when 'attack-chain'
          handle_attack_chain_command(args)
        when 'standards'
          handle_standards_command(args)
        when 'coverage'
          handle_coverage_command(args)
        when 'about'
          handle_about_command
        when 'report'
          handle_report_command(args)
        when 'analyze'
          handle_analyze_command(args)
        else
          puts "[-] Unknown command: #{command}"
          puts "Type 'help' for available commands"
        end
      end

      def handle_analyze_command(args)
        if args.nil? || args.strip.empty?
          puts "[-] Usage: analyze <path_to_apk_or_ipa>"
          return
        end

        target_path = args.strip
        unless File.exist?(target_path)
          puts "[-] Target file not found: #{target_path}"
          return
        end

        require_relative '../modules/static_analysis_v2'
        static_module = MPF::Modules::StaticAnalysis.new
        static_module.set_option('TARGET', target_path)
        static_module.set_option('APK', target_path) # support legacy APK option too
        static_module.run
      end

      def show_help(context = nil)
        # Context-aware help based on current state
        if context == 'auxiliary' || (@current_module && @current_module.is_a?(MPF::Core::AuxiliaryBase))
          show_auxiliary_help
        elsif context == 'exploit' || (@current_module && defined?(MPF::Core::ExploitBase) && @current_module.is_a?(MPF::Core::ExploitBase))
          show_exploit_help
        elsif context == 'payload' || @current_payload
          show_payload_help
        else
          show_main_help
        end
      end

      def show_main_help
        help_text = <<~HELP

          ╔════════════════════════════════════════════════════════════════╗
          ║                    MPF v2.0 - MAIN MENU                        ║
          ╚════════════════════════════════════════════════════════════════╝

          Core Commands
          =============
            help                    Display this help menu
            about                   Show framework research positioning
            exit, quit              Exit the framework
            analyze <file>          Analyze Android APK or iOS IPA package
            
          Reporting & Analysis
          ====================
            report owasp            OWASP Mobile Top 10 assessment (text)
            report html             Interactive HTML intelligence dashboard
            report preview          Quick summary of latest report
            report html --dry-run   Preview HTML generation (no files)
            report html --preview   Show report summary without browser
            
          Standards & Compliance
          ======================
            standards owasp         View OWASP Mobile Top 10 categories
            standards mapping       View Exploit-to-OWASP mapping
            coverage owasp          View OWASP detection coverage
            
          Attack Chain Analysis
          =====================
            attack-chain generate   Generate attack chains from static analysis
            attack-chain load       Load vulnerabilities from file
            attack-chain export     Export attack chains to JSON
            
          Module Selection
          ================
            use <module>            Select a module (TAB for completion)
            back                    Return to main menu
            
          Discovery Commands
          ==================
            show exploits           List all exploit modules (9 available)
            show payloads           List all payload modules (13 available)
            show auxiliary          List auxiliary modules (2 available)
            show all                List everything
            search <term>           Search modules with filters

          Quick Start
          ===========
            1. Run static analysis:
               analyze app.apk
               or
               analyze app.ipa
               (Alternative: use auxiliary/static_analysis && set TARGET <file> && run)
               
            2. Generate report:
               report html
               report preview
               
            3. Search for exploits:
               search <vulnerability_type>
               
            3. Select and configure:
               use exploit/android/<module>
               
            4. Get context help:
               help exploit

          Available Module Types
          ======================
            Exploits (9):
              • exported_provider      - ContentProvider exploitation
              • exported_activity      - Activity exploitation
              • exported_service       - Service exploitation
              • insecure_broadcast     - BroadcastReceiver exploitation
              • webview_rce            - WebView RCE
              • deeplink_injection     - Deep link attacks
              • sql_injection          - SQL injection via providers
              • path_traversal         - Path traversal attacks
              • insecure_webview       - WebView configuration issues

            Payloads (13):
              Singles (8):  intent_injection, data_exfiltration, provider_query,
                           deeplink_trigger, permission_escalation, sql_injection,
                           file_extraction, screenshot_capture
              Stagers (1):  frida_injector
              Stages (3):   ssl_unpinning, method_hooking, memory_dump
              Meterpreter:  app_shell (24 commands)

            Auxiliary (2):
              • static_analysis        - APK static analysis
              • dynamic_analysis       - Runtime behavior analysis

          Search Examples
          ===============
            search provider                    - Find provider-related modules
            search type:exploit sql            - Find SQL injection exploits
            search type:payload data           - Find data exfiltration payloads
            search platform:android webview    - Find Android WebView modules

          Tips
          ====
            • Use TAB for auto-completion
            • Type 'help <context>' for specific help
            • All commands support TAB completion
            • Results saved to reports/ directory

          ╔════════════════════════════════════════════════════════════════╗
          ║  Type 'help auxiliary', 'help exploit', or 'help payload'      ║
          ║  for context-specific commands and examples                    ║
          ╚════════════════════════════════════════════════════════════════╝

        HELP
        puts format_help_visuals(help_text)
      end

      def show_auxiliary_help
        help_text = <<~HELP

          ╔════════════════════════════════════════════════════════════════╗
          ║                AUXILIARY MODULE COMMANDS                       ║
          ╚════════════════════════════════════════════════════════════════╝

          Available Commands
          ==================
            info                    Show module information
            show options            Display module options
            set <option> <value>    Set an option (TAB completion)
            unset <option>          Clear an option
            run                     Execute the module
            back                    Return to main menu
            help                    Show this help

          Available Auxiliary Modules
          ===========================
            auxiliary/static_analysis
              • Decompiles APK/Extracts IPA
              • Parses AndroidManifest.xml / Info.plist
              • Identifies exported components / entitlements
              • Detects common Android & iOS vulnerabilities
              • Generates static_analysis.json and HTML report

            auxiliary/dynamic_analysis
              • Installs and launches APK
              • Monitors runtime behavior
              • Captures network traffic
              • Analyzes SSL/TLS configuration
              • Tracks permission usage
              • Generates dynamic_analysis.json

          Example: Static Analysis
          ========================
            mpf > use auxiliary/static_analysis
            mpf static_analysis > show options
            mpf static_analysis > set APK DivaApplication.apk
            mpf static_analysis > run

          Example: Dynamic Analysis
          =========================
            mpf > use auxiliary/dynamic_analysis
            mpf dynamic_analysis > show options
            mpf dynamic_analysis > set APK DivaApplication.apk
            mpf dynamic_analysis > set PACKAGE jakhar.aseem.diva
            mpf dynamic_analysis > set DEVICE emulator-5554
            mpf dynamic_analysis > run

          Common Options
          ==============
            TARGET      - Path to APK or IPA file for analysis
            APK         - Path to APK file (legacy)
            PACKAGE     - Application package name / Bundle ID
            DEVICE      - Target device ID (default: emulator-5554)
            OUTPUT_DIR  - Output directory for results

          Tips
          ====
            • Run static analysis first to identify package name
            • Use dynamic analysis to validate runtime behavior
            • Results are saved to reports/static/ and reports/dynamic/
            • Use TAB to complete option names

          ╔════════════════════════════════════════════════════════════════╗
          ║  Type 'back' to return to main menu                            ║
          ╚════════════════════════════════════════════════════════════════╝

        HELP
        puts format_help_visuals(help_text)
      end

      def show_exploit_help
        help_text = <<~HELP

          ╔════════════════════════════════════════════════════════════════╗
          ║                  EXPLOIT MODULE COMMANDS                       ║
          ╚════════════════════════════════════════════════════════════════╝

          Available Commands
          ==================
            info                    Show detailed exploit information
            show options            Display exploit options
            show targets            Show available targets
            show payloads           List compatible payloads
            set <option> <value>    Set an option (TAB completion)
            set PAYLOAD <path>      Select payload for exploit
            unset <option>          Clear an option
            check                   Check if target is vulnerable (SAFE)
            exploit, run            Execute the exploit
            back                    Return to main menu
            help                    Show this help

          Exploit Workflow
          ================
            1. Select exploit:      use exploit/android/<module>
            2. View info:           info
            3. Check options:       show options
            4. Configure target:    set TARGET_PACKAGE <package>
            5. Set component:       set TARGET_<COMPONENT> <name>
            6. Select payload:      set PAYLOAD payload/android/<type>/<name>
            7. Verify config:       show options
            8. Test safely:         check
            9. Exploit:             exploit

          Available Exploits (9)
          ======================
            exploit/android/exported_provider
              • Exploits unprotected ContentProviders
              • Compatible: provider_query, data_exfiltration, sql_injection

            exploit/android/exported_activity
              • Exploits unprotected Activities
              • Compatible: intent_injection, deeplink_trigger

            exploit/android/exported_service
              • Exploits unprotected Services
              • Compatible: intent_injection, permission_escalation

            exploit/android/insecure_broadcast
              • Exploits BroadcastReceivers
              • Compatible: intent_injection

            exploit/android/webview_rce
              • WebView remote code execution
              • Compatible: intent_injection, data_exfiltration

            exploit/android/deeplink_injection
              • Deep link parameter injection
              • Compatible: deeplink_trigger, intent_injection

            exploit/android/sql_injection
              • SQL injection via ContentProvider
              • Compatible: sql_injection, data_exfiltration, provider_query

            exploit/android/path_traversal
              • Path traversal attacks
              • Compatible: file_extraction, data_exfiltration

            exploit/android/insecure_webview
              • WebView configuration issues
              • Compatible: intent_injection, data_exfiltration

          Common Options
          ==============
            TARGET_PACKAGE      - Application package name (required)
            TARGET_PROVIDER     - ContentProvider authority
            TARGET_ACTIVITY     - Activity class name
            TARGET_SERVICE      - Service class name
            TARGET_RECEIVER     - BroadcastReceiver class name
            DEVICE              - Device ID (default: emulator-5554)
            CHECK_ONLY          - Only check, don't exploit (true/false)
            PAYLOAD             - Payload module path

          Example: ContentProvider Exploitation
          ======================================
            mpf > use exploit/android/exported_provider
            mpf exported_provider > info
            mpf exported_provider > show options
            mpf exported_provider > set TARGET_PACKAGE jakhar.aseem.diva
            mpf exported_provider > set TARGET_PROVIDER jakhar.aseem.diva.provider.notesprovider
            mpf exported_provider > set PAYLOAD payload/android/singles/provider_query
            mpf exported_provider > check
            mpf exported_provider > exploit

          Tips
          ====
            • Always use 'check' before 'exploit' for safety
            • Use 'info' to see detailed module information
            • Use 'show payloads' to see compatible payloads
            • Set CHECK_ONLY=true for non-destructive testing
            • TAB completion works for all options

          ╔════════════════════════════════════════════════════════════════╗
          ║  Type 'back' to return to main menu                            ║
          ╚════════════════════════════════════════════════════════════════╝

        HELP
        puts format_help_visuals(help_text)
      end

      def show_payload_help
        help_text = <<~HELP

          ╔════════════════════════════════════════════════════════════════╗
          ║                  PAYLOAD MODULE COMMANDS                       ║
          ╚════════════════════════════════════════════════════════════════╝

          Available Commands
          ==================
            info                    Show detailed payload information
            show options            Display payload options
            set <option> <value>    Set an option (TAB completion)
            unset <option>          Clear an option
            generate                Generate payload without execution
            run                     Execute the payload
            back                    Return to main menu
            help                    Show this help

          Payload Types
          =============
            Singles (8)
              • Self-contained, execute immediately
              • No staging required
              • Examples: intent_injection, data_exfiltration

            Stagers (1)
              • Small initial payload
              • Downloads and executes stage
              • Example: frida_injector

            Stages (3)
              • Larger payload delivered by stager
              • Advanced functionality
              • Examples: ssl_unpinning, method_hooking, memory_dump

            Meterpreter (1)
              • Interactive shell with 24 commands
              • Full app manipulation
              • Example: app_shell

          Available Payloads (13)
          =======================
            Singles:
              payload/android/singles/intent_injection
              payload/android/singles/data_exfiltration
              payload/android/singles/provider_query
              payload/android/singles/deeplink_trigger
              payload/android/singles/permission_escalation
              payload/android/singles/sql_injection
              payload/android/singles/file_extraction
              payload/android/singles/screenshot_capture

            Stagers:
              payload/android/stagers/frida_injector

            Stages:
              payload/android/stages/ssl_unpinning
              payload/android/stages/method_hooking
              payload/android/stages/memory_dump

            Meterpreter:
              payload/android/meterpreter/app_shell

          Common Options
          ==============
            TARGET_PACKAGE      - Application package name (required)
            TARGET_COMPONENT    - Specific component to target
            DEVICE              - Device ID (default: emulator-5554)
            OUTPUT_DIR          - Output directory for results
            OUTPUT_FILE         - Output file name

          Example: Data Exfiltration
          ===========================
            mpf > use payload/android/singles/data_exfiltration
            mpf data_exfiltration > show options
            mpf data_exfiltration > set TARGET_PACKAGE jakhar.aseem.diva
            mpf data_exfiltration > set DEVICE emulator-5554
            mpf data_exfiltration > set OUTPUT_DIR ./exfiltrated
            mpf data_exfiltration > run

          Example: Interactive Shell
          ===========================
            mpf > use payload/android/meterpreter/app_shell
            mpf app_shell > set TARGET_PACKAGE jakhar.aseem.diva
            mpf app_shell > run
            
            app_shell > help
            app_shell > list_activities
            app_shell > screenshot
            app_shell > exit

          Example: Memory Dump
          ====================
            mpf > use payload/android/stages/memory_dump
            mpf memory_dump > set TARGET_PACKAGE jakhar.aseem.diva
            mpf memory_dump > set DUMP_TYPE heap
            mpf memory_dump > set OUTPUT_DIR ./dumps
            mpf memory_dump > run

          Tips
          ====
            • Use 'generate' to create payload without executing
            • Singles are easiest to use
            • Stages require stagers to be deployed first
            • Meterpreter provides interactive control
            • All payloads save results to reports/payload/

          ╔════════════════════════════════════════════════════════════════╗
          ║  Type 'back' to return to main menu                            ║
          ╚════════════════════════════════════════════════════════════════╝

        HELP
        puts format_help_visuals(help_text)
      end

      def format_help_visuals(text)
        # Apply vibrant ANSI styling to the help desk Output
        formatted = text.dup
        
        # Colorize main banners/borders
        formatted.gsub!(/^[║╔╚].*?[╗╝║]$/) { |m| "\e[38;5;51m#{m}\e[0m" }
        
        # Colorize Section Headers (Words followed by ====)
        formatted.gsub!(/^([A-Za-z0-9\s&\(\)]+)\n(={3,})$/) { |m| "\e[1m\e[38;5;82m#{$1}\e[0m\n\e[38;5;239m#{$2}\e[0m" }
        
        # Colorize key commands inside text (padding spaces + command string)
        formatted.gsub!(/^(\s{2,})([a-zA-Z0-9\-\_ ]{4,25})\s\s+(.*)$/) do |match|
          indent = $1
          cmd = $2.rstrip
          desc = $3
          
          # Avoid incorrectly highlighting list bullets
          if cmd.include?('•') || cmd.include?('Tips')
            match
          else
            "#{indent}\e[38;5;15m#{cmd.ljust(25)}\e[0m \e[38;5;245m#{desc}\e[0m"
          end
        end
        
        formatted
      end

      def use_module(module_path)
        return puts "[-] No module specified" unless module_path

        # Check if it's an exploit
        if module_path.start_with?('exploit/')
          exploit = @module_manager.instantiate_exploit(module_path)
          if exploit
            @current_module = exploit
            @current_payload = nil
            @prompt = "mpf #{module_path.split('/').last}"
            puts "[+] Loaded exploit: #{module_path}"
          else
            puts "[-] Failed to load exploit: #{module_path}"
          end
        # Check if it's a payload
        elsif module_path.start_with?('payload/')
          payload = @module_manager.instantiate_payload(module_path)
          if payload
            @current_payload = payload
            @current_module = nil
            @prompt = "mpf #{module_path.split('/').last}"
            puts "[+] Loaded payload: #{module_path}"
          else
            puts "[-] Failed to load payload: #{module_path}"
          end
        # Check if it's auxiliary
        elsif module_path == 'auxiliary/static_analysis'
          require_relative '../modules/static_analysis_v2'
          @current_module = MPF::Modules::StaticAnalysis.new
          @current_payload = nil
          @prompt = "mpf static_analysis"
          puts "[+] Loaded auxiliary: #{module_path}"
        elsif module_path == 'auxiliary/dynamic_analysis'
          require_relative '../modules/dynamic_analysis_v2'
          @current_module = MPF::Modules::DynamicAnalysis.new
          @current_payload = nil
          @prompt = "mpf dynamic_analysis"
          puts "[+] Loaded auxiliary: #{module_path}"
        elsif module_path == 'auxiliary/intel_analysis'
          require_relative '../modules/intel_analysis'
          @current_module = MPF::Modules::IntelAnalysis.new
          @current_payload = nil
          @prompt = "mpf intel_analysis"
          puts "[+] Loaded auxiliary: #{module_path}"
        else
          puts "[-] Unknown module: #{module_path}"
        end
      end

      def back_to_main
        @current_module = nil
        @current_payload = nil
        @prompt = "mpf"
        puts "[*] Back to main context"
      end

      def show_command(args)
        return puts "[-] No argument specified" unless args

        case args.downcase
        when 'exploits'
          show_exploits
        when 'payloads'
          show_payloads
        when 'auxiliary'
          show_auxiliary
        when 'options'
          show_options
        when 'targets'
          show_targets
        when 'all'
          show_all_modules
        when 'option'
          puts "[-] Did you mean 'show options'?"
          puts "Available: exploits, payloads, auxiliary, options, targets, all"
        else
          puts "[-] Unknown show option: #{args}"
          puts "Available: exploits, payloads, auxiliary, options, targets, all"
        end
      end

      def show_exploits
        exploits = @module_manager.list_modules(:exploits)
        
        puts "\nExploits"
        puts "========\n\n"
        
        if exploits.empty?
          puts "No exploits loaded"
        else
          exploits.each do |path, file|
            puts "  #{path}"
          end
        end
        puts
      end

      def show_payloads
        payloads = @module_manager.list_modules(:payloads)
        
        puts "\nPayloads"
        puts "========\n\n"
        
        # Group by type
        singles = payloads.select { |p, _| p.include?('/singles/') }
        stagers = payloads.select { |p, _| p.include?('/stagers/') }
        stages = payloads.select { |p, _| p.include?('/stages/') }
        meterpreter = payloads.select { |p, _| p.include?('/meterpreter/') }
        
        if singles.any?
          puts "Singles"
          puts "-------"
          singles.each { |path, _| puts "  #{path}" }
          puts
        end
        
        if stagers.any?
          puts "Stagers"
          puts "-------"
          stagers.each { |path, _| puts "  #{path}" }
          puts
        end
        
        if stages.any?
          puts "Stages"
          puts "-------"
          stages.each { |path, _| puts "  #{path}" }
          puts
        end
        
        if meterpreter.any?
          puts "Meterpreter"
          puts "-----------"
          meterpreter.each { |path, _| puts "  #{path}" }
          puts
        end
      end

      def show_auxiliary
        auxiliary = @module_manager.list_modules(:auxiliary)
        
        puts "\nAuxiliary Modules"
        puts "=================\n\n"
        
        auxiliary.each do |path, file|
          puts "  #{path}"
        end
        puts
      end

      def show_all_modules
        show_exploits
        show_payloads
        show_auxiliary
      end

      def show_options
        if @current_module && @current_module.respond_to?(:show_options)
          puts @current_module.show_options
        elsif @current_payload
          puts @current_payload.show_options
        else
          puts "[-] No module selected"
        end
      end

      def show_targets
        if @current_module && @current_module.respond_to?(:show_targets)
          puts @current_module.show_targets
        else
          puts "[-] Current module does not support targets"
        end
      end

      def show_info
        if @current_module && @current_module.respond_to?(:show_info)
          puts @current_module.show_info
        elsif @current_payload
          puts @current_payload.show_info
        else
          puts "[-] No module selected"
        end
      end

      def set_option(args)
        return puts "[-] Usage: set <option> <value>" unless args

        parts = args.split(/\s+/, 2)
        return puts "[-] Usage: set <option> <value>" unless parts.length == 2

        option, value = parts

        # Special handling for PAYLOAD option in exploits
        if option.upcase == 'PAYLOAD' && @current_module && defined?(MPF::Core::ExploitBase) && @current_module.is_a?(MPF::Core::ExploitBase)
          payload = @module_manager.instantiate_payload(value)
          if payload
            @current_module.set_payload(payload)
            puts "[+] PAYLOAD => #{value}"
          else
            puts "[-] Invalid payload: #{value}"
          end
          return
        end

        # Set option on current module
        if @current_module && @current_module.respond_to?(:set_option)
          if @current_module.set_option(option, value)
            puts "[+] #{option.upcase} => #{value}"
          else
            puts "[-] Unknown option: #{option}"
          end
        elsif @current_payload
          if @current_payload.set_option(option, value)
            puts "[+] #{option.upcase} => #{value}"
          else
            puts "[-] Unknown option: #{option}"
          end
        else
          puts "[-] No module selected"
        end
      end

      def unset_option(args)
        return puts "[-] Usage: unset <option>" unless args
        
        if @current_module && @current_module.respond_to?(:set_option)
          @current_module.set_option(args, nil)
          puts "[+] Unset #{args.upcase}"
        elsif @current_payload
          @current_payload.set_option(args, nil)
          puts "[+] Unset #{args.upcase}"
        else
          puts "[-] No module selected"
        end
      end

      def set_global_option(args)
        # For future implementation of global options
        puts "[*] Global options not yet implemented"
      end

      def search_modules(query)
        return puts "[-] Usage: search <term>" unless query

        # Parse search query for filters
        filters = parse_search_filters(query)
        
        results = @module_manager.search(filters[:term])
        
        # Apply filters
        if filters[:type]
          results = results.select { |r| r[:type].to_s == filters[:type] }
        end
        
        if filters[:platform]
          results = results.select { |r| r[:path].include?(filters[:platform]) }
        end
        
        if results.empty?
          puts "[-] No results found for: #{query}"
        else
          puts "\nMatching Modules"
          puts "================\n\n"
          
          # Group by type
          grouped = results.group_by { |r| r[:type] }
          
          grouped.each do |type, modules|
            puts "#{type.to_s.capitalize}:"
            puts "-" * 40
            modules.each do |result|
              # Try to get module info for severity/CVE display
              info = get_module_info_for_search(result[:path])
              
              output = "  #{result[:path]}"
              
              if info
                output += " [#{info[:severity]}]" if info[:severity]
                output += " (#{info[:cve]})" if info[:cve]
              end
              
              puts output
            end
            puts
          end
          
          puts "#{results.length} module(s) found"
        end
      end

      def parse_search_filters(query)
        filters = { term: query }
        
        # Extract type filter: type:exploit
        if query =~ /type:(\w+)/
          filters[:type] = $1
          filters[:term] = query.gsub(/type:\w+/, '').strip
        end
        
        # Extract platform filter: platform:android
        if query =~ /platform:(\w+)/
          filters[:platform] = $1
          filters[:term] = query.gsub(/platform:\w+/, '').strip
        end
        
        filters
      end

      def get_module_info_for_search(path)
        begin
          if path.start_with?('exploit/')
            exploit = @module_manager.instantiate_exploit(path)
            return nil unless exploit
            
            {
              severity: exploit.info[:privileged] ? 'privileged' : 'standard',
              cve: exploit.info[:references]&.find { |r| r.include?('CVE') }
            }
          elsif path.start_with?('payload/')
            payload = @module_manager.instantiate_payload(path)
            return nil unless payload
            
            {
              severity: payload.info[:severity],
              cve: nil
            }
          end
        rescue
          nil
        end
      end

      def check_exploit
        unless @current_module && defined?(MPF::Core::ExploitBase) && @current_module.is_a?(MPF::Core::ExploitBase)
          puts "[-] Current module is not an exploit"
          return
        end

        puts "[*] Checking if target is vulnerable..."
        result = @current_module.check

        if result[:vulnerable]
          puts "[+] Target appears to be VULNERABLE"
          puts "[*] Confidence: #{result[:confidence]}"
          puts "[*] Details: #{result[:details]}"
        else
          puts "[-] Target does not appear to be vulnerable"
          puts "[*] Details: #{result[:details]}"
        end
      end

      def run_exploit
        if @current_module && defined?(MPF::Core::ExploitBase) && @current_module.is_a?(MPF::Core::ExploitBase)
          puts "[*] Launching exploit..."
          result = @current_module.exploit
          
          if result[:success]
            puts "[+] Exploitation successful!"
            
            # Save results
            timestamp = Time.now.to_i
            report_file = "reports/exploit/exploit_#{timestamp}.json"
            File.write(report_file, JSON.pretty_generate(result))
            puts "[*] Results saved to: #{report_file}"
          else
            puts "[-] Exploitation failed"
            puts "[-] Error: #{result[:error]}" if result[:error]
          end
        elsif @current_payload
          puts "[*] Executing payload..."
          result = @current_payload.execute({})
          
          if result[:success]
            puts "[+] Payload executed successfully!"
            
            # Save results
            timestamp = Time.now.to_i
            report_file = "reports/payload/payload_#{timestamp}.json"
            File.write(report_file, JSON.pretty_generate(result))
            puts "[*] Results saved to: #{report_file}"
          else
            puts "[-] Payload execution failed"
            puts "[-] Error: #{result[:error]}" if result[:error]
          end
        elsif @current_module
          # Handle auxiliary modules
          puts "[*] Running module..."
          
          # Check if it's the new auxiliary base
          if @current_module.is_a?(MPF::Core::AuxiliaryBase)
            result = @current_module.run
          else
            # Legacy support for old module interface
            target = {
              apk: @current_module.instance_variable_get(:@options)['APK']&.[](:value)
            }
            result = @current_module.run(target)
          end
          
          timestamp = Time.now.to_i
          
          # Determine output directory based on module type
          module_class_name = @current_module.class.name
          if module_class_name.include?('StaticAnalysis')
            report_file = "reports/static/static_analysis_#{timestamp}.json"
          elsif module_class_name.include?('DynamicAnalysis')
            report_file = "reports/dynamic/dynamic_#{timestamp}.json"
          elsif module_class_name.include?('IntelAnalysis')
            report_file = "reports/intel/aux_intel_#{timestamp}.json"
          else
            report_file = "reports/auxiliary/auxiliary_#{timestamp}.json"
          end
          
          begin
            File.write(report_file, JSON.pretty_generate(result))
            puts "\e[38;5;82m"
            puts "   .-----------------------."
            puts "   |  MODULE EXECUTION OK  |"
            puts "   '-----------------------'\e[0m"
            
            puts "\e[38;5;82m[*]\e[0m #{result['summary']}" if result['summary']
            puts "\e[38;5;82m[*]\e[0m Results saved to: #{report_file}"
          rescue => e
            puts "\e[38;5;196m[-] Failed to save auxiliary report: #{e.message}\e[0m"
          end
        else
          puts "\e[38;5;196m[-] No module selected\e[0m"
        end
      end

      def generate_payload
        unless @current_payload
          puts "[-] No payload selected"
          return
        end

        puts "[*] Generating payload..."
        result = @current_payload.generate

        puts "[+] Payload generated successfully"
        puts "[*] Type: #{result[:type]}"
        puts "[*] Description: #{result[:description]}"
        
        if result[:command]
          puts "\nGenerated Command:"
          puts "==================\n"
          puts result[:command]
        end

        # Save to file
        timestamp = Time.now.to_i
        output_file = "reports/payload/generated_#{timestamp}.json"
        File.write(output_file, JSON.pretty_generate(result))
        puts "\n[*] Payload saved to: #{output_file}"
      end

      def show_sessions(args)
        puts "[*] No active sessions"
        puts "[*] Sessions feature coming soon"
      end

      def manage_workspace(args)
        puts "[*] Current workspace: default"
        puts "[*] Workspace management coming soon"
      end

      def auto_exploit(args)
        unless args
          puts "[-] Usage: auto <apk_path>"
          return
        end

        apk_path = args.strip
        unless File.exist?(apk_path)
          puts "[-] APK file not found: #{apk_path}"
          return
        end

        puts "\n" + "=" * 70
        puts "MPF AUTOMATED EXPLOITATION WORKFLOW"
        puts "=" * 70
        puts "[*] Target APK: #{apk_path}"
        puts "[*] Starting automated analysis and exploitation...\n"

        # Step 1: Static Analysis
        puts "\n[STEP 1] Static Analysis"
        puts "-" * 70
        
        static_module = MPF::Modules::StaticAnalysis.new
        static_module.set_option('APK', apk_path)
        static_result = static_module.run
        
        if static_result['findings']
          puts "[+] Found #{static_result['findings'].length} potential vulnerabilities"
          
          # Save static results
          timestamp = Time.now.to_i
          static_file = "reports/static/auto_static_#{timestamp}.json"
          File.write(static_file, JSON.pretty_generate(static_result))
          puts "[*] Static analysis saved to: #{static_file}"
        else
          puts "[-] Static analysis failed"
          return
        end

        # Step 2: Identify Exploitable Vulnerabilities
        puts "\n[STEP 2] Identifying Exploitable Vulnerabilities"
        puts "-" * 70
        
        exploitable = []
        
        static_result['findings'].each do |finding|
          case finding['id']
          when /exported_provider/
            exploitable << {
              type: 'exported_provider',
              exploit: 'exploit/android/exported_provider',
              payload: 'payload/android/singles/provider_query',
              component: finding['component']
            }
          when /exported_activity/
            exploitable << {
              type: 'exported_activity',
              exploit: 'exploit/android/exported_activity',
              payload: 'payload/android/singles/intent_injection',
              component: finding['component']
            }
          when /exported_receiver/
            exploitable << {
              type: 'exported_receiver',
              exploit: 'exploit/android/insecure_broadcast',
              payload: 'payload/android/singles/intent_injection',
              component: finding['component']
            }
          end
        end

        if exploitable.empty?
          puts "[-] No automatically exploitable vulnerabilities found"
          puts "[*] Manual analysis recommended"
          return
        end

        puts "[+] Found #{exploitable.length} exploitable vulnerability(ies)"
        exploitable.each_with_index do |vuln, idx|
          puts "    #{idx + 1}. #{vuln[:type]} - #{vuln[:component]}"
        end

        # Step 3: Automated Exploitation
        puts "\n[STEP 3] Automated Exploitation"
        puts "-" * 70
        
        package = static_result['evidence']['package']
        results = []

        exploitable.each_with_index do |vuln, idx|
          puts "\n[*] Exploiting vulnerability #{idx + 1}/#{exploitable.length}"
          puts "[*] Type: #{vuln[:type]}"
          puts "[*] Component: #{vuln[:component]}"
          
          # Load exploit
          exploit = @module_manager.instantiate_exploit(vuln[:exploit])
          next unless exploit

          # Load payload
          payload = @module_manager.instantiate_payload(vuln[:payload])
          next unless payload

          # Configure exploit
          exploit.set_option('TARGET_PACKAGE', package)
          
          case vuln[:type]
          when 'exported_provider'
            exploit.set_option('PROVIDER_AUTHORITY', vuln[:component])
            payload.set_option('PROVIDER_URI', "content://#{vuln[:component]}")
          when 'exported_activity'
            exploit.set_option('TARGET_ACTIVITY', vuln[:component])
            payload.set_option('TARGET_COMPONENT', vuln[:component])
          when 'exported_receiver'
            exploit.set_option('TARGET_RECEIVER', vuln[:component])
            payload.set_option('TARGET_COMPONENT', vuln[:component])
          end

          exploit.set_payload(payload)

          # Check vulnerability
          check_result = exploit.check
          
          if check_result[:vulnerable]
            puts "[+] Vulnerability confirmed!"
            
            # Exploit
            exploit_result = exploit.exploit
            
            if exploit_result[:success]
              puts "[+] Exploitation successful!"
              results << {
                vulnerability: vuln,
                check: check_result,
                exploit: exploit_result,
                success: true
              }
            else
              puts "[-] Exploitation failed"
              results << {
                vulnerability: vuln,
                check: check_result,
                success: false
              }
            end
          else
            puts "[-] Vulnerability check failed"
          end
        end

        # Step 4: Generate Report
        puts "\n[STEP 4] Generating Report"
        puts "-" * 70
        
        report = {
          apk: apk_path,
          package: package,
          timestamp: Time.now.iso8601,
          static_analysis: static_result,
          exploitable_vulnerabilities: exploitable.length,
          exploitation_results: results,
          successful_exploits: results.count { |r| r[:success] }
        }

        report_file = "reports/auto_exploit_#{timestamp}.json"
        File.write(report_file, JSON.pretty_generate(report))
        
        puts "[+] Automated exploitation complete"
        puts "[*] Report saved to: #{report_file}"
        puts "\n" + "=" * 70
        puts "SUMMARY"
        puts "=" * 70
        puts "Total Vulnerabilities: #{static_result['findings'].length}"
        puts "Exploitable: #{exploitable.length}"
        puts "Successfully Exploited: #{results.count { |r| r[:success] }}"
        puts "=" * 70
      end

      def handle_standards_command(args)
        if args.nil? || args.strip.empty?
          puts "Usage: standards <type>"
          puts "Available: owasp, mapping"
          return
        end

        cmd = args.strip
        case cmd.downcase
        when 'owasp'

          require_relative '../standards/owasp_mobile_top10'
          puts "\nOWASP Mobile Top 10 Assessment"
          puts "==============================\n\n"
          
          MPF::Standards::OWASPMobileTop10.all.each do |id, info|
            puts "#{id}: #{info[:name]} - #{info[:severity]}"
            puts "    #{info[:description]}"
            puts ""
          end
        when 'mapping'
           show_exploit_mapping
        else
          puts "[-] Unknown standard type: #{args}"
        end
      end

      def handle_about_command
        output = <<~ABOUT
        
          ╔════════════════════════════════════════════════════════════════╗
          ║           MPF - Mobile Security Validation Platform            ║
          ╚════════════════════════════════════════════════════════════════╝
          
          Research Positioning
          ====================
          MPF is designed as a modular, academic-grade security validation framework 
          that bridges the gap between automated scanning and manual penetration testing.
          
          Core Principles:
            1. Standards-Aligned: Strict adherence to OWASP Mobile Top 10 (2024).
            2. Non-Destructive: Emphasis on safe validation over aggressive exploitation.
            3. Analyst-in-the-Loop: Designed to augment human intelligence, not replace it.
            4. Reproducible: consistent environments via emulator integration.
            
          Architecture:
            • Core: Modular plugin system (Exploits, Payloads, Analysis)
            • Rules: Centralized, reusable detection logic (Rule Engine)
            • Compliance: quantifiable risk assessment (Compliance Engine)
            
          Version: 2.1.0-research
          License: MIT
          
        ABOUT
        puts output
      end

      def handle_coverage_command(args)
        if args.nil? || args.strip.empty? || args.downcase != 'owasp'
           puts "Usage: coverage owasp"
           return
        end

        puts "\nOWASP Mobile Top 10 Coverage Analysis"
        puts "=====================================\n\n"
        
        # Load registry to check rules
        require_relative '../analysis/rules/rule_registry'
        registry = MPF::Analysis::Rules::RuleRegistry.new
        
        rules = registry.all_rules
        covered_categories = rules.map(&:owasp_category).uniq.sort
        
        all_categories = ['M1', 'M2', 'M3', 'M4', 'M5', 'M6', 'M7', 'M8', 'M9', 'M10']
        missing_categories = all_categories - covered_categories
        
        puts "Fully Supported:    #{covered_categories.join(', ')}"
        puts "Partially Supported: #{['M2', 'M8'].join(', ')} (Manual/Pending)"
        puts "Missing:            #{missing_categories.empty? ? 'None' : missing_categories.join(', ')}"
        
        score = (covered_categories.length.to_f / 10.0) * 100
        puts "-" * 40
        puts "Coverage Score:     #{score.to_i}%"
        puts "\n"
      end

      def show_exploit_mapping
        puts "\nExploit Module -> OWASP Category Mapping"
        puts "========================================"
        puts format("%-35s | %-15s", "Exploit Module", "OWASP Category")
        puts "-" * 53
        
        mappings = {
          "exploit/android/exported_provider" => "M3",
          "exploit/android/exported_activity" => "M3",
          "exploit/android/exported_service"  => "M3",
          "exploit/android/insecure_broadcast" => "M3",
          "exploit/android/sql_injection"     => "M4",
          "exploit/android/path_traversal"    => "M4",
          "exploit/android/webview_rce"       => "M4",
          "exploit/android/deeplink_injection" => "M4",
          "exploit/android/insecure_webview"  => "M5"
        }
        
        mappings.each do |mod, cat|
           puts format("%-35s | %-15s", mod, cat)
        end
        puts "\n"
      end

      def handle_report_command(args)
        if args.nil? || args.strip.empty?
          puts "\n  ╔════════════════════════════════════════════════╗"
          puts "  ║         REPORT GENERATION COMMAND             ║"
          puts "  ╚════════════════════════════════════════════════╝\n"
          puts "  Usage: report <type> [--dry-run] [--preview] [<json_path>]"
          puts ""
          puts "  Types:     owasp          Generate OWASP compliance report"
          puts "             html           Generate interactive HTML dashboard"
          puts "             preview        Preview latest report without file I/O"
          puts ""
          puts "  Options:   --dry-run      Show what would be generated (no files written)"
          puts "             --preview      Display summary without opening browser"
          puts "             <json_path>    Use specific report JSON (optional)"
          puts "\n"
          return
        end

        parts = args.split(/\s+/)
        report_type = parts[0].downcase
        flags = parts[1..-1] || []
        dry_run = flags.include?('--dry-run')
        preview = flags.include?('--preview')
        custom_path = parts.find { |p| p.start_with?('reports/') || p.end_with?('.json') }

        case report_type
        when 'owasp'
          handle_owasp_report(dry_run, preview)
        when 'html'
          handle_html_report(custom_path, dry_run, preview)
        when 'preview'
          handle_report_preview
        else
          puts "[-] Unknown report type: #{report_type}"
          puts "[*] Available: owasp, html, preview"
        end
      end

      def handle_owasp_report(dry_run = false, preview = false)
        puts "[*] Generating OWASP Mobile Top 10 report..."

        latest_report = Dir.glob("reports/static/static_analysis_*.json").max_by { |f| File.mtime(f) }

        unless latest_report
          puts "[-] No static analysis reports found."
          puts "[*] Run: use auxiliary/static_analysis && run"
          return
        end

        require_relative '../compliance/compliance_engine'
        require_relative '../reporting/report_generator'

        engine = MPF::Compliance::ComplianceEngine.new
        engine.load_findings(latest_report)
        report_data = engine.assess(:owasp)
        report_text = MPF::Reporting::ReportGenerator.generate_owasp_text_report(report_data)

        if dry_run
          puts "[*] DRY-RUN MODE: Would generate report from #{File.basename(latest_report)}"
          puts "[*] Report size: ~#{report_text.size} bytes"
          puts "[*] Destination: reports/owasp_compliance_*.txt"
          return
        end

        puts report_text

        filename = "owasp_compliance_#{Time.now.to_i}.txt"
        path = File.join("reports", filename)
        File.write(path, report_text)
        puts "[+] Report saved to: #{path}"
      end

      def handle_html_report(custom_path = nil, dry_run = false, preview = false)
        puts "[*] Generating interactive HTML dashboard..."

        if custom_path
          json_path = custom_path
          unless File.exist?(json_path)
            puts "[-] File not found: #{json_path}"
            return
          end
        else
          static_files = Dir.glob("reports/static/static_analysis_*.json")
          intel_files = Dir.glob("reports/intel/intel_analysis_*.json")
          all_reports = static_files + intel_files
          json_path = all_reports.max_by { |f| File.mtime(f) }

          unless json_path
            puts "[-] No analysis reports found."
            puts "[*] Run: use auxiliary/static_analysis && run"
            puts "[*] Or:  use auxiliary/intel_analysis && run"
            return
          end
        end

        require 'json'
        report = JSON.parse(File.read(json_path))
        package = report['package'] || report.dig('evidence', 'package') || 'unknown'

        if dry_run
          puts "[*] DRY-RUN MODE: Would generate HTML report"
          puts "[*] Source: #{File.basename(json_path)}"
          puts "[*] Package: #{package}"
          puts "[*] Findings: #{(report['findings'] || []).size}"
          puts "[*] Destination: reports/html/<type>/#{package}/report.html"
          return
        end

        if preview
          require_relative '../reporting/report_manager'
          validation = MPF::Reporting::ReportManager.validate_report(json_path)
          if validation[:success]
            puts "[+] Report Preview Summary:"
            puts "    ID: #{validation[:summary][:id]}"
            puts "    Package: #{validation[:summary][:package]}"
            puts "    Findings: #{validation[:summary][:findings_total]}"
            puts "    By Severity: Critical=#{validation[:summary][:findings_by_severity]['critical']}, High=#{validation[:summary][:findings_by_severity]['high']}, Medium=#{validation[:summary][:findings_by_severity]['medium']}, Low=#{validation[:summary][:findings_by_severity]['low']}"
            puts "    OWASP Score: #{validation[:summary][:owasp_score]}%"
            puts "    Exploit Prob: #{validation[:summary][:exploit_probability]}%"
          else
            puts "[-] Preview failed: #{validation[:error]}"
          end
          return
        end

        require_relative '../reporting/report_manager'
        type_dir = json_path.include?('reports/intel/') ? 'intel' : 'static'
        result = MPF::Reporting::ReportManager.generate_reports(json_path, type_dir, package)

        if result[:success]
          puts "[+] HTML dashboard generated: #{result[:html_path]}"
          puts "[*] Open in browser: file://#{File.expand_path(result[:html_path])}"
        else
          puts "[-] HTML generation failed: #{result[:error]}"
        end
      end

      def handle_report_preview
        puts "[*] Fetching latest report summary..."

        all_reports = Dir.glob("reports/**/analysis_*.json") + Dir.glob("reports/**/*_analysis_*.json")
        latest = all_reports.max_by { |f| File.mtime(f) }

        unless latest
          puts "[-] No reports found in reports/ directory."
          return
        end

        begin
          report = JSON.parse(File.read(latest))
          findings = report['findings'] || []

          puts "\n╔════════════════════════════════════════════════╗"
          puts "║              REPORT PREVIEW                   ║"
          puts "╚════════════════════════════════════════════════╝"
          puts "File:     #{File.basename(latest)}"
          puts "Package:  #{report['package'] || 'unknown'}"
          puts "Time:     #{report['timestamp'] || 'unknown'}"
          puts ""
          puts "Findings by Severity:"
          sev_summary = { 'critical' => 0, 'high' => 0, 'medium' => 0, 'low' => 0 }
          findings.each do |f|
            sev = (f['severity'] || 'unknown').to_s.downcase
            sev_summary[sev] += 1 if sev_summary.key?(sev)
          end
          puts "  🔴 Critical: #{sev_summary['critical']}"
          puts "  🟠 High:     #{sev_summary['high']}"
          puts "  🟡 Medium:   #{sev_summary['medium']}"
          puts "  🔵 Low:      #{sev_summary['low']}"
          puts ""
          puts "OWASP Compliance: #{report.dig('owasp_compliance', 'compliance_score') || 'N/A'}%"
          puts "Risk Score:       #{report.dig('risk_summary', 'overall_risk') || 'N/A'}/10"
          puts "\n"
        rescue JSON::ParserError
          puts "[-] Invalid JSON in #{File.basename(latest)}"
        end
      end


      def print_owasp_report(report)
        puts "\n" + "="*50
        puts "OWASP MOBILE SECURITY SUMMARY"
        puts "="*50
        puts "Total Categories Assessed: #{report[:total_categories]}"
        puts "Categories Affected:       #{report[:categories_affected]}"
        puts "Critical Risks:            #{report[:critical_risks]}"
        puts "High Risks:                #{report[:high_risks]}"
        puts "Medium Risks:              #{report[:medium_risks]}"
        puts "Low Risks:                 #{report[:low_risks]}"
        puts "-"*50
        puts "Compliance Score:          #{report[:compliance_score]}%"
        puts "="*50 + "\n"
        
        report[:details].each do |id, detail|
          next if detail[:risk] == "NONE"
          
          puts "#{id}: #{detail[:name]} - #{detail[:risk]}"
          detail[:findings].each do |finding|
             puts "  - [#{finding['severity'].upcase}] #{finding['description']}"
             puts "    File: #{finding['component']}"
          end
          puts ""
        end
      end

      ##
      # Handle emulator commands
      ##
      def handle_emulator_command(args)
        return show_emulator_help unless args

        parts = args.split(/\s+/)
        subcommand = parts[0]&.downcase
        emulator_args = parts[1..-1]

        case subcommand
        when 'list'
          emulator_list
        when 'start'
          emulator_start(emulator_args[0])
        when 'stop'
          emulator_stop(emulator_args[0])
        when 'status'
          emulator_status(emulator_args[0])
        when 'snapshot'
          emulator_snapshot(emulator_args[0])
        when 'restore'
          emulator_restore(emulator_args[0], emulator_args[1])
        when 'reset'
          emulator_reset(emulator_args[0])
        when 'register'
          emulator_register(emulator_args)
        else
          puts "[-] Unknown emulator command: #{subcommand}"
          show_emulator_help
        end
      end

      def show_emulator_help
        puts <<~HELP

          ╔════════════════════════════════════════════════════════════════╗
          ║                    EMULATOR COMMANDS                           ║
          ╚════════════════════════════════════════════════════════════════╝

          Emulator Management
          ===================
            emulator list                    List all configured emulators
            emulator start <avd_name>        Start an emulator with AVD name
            emulator stop [name]             Stop emulator (active if no name)
            emulator status [name]           Show emulator status
            emulator snapshot <name>         Create snapshot of current state
            emulator restore <emu> <snap>    Restore from snapshot
            emulator reset [name]            Reset emulator to clean state

          Setup Instructions
          ==================
            Windows: See WINDOWS_EMULATOR_SETUP.md
            Other:   See ANDROID_SDK_SETUP.md

          Available AVDs
          ==============
        HELP

        # Try to list available AVDs
        begin
          if @emulator_manager && @emulator_manager.respond_to?(:list)
            emulators = @emulator_manager.list
            first_emulator = emulators.values.first
            
            if first_emulator && first_emulator[:config]
              # Try to get a QEMU instance to list AVDs
              require_relative '../emulator/qemu_android'
              qemu = MPF::Emulator::QemuAndroid.new('temp', {})
              avds = qemu.list_available_avds
              
              if avds.empty?
                puts "            No AVDs found. Create one using Android Studio Device Manager."
                puts "            See: WINDOWS_EMULATOR_SETUP.md for instructions"
              else
                avds.each do |avd|
                  puts "            • #{avd}"
                end
              end
            end
          end
        rescue => e
          puts "            Unable to list AVDs. Ensure Android SDK is configured."
        end

        puts <<~HELP

          Examples
          ========
            # List available AVDs
            mpf > emulator list

            # Start emulator (use actual AVD name)
            mpf > emulator start Pixel_5_API_30

            # Check status
            mpf > emulator status

            # Stop emulator
            mpf > emulator stop

          Integration with Modules
          ========================
            # Use with dynamic analysis
            mpf > emulator start Pixel_5_API_30
            mpf > use auxiliary/dynamic_analysis
            mpf > set APK target.apk
            mpf > set DEVICE emulator-5554
            mpf > run

        HELP
      end

      def emulator_list
        emulators = @emulator_manager.list

        if emulators.empty?
          puts "[-] No emulators configured"
          return
        end

        puts "\n╔════════════════════════════════════════════════════════════════╗"
        puts "║                    CONFIGURED EMULATORS                        ║"
        puts "╚════════════════════════════════════════════════════════════════╝\n"

        emulators.each do |name, status|
          state_color = case status[:state]
                       when :ready then "\e[32m"  # Green
                       when :booting then "\e[33m"  # Yellow
                       when :error then "\e[31m"  # Red
                       else "\e[90m"  # Gray
                       end

          state_text = status[:state].to_s.upcase
          puts "\n  #{name}"
          puts "  #{'-' * name.length}"
          puts "  State:      #{state_color}#{state_text}\e[0m"
          puts "  ADB Device: #{status[:adb_device_id] || 'N/A'}"
          puts "  Uptime:     #{status[:uptime] || 'N/A'}"
          puts "  API Level:  #{status[:config][:api_level]}"
          puts "  Arch:       #{status[:config][:arch]}"
          puts "  Memory:     #{status[:config][:memory]} MB"
        end

        puts "\n"
      end

      def emulator_start(name)
        unless name
          puts "[-] Usage: emulator start <avd_name>"
          puts "[-] Run 'emulator -list-avds' to see available AVDs"
          puts "[-] Or create AVD using Android Studio Device Manager"
          return
        end

        puts "[*] Starting emulator with AVD: #{name}"
        
        # Try to start with the given name as AVD name directly
        # Create a temporary QEMU instance with the AVD name
        require_relative '../emulator/qemu_android'
        emulator = MPF::Emulator::QemuAndroid.new(name, { avd_name: name })
        
        result = emulator.start

        if result[:success]
          puts "[+] #{result[:message]}"
          puts "[+] ADB Device: #{result[:adb_device_id]}" if result[:adb_device_id]
          
          # Store in manager
          @emulator_manager.instance_variable_get(:@emulators)[name] = emulator
          @emulator_manager.instance_variable_set(:@active_emulator, name)
        else
          puts "[-] #{result[:message]}"
          
          # Show helpful hints
          if result[:message].include?("Android SDK")
            puts "\n[*] Setup Instructions:"
            puts "    Windows: See WINDOWS_EMULATOR_SETUP.md"
            puts "    Other:   See ANDROID_SDK_SETUP.md"
          elsif result[:message].include?("AVD")
            puts "\n[*] To see available AVDs, run in terminal:"
            puts "    emulator -list-avds"
            puts "\n[*] To create AVD:"
            puts "    Windows: See WINDOWS_EMULATOR_SETUP.md"
            puts "    Other:   See ANDROID_SDK_SETUP.md"
          end
        end
      end

      def emulator_stop(name = nil)
        name ||= @emulator_manager.active_emulator

        unless name
          puts "[-] No emulator specified and no active emulator"
          return
        end

        puts "[*] Stopping emulator: #{name}"
        result = @emulator_manager.stop(name)

        if result[:success]
          puts "[+] #{result[:message]}"
        else
          puts "[-] #{result[:message]}"
        end
      end

      def emulator_status(name = nil)
        status = @emulator_manager.status(name)

        if status[:error]
          puts "[-] #{status[:error]}"
          return
        end

        puts "\n╔════════════════════════════════════════════════════════════════╗"
        puts "║                    EMULATOR STATUS                             ║"
        puts "╚════════════════════════════════════════════════════════════════╝\n"

        state_color = case status[:state]
                     when :ready then "\e[32m"
                     when :booting then "\e[33m"
                     when :error then "\e[31m"
                     else "\e[90m"
                     end

        puts "  Name:       #{status[:name]}"
        puts "  State:      #{state_color}#{status[:state].to_s.upcase}\e[0m"
        puts "  ADB Device: #{status[:adb_device_id] || 'N/A'}"
        puts "  Uptime:     #{status[:uptime] || 'N/A'}"
        puts "\n  Configuration:"
        puts "    API Level:  #{status[:config][:api_level]}"
        puts "    Arch:       #{status[:config][:arch]}"
        puts "    Memory:     #{status[:config][:memory]} MB"
        puts "    Headless:   #{status[:config][:headless]}"
        puts "\n"
      end

      def emulator_snapshot(snapshot_name)
        unless snapshot_name
          puts "[-] Usage: emulator snapshot <name>"
          return
        end

        puts "[*] Creating snapshot: #{snapshot_name}"
        result = @emulator_manager.snapshot(snapshot_name)

        if result[:success]
          puts "[+] #{result[:message]}"
        else
          puts "[-] #{result[:message]}"
        end
      end

      def emulator_restore(emulator_name, snapshot_name)
        unless emulator_name && snapshot_name
          puts "[-] Usage: emulator restore <emulator_name> <snapshot_name>"
          return
        end

        puts "[*] Restoring #{emulator_name} from snapshot: #{snapshot_name}"
        result = @emulator_manager.restore(emulator_name, snapshot_name)

        if result[:success]
          puts "[+] #{result[:message]}"
        else
          puts "[-] #{result[:message]}"
        end
      end

      def emulator_reset(name = nil)
        name ||= @emulator_manager.active_emulator

        unless name
          puts "[-] No emulator specified and no active emulator"
          return
        end

        puts "[*] Resetting emulator: #{name}"
        result = @emulator_manager.reset(name)

        if result[:success]
          puts "[+] #{result[:message]}"
        else
          puts "[-] #{result[:message]}"
        end
      end

      def emulator_register(args)
        if args.length < 2
          puts "[-] Usage: emulator register <name> <type> [config_options]"
          puts "[-] Example: emulator register my-emu qemu api_level=30 arch=x86_64"
          return
        end

        name = args[0]
        type = args[1].to_sym
        config = {}

        # Parse config options
        args[2..-1]&.each do |arg|
          key, value = arg.split('=')
          config[key.to_sym] = value if key && value
        end

        result = @emulator_manager.register(name, type, config)

        if result[:success]
          puts "[+] #{result[:message]}"
        else
          puts "[-] #{result[:message]}"
        end
      end
    end
  end
end

      ##
      # Handle attack-chain commands
      ##
      def handle_attack_chain_command(args)
        return show_attack_chain_help unless args

        parts = args.split(/\s+/)
        subcommand = parts[0]&.downcase

        case subcommand
        when 'generate'
          attack_chain_generate
        when 'load'
          attack_chain_load(parts[1])
        when 'export'
          attack_chain_export(parts[1])
        else
          puts "[-] Unknown attack-chain command: #{subcommand}"
          show_attack_chain_help
        end
      end

      def show_attack_chain_help
        puts <<~HELP

          ╔════════════════════════════════════════════════════════════════╗
          ║                    ATTACK CHAIN COMMANDS                       ║
          ╚════════════════════════════════════════════════════════════════╝

          Attack Chain Analysis
          =====================
            attack-chain generate           Generate attack chains from static analysis
            attack-chain load <file>        Load vulnerabilities from JSON file
            attack-chain export <file>      Export attack chains to JSON file

          Examples
          ========
            # Generate attack chains from latest static analysis
            mpf > attack-chain generate

            # Load vulnerabilities from specific file
            mpf > attack-chain load reports/static/analysis.json

            # Export attack chains
            mpf > attack-chain export attack_chains.json

          Academic Features
          =================
            • Component exposure correlation
            • Data access path analysis
            • Credential exposure detection
            • Misconfiguration impact assessment
            • OWASP Mobile Top 10 mapping
            • Explainable reasoning output

          Requirements
          ============
            • Static analysis results must be available
            • Works without emulator (static findings only)
            • Academic-focused explanations
            • Reproducible methodology

        HELP
      end

      def attack_chain_generate
        puts "\n[*] Initializing Attack Chain Reasoning Engine..."
        
        require_relative '../attack_chain_engine'
        
        # Find latest static analysis results
        static_files = Dir.glob('reports/static/**/static_analysis*.json') + 
                      Dir.glob('reports/intel/**/static_analysis*.json') +
                      Dir.glob('static_analysis.json')
        
        if static_files.empty?
          puts "[-] No static analysis results found"
          puts "[-] Run static analysis or intel analysis first"
          return
        end
        
        # Use the most recent file
        static_file = static_files.max_by { |f| File.mtime(f) }
        puts "[*] Loading static analysis results: #{static_file}"
        
        begin
          static_results = JSON.parse(File.read(static_file))
          findings = static_results['findings'] || []
          
          if findings.empty?
            puts "[-] No vulnerabilities found in static analysis results"
            return
          end
          
          # Initialize engine
          engine = MPF::AttackChainEngine.new
          
          puts "[*] Generating attack chains..."
          results = engine.analyze_attack_surface(findings)
          attack_chains = results[:attack_chains]
          
          if attack_chains.empty?
            puts "[-] No exploitable attack chains identified"
            puts "[*] This indicates good security posture for analyzed components"
            return
          end
          
          # Display attack chains
          puts "\n\e[38;5;51m" + "=" * 80
          puts " ⚡ ATTACK CHAIN ANALYSIS - INTELLIGENCE DEMONSTRATION"
          puts "=" * 80 + "\e[0m"
          
          attack_chains.each do |c|
            puts "\n[*] \e[38;5;82mChain:\e[0m #{c[:id]} (Risk: \e[38;5;196m#{c[:risk_score].upcase}\e[0m, Feasibility: \e[38;5;208m#{c[:feasibility].upcase}\e[0m)"
            c[:steps].each_with_index do |step, i|
               puts "  \e[38;5;245m[Step #{i+1}]\e[0m → #{step}"
            end
          end
          
          @loaded_attack_chains = results
          
          # Export results
          output_dir = File.dirname(static_file)
          export_file = File.join(output_dir, 'attack_chains.json')
          File.write(export_file, JSON.pretty_generate(results))
          
          puts "\n[+] Attack chain analysis completed successfully"
          puts "[+] Results exported to: #{export_file}"
          
        rescue JSON::ParserError => e
          puts "[-] Error parsing static analysis results: #{e.message}"
        rescue => e
          puts "[-] Error during attack chain generation: #{e.message}"
          puts e.backtrace if ENV['DEBUG']
        end
      end

      def attack_chain_load(file_path)
        unless file_path && File.exist?(file_path)
          puts "[-] Usage: attack-chain load <file_path>"
          return
        end
        
        puts "[*] Loading vulnerabilities from: #{file_path}"
        
        begin
          static_results = JSON.parse(File.read(file_path))
          findings = static_results['findings'] || []
          
          require_relative '../attack_chain_engine'
          engine = MPF::AttackChainEngine.new
          
          results = engine.analyze_attack_surface(findings)
          @loaded_attack_chains = results
          
          puts "[+] Loaded and correlated #{findings.length} findings into #{results[:attack_chains].length} logic chains"
          
        rescue JSON::ParserError => e
          puts "[-] Error parsing file: #{e.message}"
        rescue => e
          puts "[-] Error loading vulnerabilities: #{e.message}"
        end
      end

      def attack_chain_export(file_path)
        unless @loaded_attack_chains
          puts "[-] No attack chain data loaded"
          puts "[-] Run 'attack-chain generate' first"
          return
        end
        
        file_path ||= "reports/attack_chains/attack_chains_#{Time.now.to_i}.json"
        
        puts "[*] Exporting attack chains to: #{file_path}"
        File.write(file_path, JSON.pretty_generate(@loaded_attack_chains))
        puts "[+] Export successful"
      end