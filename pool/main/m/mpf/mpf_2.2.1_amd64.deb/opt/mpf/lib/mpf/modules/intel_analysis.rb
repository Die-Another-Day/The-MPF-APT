require_relative '../core/auxiliary_base'
require_relative '../analysis/static/analyzer'
require_relative '../intelligence/cvss_scorer'
require_relative '../intelligence/vulnerability_correlator'
require_relative '../intelligence/attack_graph'
require_relative '../intelligence/explainability_engine'
require_relative '../intelligence/payload_recommender'
require_relative '../compliance/compliance_engine'
require_relative '../reporting/report_manager'
require 'json'
require 'time'
require 'fileutils'

module MPF
  module Modules
    # Intelligence-driven analysis module
    # Combines static analysis with CVSS scoring, attack graph, correlation, and explainability
    class IntelAnalysis < MPF::Core::AuxiliaryBase

      def register_info
        @info = {
          name: 'MPF Intelligence Analysis Engine',
          module: 'auxiliary/intel_analysis',
          description: 'Full-spectrum intelligence analysis: static analysis + CVSS scoring + ' \
                       'attack graph + vulnerability correlation + explainability + payload recommendations.',
          authors: ['MPF Research Team']
        }
      end

      def register_options
        add_option('TARGET',     'Path to APK or IPA file',   required: false)
        add_option('APK',        'Path to APK file (legacy)', required: false)
        add_option('OUTPUT_DIR', 'Output directory',          default: 'reports/intel')
        add_option('WORKSPACE',  'Workspace directory',       default: 'workspace')
        add_option('VERBOSE',    'Show detailed output',      default: 'true')
      end

      def run(_target_info = {})
        target     = get_option('TARGET') || get_option('APK')
        output_dir = get_option('OUTPUT_DIR')
        workspace  = get_option('WORKSPACE')
        verbose    = get_option('VERBOSE') == 'true'

        return { 'summary' => 'No target file provided' } unless target
        return { 'summary' => "Target file not found: #{target}" } unless File.exist?(target)

        FileUtils.mkdir_p(output_dir)
        timestamp = Time.now.to_i

        # ── Phase 1: Static Analysis ──────────────────────────────────────────
        print_status('Phase 1/6: Running static analysis...')
        analyzer = MPF::Analysis::Static::Analyzer.new
        analyzer.set_option('TARGET', target)
        analyzer.set_option('APK', target)
        analyzer.set_option('OUTPUT_DIR', "#{output_dir}/static")
        analyzer.set_option('WORKSPACE', workspace)
        static_result = analyzer.run

        findings = static_result['findings'] || []
        print_good("Static analysis: #{findings.length} findings")

        # ── Phase 2: CVSS Scoring ─────────────────────────────────────────────
        scored_findings = animate_phase('Phase 2/6: Applying CVSS v3.1 + OWASP hybrid scoring') do
          findings.map do |f|
            fid = (f['id'] || f[:id]).to_s
            score_data = MPF::Intelligence::CVSSScorer.score(fid)
            f.merge(
              'cvss_score'    => score_data[:base_score],
              'hybrid_score'  => score_data[:hybrid_score],
              'cvss_severity' => score_data[:severity].to_s,
              'cvss_vector'   => score_data[:vector_string],
              'cvss_breakdown'=> score_data[:breakdown]
            )
          end
        end

        critical_count = scored_findings.count { |f| f['cvss_severity'] == 'critical' }
        high_count     = scored_findings.count { |f| f['cvss_severity'] == 'high' }
        print_good("CVSS scoring: #{critical_count} critical, #{high_count} high")

        # ── Phase 3: Explainability ───────────────────────────────────────────
        explained_findings = animate_phase('Phase 3/6: Generating explainability analysis') do
          MPF::Intelligence::ExplainabilityEngine.explain_all(scored_findings)
        end
        print_good("Explainability: #{explained_findings.length} findings explained")

        # ── Phase 4: Vulnerability Correlation ───────────────────────────────
        correlation_result = animate_phase('Phase 4/6: Correlating vulnerabilities') do
          correlator = MPF::Intelligence::VulnerabilityCorrelator.new(findings)
          correlator.correlate
        end
        print_good("Correlation: #{correlation_result[:total_compounds]} compound vulnerabilities found")
        if verbose && correlation_result[:total_compounds] > 0
          correlation_result[:compound_findings].each do |c|
            print_status("  [#{c[:severity].to_s.upcase}] #{c[:name]} (CVSS: #{c[:cvss_score]})")
          end
        end

        # ── Phase 5: Attack Graph ─────────────────────────────────────────────
        graph_result = animate_phase('Phase 5/6: Building attack graph') do
          graph = MPF::Intelligence::AttackGraph.new(findings)
          graph.analyze
        end
        print_good("Attack graph: #{graph_result[:active_paths].length} active attack paths")
        print_good("Exploitation probability: #{graph_result[:exploitation_probability]}%")
        if verbose
          graph_result[:active_paths].each do |path|
            print_status("  [#{path[:severity].to_s.upcase}] #{path[:name]} (score: #{path[:risk_score]})")
          end
        end

        # ── Phase 6: Payload Recommendations ─────────────────────────────────
        rec_result = animate_phase('Phase 6/6: Generating payload recommendations') do
          MPF::Intelligence::PayloadRecommender.recommend(findings)
        end
        print_good("Payload recommendations: #{rec_result[:total]} payloads recommended")
        if verbose && rec_result[:top_recommendation]
          top = rec_result[:top_recommendation]
          print_status("  Top: #{top[:payload]} (confidence: #{top[:confidence]}%)")
          print_status("  Reason: #{top[:reason]}")
        end

        # ── OWASP Compliance ──────────────────────────────────────────────────
        compliance_engine = MPF::Compliance::ComplianceEngine.new
        compliance_engine.load_findings(findings)
        compliance_report = compliance_engine.assess(:owasp)

        # ── Assemble Full Report ──────────────────────────────────────────────
        report = {
          'summary'          => 'MPF Intelligence Analysis Complete',
          'timestamp'        => Time.now.iso8601,
          'apk'              => apk,
          'package'          => static_result.dig('evidence', 'package'),
          'analysis_phases'  => 6,

          'findings_summary' => {
            'total'    => findings.length,
            'critical' => critical_count,
            'high'     => high_count,
            'medium'   => scored_findings.count { |f| f['cvss_severity'] == 'medium' },
            'low'      => scored_findings.count { |f| f['cvss_severity'] == 'low' }
          },

          'findings'         => explained_findings,

          'cvss_analysis'    => {
            'max_score'  => scored_findings.map { |f| f['hybrid_score'] || 0 }.max || 0,
            'avg_score'  => scored_findings.empty? ? 0 :
              (scored_findings.sum { |f| f['hybrid_score'] || 0 } / scored_findings.length).round(2),
            'distribution' => {
              'critical' => critical_count,
              'high'     => high_count,
              'medium'   => scored_findings.count { |f| f['cvss_severity'] == 'medium' },
              'low'      => scored_findings.count { |f| f['cvss_severity'] == 'low' }
            }
          },

          'correlation'      => correlation_result,
          'attack_graph'     => graph_result,
          'payload_recommendations' => rec_result,
          'owasp_compliance' => compliance_report,

          'risk_summary'     => {
            'overall_risk'             => graph_result.dig(:risk_propagation, :overall_risk),
            'overall_severity'         => graph_result.dig(:risk_propagation, :severity).to_s,
            'attack_surface_score'     => graph_result[:attack_surface_score],
            'exploitation_probability' => graph_result[:exploitation_probability],
            'compound_vulnerabilities' => correlation_result[:total_compounds],
            'critical_attack_paths'    => graph_result[:critical_paths]&.length || 0,
            'compliance_score'         => compliance_report[:compliance_score]
          }
        }

        # Save report
        report_file = File.join(output_dir, "intel_analysis_#{timestamp}.json")
        File.write(report_file, JSON.pretty_generate(report))

        # Print summary
        print_summary(report)
        MPF::Reporting::ReportManager.generate_reports(report_file, "intel", report['package'])
        print_good("Full report saved to: #{report_file}")

        report
      end

      private

      def print_summary(report)
        rs = report['risk_summary']
        puts "\n\e[38;5;82m" + '━' * 65 + "\e[0m"
        puts "\e[1m\e[38;5;51m ⚡ MPF INTELLIGENCE ANALYSIS SUMMARY \e[0m"
        puts "\e[38;5;82m" + '━' * 65 + "\e[0m"
        
        # Color formatted items
        format_stat = ->(label, value, is_warning = false, is_critical = false) do
          val_color = is_critical ? "\e[38;5;196m" : (is_warning ? "\e[38;5;208m" : "\e[38;5;82m")
          format("  \e[38;5;245m%-22s\e[0m %s%s\e[0m", label, val_color, value)
        end
        
        puts format_stat.call("Package:", report['package'])
        puts format_stat.call("Total Findings:", report['findings_summary']['total'], report['findings_summary']['total'] > 0)
        puts format_stat.call("Critical:", report['findings_summary']['critical'], false, report['findings_summary']['critical'] > 0)
        puts format_stat.call("High:", report['findings_summary']['high'], report['findings_summary']['high'] > 0)
        puts format_stat.call("Compound Vulns:", rs['compound_vulnerabilities'], rs['compound_vulnerabilities'] > 0)
        
        attack_paths = report.dig('attack_graph', :active_paths)&.length || 0
        puts format_stat.call("Attack Paths:", attack_paths, attack_paths > 0)
        puts format_stat.call("Critical Paths:", rs['critical_attack_paths'], false, rs['critical_attack_paths'] > 0)
        
        prob = rs['exploitation_probability']
        puts format_stat.call("Exploit Probability:", "#{prob}%", prob > 30, prob > 70)
        
        puts format_stat.call("Attack Surface Score:", "#{rs['attack_surface_score']}/10")
        
        overall_risk_val = "#{rs['overall_risk']}/10 (#{rs['overall_severity'].upcase})"
        puts format_stat.call("Overall Risk:", overall_risk_val, rs['overall_risk'] > 4.0, rs['overall_risk'] > 7.0)
        
        comp = rs['compliance_score'] || 0
        puts format_stat.call("OWASP Compliance:", "#{comp}/100", comp < 80, comp < 50)
        puts "\e[38;5;82m" + '━' * 65 + "\e[0m\n"
      end

      def print_status(msg) = puts("\e[38;5;245m[*]\e[0m \e[38;5;253m#{msg}\e[0m")
      def print_good(msg)   = puts("\e[38;5;82m[+]\e[0m \e[38;5;15m#{msg}\e[0m")
      def print_error(msg)  = puts("\e[38;5;196m[-]\e[0m \e[38;5;204m#{msg}\e[0m")

      def animate_phase(msg)
        print "\e[?25l"
        t = Thread.new do
          chars = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']
          i = 0
          loop do
            print "\r\e[38;5;82m[\e[38;5;51m#{chars[i % chars.length]}\e[38;5;82m]\e[0m \e[38;5;253m#{msg}...\e[0m"
            i += 1
            sleep 0.08
          end
        end
        result = yield if block_given?
        sleep(0.4) # Add tiny cinematic delay
        t.kill
        print "\r\e[K\e[?25h"
        result
      end
    end
  end
end
