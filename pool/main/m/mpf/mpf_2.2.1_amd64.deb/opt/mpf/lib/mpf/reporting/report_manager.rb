require 'json'
require 'fileutils'
require 'time'
require 'securerandom'
require_relative 'html_reporter'

module MPF
  module Reporting
    class ReportManager
      def self.generate_reports(json_path, type = 'analysis', app_name = nil)
        return { success: false, error: 'JSON file not found' } unless File.exist?(json_path)

        begin
          json_content = File.read(json_path)
          report = JSON.parse(json_content)
          package = app_name || report['package'] || report['evidence']&.dig('package') || 'unknown'

          html_base_dir = File.join('reports', 'html', type, package)
          FileUtils.mkdir_p(html_base_dir)

          enriched_report_path = File.join(html_base_dir, 'report_enriched.json')
          enriched_report = enrich_report(report, json_path, type, package)
          File.write(enriched_report_path, JSON.pretty_generate(enriched_report))

          html_reporter_path = HTMLReporter.generate(enriched_report_path, 'reports', package, type)

          unless html_reporter_path && File.exist?(html_reporter_path)
            return { success: false, error: 'HTML generation failed' }
          end

          print_good("[+] HTML report generated: #{html_reporter_path}")

          {
            success: true,
            json_path: json_path,
            html_path: html_reporter_path,
            enriched_json_path: enriched_report_path,
            package: package,
            type: type,
            html_url: File.join(html_base_dir, 'report.html')
          }
        rescue JSON::ParserError => e
          print_error("[-] Invalid JSON in #{json_path}: #{e.message}")
          { success: false, error: 'Invalid JSON format' }
        rescue => e
          print_error("[-] Report generation failed: #{e.message}")
          { success: false, error: e.message }
        end
      end

      def self.validate_report(json_path)
        return { success: false, error: 'JSON file not found' } unless File.exist?(json_path)

        begin
          report = JSON.parse(File.read(json_path))
          package = report['package'] || report['evidence']&.dig('package') || 'unknown'
          enriched_report = enrich_report(report, json_path, 'preview', package)
          { success: true, summary: build_summary(enriched_report) }
        rescue JSON::ParserError => e
          { success: false, error: "Invalid JSON format: #{e.message}" }
        rescue => e
          { success: false, error: e.message }
        end
      end

      def self.enrich_report(report, json_path, type, package)
        enriched = deep_copy(report)
        enriched['timestamp'] ||= Time.now.utc.iso8601
        enriched['scan_metadata'] ||= {}
        enriched['scan_metadata']['package'] ||= package
        enriched['scan_metadata']['type'] ||= type
        enriched['scan_metadata']['source_file'] ||= File.basename(json_path)
        enriched['scan_metadata']['generated_at'] ||= Time.now.utc.iso8601
        enriched['scan_metadata']['tool_version'] ||= 'MPF v2.1'
        enriched['platform'] ||= report['platform'] || (report['ipa'] ? 'ios' : 'android')
        enriched['scan_metadata']['platform'] ||= enriched['platform']

        enriched['id'] ||= "mpf-report-#{SecureRandom.hex(6)}"
        enriched['findings'] = Array(enriched['findings'])

        enriched['findings'].each_with_index do |finding, index|
          finding = finding || {}
          finding['id'] ||= finding['rule_id'] || "finding-#{index + 1}"
          finding['rule_id'] ||= finding['id']
          finding['confidence'] ||= infer_confidence(finding)
          finding['component'] ||= finding['component'] || finding['affected_component'] || finding['package'] || package
          finding['evidence_snippet'] ||= extract_evidence_snippet(finding)
          finding['owasp_category'] ||= finding['owasp'] || finding['category'] || finding['owasp_category'] || 'N/A'
          finding['severity'] ||= finding['cvss_severity'] || finding['risk'] || finding['severity'] || 'unknown'
          finding['description'] ||= 'Description unavailable'
          finding['execution_trace'] ||= finding['execution_trace'] || []
        end

        enriched['findings_summary'] ||= summary_from_findings(enriched['findings'])
        enriched['cvss_analysis'] ||= cvss_distribution(enriched['findings'])
        enriched['risk_summary'] ||= risk_overview(enriched['findings_summary'])
        enriched['payload_recommendations'] ||= enriched['payload_recommendations'] || { 'total' => 0, 'recommendations' => [] }
        enriched['attack_graph'] ||= enriched['attack_graph'] || { 'active_paths' => [] }
        enriched['owasp_compliance'] ||= enriched['owasp_compliance'] || { 'compliance_score' => 0 }

        enriched
      end

      def self.build_summary(report)
        {
          id: report['id'],
          package: report.dig('scan_metadata', 'package'),
          generated_at: report.dig('scan_metadata', 'generated_at'),
          findings_total: report.dig('findings_summary', 'total') || report['findings'].size,
          findings_by_severity: report['findings_summary'],
          owasp_score: report.dig('owasp_compliance', 'compliance_score'),
          overall_risk: report.dig('risk_summary', 'overall_risk'),
          exploit_probability: report.dig('risk_summary', 'exploitation_probability')
        }
      end

      def self.summary_from_findings(findings)
        summary = { 'total' => findings.size, 'critical' => 0, 'high' => 0, 'medium' => 0, 'low' => 0, 'none' => 0 }
        findings.each do |finding|
          severity = finding['severity'].to_s.downcase
          summary[severity] += 1 if summary.key?(severity)
        end
        summary
      end

      def self.cvss_distribution(findings)
        dist = { 'critical' => 0, 'high' => 0, 'medium' => 0, 'low' => 0 }
        findings.each do |finding|
          severity = finding['cvss_severity'] || finding['severity']
          key = severity.to_s.downcase
          dist[key] += 1 if dist.key?(key)
        end
        { 'distribution' => dist }
      end

      def self.risk_overview(summary)
        critical = summary['critical'] || 0
        high = summary['high'] || 0
        medium = summary['medium'] || 0
        low = summary['low'] || 0
        score = [10, critical * 4 + high * 3 + medium * 2 + low].min
        severity = if critical.positive?
                     'critical'
                   elsif high.positive?
                     'high'
                   elsif medium.positive?
                     'medium'
                   elsif low.positive?
                     'low'
                   else
                     'none'
                   end

        {
          'overall_risk' => score,
          'overall_severity' => severity,
          'exploitation_probability' => [100, critical * 18 + high * 12 + medium * 7 + low * 3].min
        }
      end

      def self.infer_confidence(finding)
        return finding['confidence'] if finding['confidence']

        severity = finding['severity'] || finding['cvss_severity']
        case severity.to_s.downcase
        when 'critical'
          95
        when 'high'
          80
        when 'medium'
          60
        when 'low'
          40
        else
          50
        end
      end

      def self.extract_evidence_snippet(finding)
        if finding['evidence'].is_a?(String)
          finding['evidence'].strip[0, 140]
        elsif finding['evidence'].is_a?(Array)
          finding['evidence'].first.to_s.strip[0, 140]
        elsif finding['details'].is_a?(String)
          finding['details'].strip[0, 140]
        else
          'Evidence summary unavailable.'
        end
      end

      def self.deep_copy(object)
        JSON.parse(JSON.generate(object))
      end

      private

      def self.print_good(msg)
        puts "[+] #{msg}"
      end

      def self.print_error(msg)
        puts "[-] #{msg}"
      end
    end
  end
end

