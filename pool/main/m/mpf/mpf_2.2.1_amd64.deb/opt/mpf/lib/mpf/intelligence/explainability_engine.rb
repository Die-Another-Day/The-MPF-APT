require_relative 'cvss_scorer'

module MPF
  module Intelligence
    # Explainability Engine: Generates human-readable explanations for every finding
    # Answers: "Why does this matter?", "What can an attacker do?", "How urgent is this?"
    class ExplainabilityEngine

      EXPLANATIONS = {
        'exported_provider_without_permission' => {
          why_matters: 'ContentProviders are the primary data access layer in Android. Without permission protection, ANY application installed on the device can query, insert, update, or delete data from this provider — no user interaction required.',
          attacker_can: [
            'Query the entire database without authentication',
            'Extract user credentials, session tokens, and PII',
            'Modify or delete application data',
            'Perform SQL injection if input is not sanitized',
            'Access files served by the provider'
          ],
          real_world_impact: 'A malicious app silently installed alongside this app can steal all user data in the background.',
          urgency: 'Fix immediately before production deployment.',
          fix_effort: 'Low — add android:permission attribute to provider declaration in AndroidManifest.xml'
        },
        'exported_activity_without_permission' => {
          why_matters: 'Exported Activities can be launched by any application or via ADB without user consent. This bypasses authentication flows and exposes internal application screens.',
          attacker_can: [
            'Launch sensitive screens directly (e.g., admin panels, payment screens)',
            'Bypass login screens by starting post-auth activities',
            'Inject malicious data via intent extras',
            'Trigger unintended application state transitions',
            'Perform tapjacking attacks on exposed UI'
          ],
          real_world_impact: 'Banking apps have been compromised by launching payment confirmation screens directly, bypassing PIN verification.',
          urgency: 'High priority — exploitable with a single ADB command.',
          fix_effort: 'Low — set android:exported="false" or add android:permission'
        },
        'debuggable_enabled' => {
          why_matters: 'The android:debuggable=true flag allows any process with ADB access to attach a Java debugger (JDWP) to the running application. This gives complete control over execution flow.',
          attacker_can: [
            'Attach debugger and pause execution at any point',
            'Read and modify all variables in memory',
            'Bypass certificate pinning by modifying return values',
            'Extract encryption keys from memory',
            'Dump the entire heap including sensitive data',
            'Modify authentication logic at runtime'
          ],
          real_world_impact: 'With debuggable=true, an attacker with physical device access can extract any secret the app holds, including OAuth tokens and private keys.',
          urgency: 'Critical for production builds — must be disabled before release.',
          fix_effort: 'Trivial — remove android:debuggable="true" from AndroidManifest.xml'
        },
        'allow_backup_enabled' => {
          why_matters: 'ADB backup allows extraction of the complete application data directory including databases, SharedPreferences, and files — without root access.',
          attacker_can: [
            'Extract complete application data via: adb backup -f app.ab com.target.app',
            'Recover stored passwords from SharedPreferences',
            'Access SQLite databases with all user data',
            'Restore modified data to manipulate app state',
            'Perform offline analysis of extracted data'
          ],
          real_world_impact: 'Physical access to an unlocked device is sufficient to extract all app data in under 30 seconds.',
          urgency: 'Medium — requires physical device access but no special tools.',
          fix_effort: 'Trivial — set android:allowBackup="false" in AndroidManifest.xml'
        },
        'sql_injection' => {
          why_matters: 'SQL injection in Android ContentProviders allows manipulation of database queries. Unlike web SQL injection, Android SQLite injection can affect the entire application database.',
          attacker_can: [
            'Bypass WHERE clause filters to access all records',
            'Use UNION SELECT to enumerate all tables',
            'Extract data from tables not intended to be accessible',
            'Modify or delete database records',
            'In some cases, read arbitrary files via SQLite functions'
          ],
          real_world_impact: 'DIVA (Damn Insecure and Vulnerable App) demonstrates this: the notes provider is fully dumpable via SQL injection.',
          urgency: 'Critical — automated tools can exploit this in seconds.',
          fix_effort: 'Medium — refactor queries to use parameterized selection args'
        },
        'webview_js_enabled' => {
          why_matters: 'JavaScript execution in WebView creates a bridge between web content and the Android application context. Combined with other WebView misconfigurations, this enables code execution.',
          attacker_can: [
            'Execute arbitrary JavaScript in the app context',
            'Access cookies and local storage',
            'Perform XSS attacks if content is user-controlled',
            'Exploit addJavascriptInterface if present',
            'Load malicious content via deep links'
          ],
          real_world_impact: 'JavaScript-enabled WebViews have been used to steal OAuth tokens from banking apps by injecting scripts into loaded pages.',
          urgency: 'High — especially dangerous when combined with addJavascriptInterface.',
          fix_effort: 'Medium — disable JS if not needed, or implement strict CSP'
        },
        'webview_add_js_interface' => {
          why_matters: 'addJavascriptInterface exposes Java objects to JavaScript running in WebView. On Android < 4.2, ALL public methods are accessible. On newer versions, only @JavascriptInterface annotated methods — but these can still be dangerous.',
          attacker_can: [
            'Call any exposed Java method from JavaScript',
            'Access Android filesystem through exposed methods',
            'Execute shell commands if exposed methods allow it',
            'Steal application data through Java bridge',
            'Achieve full RCE on Android < 4.2'
          ],
          real_world_impact: 'CVE-2012-6636: addJavascriptInterface allowed complete device compromise on Android < 4.2. Still dangerous on modern Android if exposed methods are powerful.',
          urgency: 'Critical — well-documented exploitation technique.',
          fix_effort: 'High — requires architectural review of WebView usage'
        },
        'cleartext_traffic_allowed' => {
          why_matters: 'Cleartext HTTP traffic can be intercepted by any network observer — ISPs, WiFi operators, or attackers on the same network. All data transmitted is visible in plaintext.',
          attacker_can: [
            'Passively capture all HTTP traffic',
            'Extract API keys, session tokens, and credentials',
            'Perform active MITM to inject malicious responses',
            'Modify API responses to manipulate app behavior',
            'Capture and replay authentication tokens'
          ],
          real_world_impact: 'Public WiFi networks are trivially exploitable. Any user on the same network can capture all app traffic.',
          urgency: 'High — especially for apps handling sensitive data.',
          fix_effort: 'Medium — migrate all endpoints to HTTPS, update Network Security Config'
        },
        'hardcoded_google_api_key' => {
          why_matters: 'API keys embedded in APK files are trivially extractable by decompiling the APK. Once extracted, they can be abused indefinitely until revoked.',
          attacker_can: [
            'Extract key via: apktool d app.apk && grep -r "AIza" .',
            'Abuse Google APIs at the app owner\'s expense',
            'Access Google services the key is authorized for',
            'Exhaust API quotas causing service disruption',
            'Access user data if key has broad permissions'
          ],
          real_world_impact: 'Thousands of apps on Google Play have had API keys extracted and abused, resulting in unexpected billing charges.',
          urgency: 'High — key is already exposed to anyone who downloads the APK.',
          fix_effort: 'Medium — move key to server-side, use key restrictions'
        },
        'hardcoded_aws_access_key' => {
          why_matters: 'AWS access keys provide programmatic access to cloud resources. Hardcoded keys in APKs are routinely scraped by automated tools scanning public app stores.',
          attacker_can: [
            'Access all AWS services the key is authorized for',
            'Read/write S3 buckets containing user data',
            'Launch EC2 instances for cryptomining',
            'Access RDS databases and DynamoDB tables',
            'Exfiltrate entire cloud infrastructure data',
            'Incur massive AWS charges'
          ],
          real_world_impact: 'Multiple companies have faced $50,000+ AWS bills within hours of publishing apps with hardcoded keys. Automated scanners find these within minutes of APK publication.',
          urgency: 'CRITICAL — rotate key immediately, then fix the code.',
          fix_effort: 'Medium — use IAM roles, AWS Cognito, or server-side key management'
        },
        'weak_algorithm_usage' => {
          why_matters: 'MD5 and SHA-1 are cryptographically broken. MD5 collisions can be computed in seconds. SHA-1 was broken in 2017 (SHAttered attack). Using these for password hashing or data integrity is dangerous.',
          attacker_can: [
            'Crack MD5 password hashes using rainbow tables in seconds',
            'Generate SHA-1 collisions to forge digital signatures',
            'Bypass integrity checks using collision attacks',
            'Recover original data from weak hashes offline'
          ],
          real_world_impact: 'LinkedIn\'s 2012 breach exposed 117M MD5 password hashes — 90% were cracked within days using GPU-accelerated tools.',
          urgency: 'High for password hashing, Medium for non-security-critical uses.',
          fix_effort: 'Low — replace with SHA-256, SHA-3, or bcrypt/Argon2 for passwords'
        },
        'ecb_mode_usage' => {
          why_matters: 'AES in ECB mode encrypts each block independently, producing identical ciphertext for identical plaintext blocks. This leaks data patterns and allows block manipulation attacks.',
          attacker_can: [
            'Detect patterns in encrypted data (e.g., repeated blocks)',
            'Perform block rearrangement attacks',
            'Decrypt data by analyzing ciphertext patterns',
            'Forge encrypted messages by rearranging blocks'
          ],
          real_world_impact: 'The "ECB penguin" demonstrates that ECB mode reveals image structure even when encrypted. The same applies to structured data like JSON.',
          urgency: 'High — replace with AES-GCM or AES-CBC with proper IV.',
          fix_effort: 'Low — change cipher mode to AES/GCM/NoPadding'
        },
        'world_readable_files' => {
          why_matters: 'Files created with MODE_WORLD_READABLE can be read by any application on the device without any permissions. This is deprecated since Android 7.0 but still dangerous on older devices.',
          attacker_can: [
            'Read application files from any other app',
            'Access SharedPreferences containing credentials',
            'Read cached data including session tokens',
            'Monitor file changes for sensitive data'
          ],
          real_world_impact: 'Any malicious app can silently read world-readable files in the background without triggering any permission dialogs.',
          urgency: 'High on Android < 7.0, Medium on newer versions.',
          fix_effort: 'Low — use MODE_PRIVATE (0) instead of MODE_WORLD_READABLE (1)'
        },
        'path_traversal' => {
          why_matters: 'Path traversal allows reading files outside the intended directory by using "../" sequences in file paths. In Android ContentProviders, this can expose the entire app sandbox.',
          attacker_can: [
            'Read arbitrary files: content://provider/../../../databases/app.db',
            'Access SQLite databases directly',
            'Read SharedPreferences XML files',
            'Access private keys and certificates',
            'Read any file the app has access to'
          ],
          real_world_impact: 'Multiple Android apps have been found vulnerable to path traversal via ContentProvider file:// URIs, exposing complete app databases.',
          urgency: 'Critical — single request can expose entire app data.',
          fix_effort: 'Medium — validate and canonicalize all file paths'
        },
        'root_detection_missing' => {
          why_matters: 'Without root detection, the app runs normally on rooted devices where an attacker has full system access. This enables Frida injection, SSL unpinning, and memory manipulation.',
          attacker_can: [
            'Inject Frida scripts to hook any method',
            'Bypass SSL certificate pinning',
            'Dump memory to extract encryption keys',
            'Modify app behavior at runtime',
            'Access app private directory as root'
          ],
          real_world_impact: 'Security researchers routinely bypass banking app protections on rooted devices using Frida in under 5 minutes.',
          urgency: 'Medium — important for high-security apps (banking, healthcare).',
          fix_effort: 'Medium — implement multi-layered root detection'
        },
        'pii_device_id' => {
          why_matters: 'Device identifiers (IMEI, Android ID) are persistent and cannot be changed by users. Collecting them without necessity violates GDPR and Google Play policies.',
          attacker_can: [
            'Track users across app reinstalls',
            'Build persistent device profiles',
            'Correlate user activity across services',
            'Violate user privacy without consent'
          ],
          real_world_impact: 'GDPR fines for unauthorized PII collection can reach €20M or 4% of global annual turnover.',
          urgency: 'Medium — legal and compliance risk.',
          fix_effort: 'Medium — replace with privacy-preserving alternatives (Advertising ID with opt-out)'
        },
        'dangerous_permissions_requested' => {
          why_matters: 'Dangerous permissions grant access to sensitive user data and device features. Requesting more permissions than necessary violates the principle of least privilege and increases attack surface.',
          attacker_can: [
            'If app is compromised, attacker inherits all granted permissions',
            'Access contacts, SMS, location, camera without additional exploitation',
            'Exfiltrate sensitive user data through compromised app'
          ],
          real_world_impact: 'Over-privileged apps are a primary vector for data exfiltration when combined with other vulnerabilities.',
          urgency: 'Medium — review and minimize permission requests.',
          fix_effort: 'Medium — audit and remove unnecessary permission requests'
        },
        'ios_nsuserdefaults_usage' => {
          why_matters: 'NSUserDefaults stores data in plaintext plist files on the device filesystem. Anyone with access to the device backup or container directories can read and modify this data.',
          attacker_can: [
            'Extract session tokens, user credentials, or PII in plaintext',
            'Tamper with flags to bypass premium locks or features',
            'Extract backend API configurations'
          ],
          real_world_impact: 'Plaintext configurations are readily inspectable via file extraction tools or simple backups.',
          urgency: 'Medium — keep sensitive data out of NSUserDefaults.',
          fix_effort: 'Medium — migrate credentials or tokens to Keychain Services'
        },
        'ios_exposed_sensitive_file' => {
          why_matters: 'Sensitive files (like sqlite databases, private certificates, or keys) packaged in the application bundle are accessible to anyone who extracts the IPA or inspects the app package.',
          attacker_can: [
            'Extract and analyze application database schemas and contents',
            'Reuse hardcoded certificate files to compromise communication',
            'Gain insight into server structures and private keys'
          ],
          real_world_impact: 'IPAs are zip archives; any resource packaged within can be extracted and read by anyone.',
          urgency: 'High — sensitive databases or private keys should never be packaged in app resources.',
          fix_effort: 'Medium — fetch config dynamically or generate keys/databases at runtime'
        },
        'ios_ats_disabled' => {
          why_matters: 'Disabling App Transport Security (ATS) globally allows the application to communicate over plaintext HTTP without TLS. This exposes all network communications to eavesdropping and manipulation.',
          attacker_can: [
            'Intercept and capture API traffic, session tokens, and credentials',
            'Perform Man-in-the-Middle (MITM) attacks to inject malicious API responses',
            'Downgrade transport security'
          ],
          real_world_impact: 'Users on insecure networks (like public WiFi) can have their entire app session hijacked.',
          urgency: 'High — ATS should remain enabled globally.',
          fix_effort: 'Low — remove NSAllowsArbitraryLoads=true or configure specific exceptions'
        },
        'ios_keychain_ksecattraccessiblealways' => {
          why_matters: 'kSecAttrAccessibleAlways allows Keychain items to be read even when the device is locked or rebooted before user passcode entry. This is deprecated and highly insecure.',
          attacker_can: [
            'Access Keychain secrets while device is locked or during background execution',
            'Read sensitive keys without user passcode validation'
          ],
          real_world_impact: 'If a device is lost or stolen, background processes or exploits could extract always-accessible keys.',
          urgency: 'High — do not use kSecAttrAccessibleAlways.',
          fix_effort: 'Low — migrate to kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly'
        },
        'ios_local_auth_bypass' => {
          why_matters: 'Unsafe implementation of LocalAuthentication (biometrics/passcodes) can allow bypasses if logic relies solely on client-side status values without keychain-backed ACL keys.',
          attacker_can: [
            'Bypass biometric screens by hooking evaluation callbacks with tools like Frida',
            'Access sensitive functions without physical presence verification'
          ],
          real_world_impact: 'Attackers can bypass app lock screens using runtime instrumentation tools.',
          urgency: 'High — ensure LocalAuthentication controls access to a keychain key.',
          fix_effort: 'Medium — secure authentication using Keychain ACLs bound to biometric state'
        },
        'ios_pie_disabled' => {
          why_matters: 'Without Position Independent Executable (PIE), the binary is loaded at a fixed memory address, disabling Address Space Layout Randomization (ASLR). This makes memory corruption exploits highly reliable.',
          attacker_can: [
            'Perform buffer overflow attacks with static return addresses',
            'Execute Return-Oriented Programming (ROP) chains'
          ],
          real_world_impact: 'Exploit payloads are significantly easier to construct when memory offsets are predictable.',
          urgency: 'High — PIE must be enabled for release binaries.',
          fix_effort: 'Low — enable PIE in Xcode build settings'
        },
        'ios_arc_disabled' => {
          why_matters: 'ARC automates memory management. Disabling it requires manual memory handling, which frequently leads to memory leaks, double frees, and Use-After-Free (UAF) vulnerabilities.',
          attacker_can: [
            'Exploit Use-After-Free vulnerabilities to execute arbitrary code',
            'Cause application crashes and Denial of Service'
          ],
          real_world_impact: 'Manual memory management is highly error-prone and a common source of critical memory bugs.',
          urgency: 'Medium — migrate project to ARC.',
          fix_effort: 'High — refactor manual memory blocks'
        },
        'ios_stack_canary_disabled' => {
          why_matters: 'Stack Canaries protect against stack-based buffer overflows by placing a guard value before the return pointer. If disabled, stack overflows can overwrite function pointers directly.',
          attacker_can: [
            'Corrupt memory structures and redirect execution flow',
            'Achieve remote code execution via stack overflows'
          ],
          real_world_impact: 'Memory corruption bugs are easily exploitable when canary protections are missing.',
          urgency: 'High — compile with stack smashing protector.',
          fix_effort: 'Low — add -fstack-protector-all compilation flag'
        },
        'ios_jailbreak_detection_missing' => {
          why_matters: 'Jailbroken environments allow root access, binary dumping, and runtime patching. Missing detection means the app will execute normally without attempting to protect its assets in an compromised state.',
          attacker_can: [
            'Attach debuggers and dump decrypted memory contents',
            'Hook Swift/Objective-C methods to alter app flow',
            'Bypass certificate pinning and SSL controls'
          ],
          real_world_impact: 'Reverse engineers can inspect, modify, and clone high-security applications with ease.',
          urgency: 'Medium — apply multi-layered checks for high-security applications.',
          fix_effort: 'Medium — implement checks for Cydia, files writeability, and system directory checks'
        }
      }.freeze

      def self.explain(finding)
        fid = (finding['id'] || finding[:id]).to_s
        exp = EXPLANATIONS[fid] || generate_generic_explanation(finding)
        finding.merge(
          'explanation' => {
            'why_matters'       => exp[:why_matters],
            'attacker_can'      => exp[:attacker_can],
            'real_world_impact' => exp[:real_world_impact],
            'urgency'           => exp[:urgency],
            'fix_effort'        => exp[:fix_effort]
          }
        )
      end

      def self.explain_all(findings)
        findings.map { |f| explain(f) }
      end

      def self.generate_generic_explanation(finding)
        severity = (finding['severity'] || finding[:severity]).to_s
        {
          why_matters: "This #{severity}-severity vulnerability was detected in the application. It represents a security weakness that could be exploited by an attacker with appropriate access.",
          attacker_can: [
            'Exploit this vulnerability to gain unauthorized access',
            'Use this as part of a larger attack chain',
            'Combine with other vulnerabilities for greater impact'
          ],
          real_world_impact: "#{severity.capitalize} severity vulnerabilities are actively exploited in real-world attacks against mobile applications.",
          urgency: severity == 'critical' ? 'Fix immediately.' : "Fix in next release cycle.",
          fix_effort: 'Review the specific component and apply security best practices.'
        }
      end
    end
  end
end
