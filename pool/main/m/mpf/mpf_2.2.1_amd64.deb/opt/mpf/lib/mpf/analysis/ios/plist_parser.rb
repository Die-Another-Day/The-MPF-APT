require 'rexml/document'
require 'time'

module MPF
  module Analysis
    module IOS
      class PlistParser
        def self.parse(path)
          return nil unless File.exist?(path)
          content = File.read(path, mode: 'rb')
          if content[0..7] == 'bplist00'
            BinaryPlistParser.new(content).parse
          else
            parse_xml(content)
          end
        rescue => e
          # If both fail, attempt basic regex string extraction as a fallback
          basic_regex_fallback(content)
        end

        private

        def self.parse_xml(content)
          doc = REXML::Document.new(content)
          root = doc.root.elements[1] # usually dict
          return {} unless root
          parse_xml_element(root)
        end

        def self.parse_xml_element(element)
          case element.name
          when 'dict'
            dict = {}
            current_key = nil
            element.elements.each do |child|
              if child.name == 'key'
                current_key = child.text&.strip
              elsif current_key
                dict[current_key] = parse_xml_element(child)
                current_key = nil
              end
            end
            dict
          when 'array'
            element.elements.map { |child| parse_xml_element(child) }
          when 'string'
            element.text || ''
          when 'integer'
            element.text.to_i
          when 'true'
            true
          when 'false'
            false
          when 'real'
            element.text.to_f
          when 'date'
            begin
              Time.parse(element.text)
            rescue
              element.text
            end
          else
            element.text || ''
          end
        end

        def self.basic_regex_fallback(content)
          # Strips visible strings from plist binary structure as a last resort
          strings = content.scan(/[[:print:]]{4,}/).map(&:strip)
          { "fallback_extracted_strings" => strings }
        end
      end

      # Pure Ruby Binary Plist (bplist00) Decoder
      class BinaryPlistParser
        def initialize(data)
          @data = data
        end

        def parse
          # Trailer is the last 32 bytes
          return nil if @data.size < 32
          trailer = @data[-32..-1]
          
          # Read trailer fields
          # offsetIntSize: 1 byte, objectRefSize: 1 byte, numObjects: 8 bytes, topObject: 8 bytes, offsetTableOffset: 8 bytes
          _, _, offset_int_size, object_ref_size, num_objects, top_object, offset_table_offset = 
            trailer.unpack('C5 C C Q> Q> Q>')

          # Read offset table
          @offsets = []
          num_objects.times do |i|
            offset_pos = offset_table_offset + (i * offset_int_size)
            offset_data = @data[offset_pos, offset_int_size]
            @offsets << read_int(offset_data)
          end

          @object_ref_size = object_ref_size
          @parsed_objects = {}
          
          # Parse top object recursively
          parse_object(top_object)
        end

        private

        def read_int(data)
          case data.size
          when 1 then data.unpack1('C')
          when 2 then data.unpack1('S>')
          when 4 then data.unpack1('L>')
          when 8 then data.unpack1('Q>')
          else
            # Fallback for odd sizes
            val = 0
            data.each_byte { |b| val = (val << 8) | b }
            val
          end
        end

        def parse_object(ref)
          return @parsed_objects[ref] if @parsed_objects.key?(ref)
          
          offset = @offsets[ref]
          return nil unless offset && offset < @data.size
          
          marker = @data[offset].ord
          type = marker & 0xF0
          info = marker & 0x0F
          
          result = nil
          
          case type
          when 0x00 # Simple types
            if marker == 0x08
              result = false
            elsif marker == 0x09
              result = true
            elsif marker == 0x00
              result = nil
            end
          when 0x10 # Integer
            length = 1 << info
            result = read_int(@data[offset + 1, length])
          when 0x20 # Real
            length = 1 << info
            if length == 4
              result = @data[offset + 1, 4].unpack1('g') # single precision float
            elsif length == 8
              result = @data[offset + 1, 8].unpack1('G') # double precision float
            end
          when 0x30 # Date
            # 8 byte double representation of seconds since 2001-01-01 00:00:00 UTC
            secs = @data[offset + 1, 8].unpack1('G')
            result = Time.utc(2001, 1, 1) + secs rescue secs
          when 0x40 # Data
            length, bytes_read = read_length(offset, info)
            result = @data[offset + 1 + bytes_read, length]
          when 0x50 # ASCII String
            length, bytes_read = read_length(offset, info)
            result = @data[offset + 1 + bytes_read, length]
          when 0x60 # UTF-16 BE String
            length, bytes_read = read_length(offset, info)
            utf16_str = @data[offset + 1 + bytes_read, length * 2]
            result = utf16_str.force_encoding('UTF-16BE').encode('UTF-8', invalid: :replace, undef: :replace)
          when 0x80 # UID
            length = info + 1
            result = read_int(@data[offset + 1, length])
          when 0xA0 # Array
            length, bytes_read = read_length(offset, info)
            refs = []
            length.times do |i|
              ref_offset = offset + 1 + bytes_read + (i * @object_ref_size)
              refs << read_int(@data[ref_offset, @object_ref_size])
            end
            # Prevent infinite recursion by caching early
            @parsed_objects[ref] = result = []
            refs.each { |r| result << parse_object(r) }
          when 0xD0 # Dictionary
            length, bytes_read = read_length(offset, info)
            keys = []
            vals = []
            length.times do |i|
              key_ref_offset = offset + 1 + bytes_read + (i * @object_ref_size)
              keys << read_int(@data[key_ref_offset, @object_ref_size])
              
              val_ref_offset = offset + 1 + bytes_read + ((length + i) * @object_ref_size)
              vals << read_int(@data[val_ref_offset, @object_ref_size])
            end
            
            # Cache container to handle cyclic references
            @parsed_objects[ref] = result = {}
            length.times do |i|
              k = parse_object(keys[i])
              v = parse_object(vals[i])
              result[k.to_s] = v if k
            end
          end
          
          @parsed_objects[ref] = result
        end

        def read_length(offset, info)
          if info == 0x0F
            # Next object is an integer containing the length
            next_marker = @data[offset + 1].ord
            next_info = next_marker & 0x0F
            len_bytes = 1 << next_info
            length = read_int(@data[offset + 2, len_bytes])
            [length, 1 + len_bytes]
          else
            [info, 0]
          end
        end
      end
    end
  end
end
