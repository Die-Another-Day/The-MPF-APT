require 'json'
require_relative '../standards/owasp_mobile_top10'

module MPF
  module Compliance
    class ComplianceEngine
      attr_reader :findings, :standards

      def initialize
        @findings = []
        @standards = {
          owasp: MPF::Standards::OWASPMobileTop10
        }
      end

      def load_findings(findings_input)
        if findings_input.is_a?(String) && File.exist?(findings_input)
          data = JSON.parse(File.read(findings_input))
          @findings += data['findings'] if data['findings']
        elsif findings_input.is_a?(Hash) && findings_input['findings']
          @findings += findings_input['findings']
        elsif findings_input.is_a?(Array)
          @findings += findings_input
        end
      end

      def assess(standard_key = :owasp)
        standard = @standards[standard_key]
        return unless standard

        report = {
          standard: standard_key.to_s.upcase,
          total_categories: standard.all.keys.length,
          categories_affected: 0,
          critical_risks: 0,
          high_risks: 0,
          medium_risks: 0,
          low_risks: 0,
          details: {}
        }

        standard.all.each do |id, info|
          mapped_findings = map_findings_to_category(id, info)
          
          risk_level = calculate_category_risk(mapped_findings)
          
          report[:details][id] = {
            name: info[:name],
            risk: risk_level,
            findings: mapped_findings
          }

          if risk_level != "NONE"
            report[:categories_affected] += 1
            case risk_level
            when "CRITICAL" then report[:critical_risks] += 1
            when "HIGH" then report[:high_risks] += 1
            when "MEDIUM" then report[:medium_risks] += 1
            when "LOW" then report[:low_risks] += 1
            end
          end
        end

        report[:compliance_score] = calculate_score(report)
        report
      end

      private

      def map_findings_to_category(id, info)
        category_findings = []
        
        @findings.each do |finding|
          # Priority: Check explicit 'owasp' key from Rule Engine
          if finding['owasp'] == id
            category_findings << finding
          # Fallback: Match by ID if 'owasp' key is missing (legacy support)
          elsif info[:detection_rules] && info[:detection_rules].include?(finding['id'])
            category_findings << finding
          end
        end

        category_findings
      end

      def calculate_category_risk(findings)
        return "NONE" if findings.empty?
        
        # Simple logic: highest severity finding dictates category risk
        severities = findings.map { |f| f['severity'].upcase }
        if severities.include?('CRITICAL')
          "CRITICAL"
        elsif severities.include?('HIGH')
          "HIGH"
        elsif severities.include?('MEDIUM')
          "MEDIUM"
        else
          "LOW"
        end
      end

      def calculate_score(report)
        # 100% - (penalty per affected category)
        # This is a simplified model
        base_score = 100.0
        penalty = 0

        report[:details].each do |id, detail|
          case detail[:risk]
          when "CRITICAL" then penalty += 15
          when "HIGH" then penalty += 10
          when "MEDIUM" then penalty += 5
          when "LOW" then penalty += 2
          end
        end

        [base_score - penalty, 0].max.round(2)
      end
    end
  end
end
