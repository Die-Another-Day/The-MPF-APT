require_relative 'base_rule'
require 'rexml/document'

module MPF
  module Analysis
    module Rules
      class M5NetworkSecurityRule < BaseRule
        def initialize
          super(
            id: 'M5-NETWORK-SECURITY',
            name: 'Insecure Communication',
            owasp_category: 'M5',
            severity: :high,
            description: 'Detection of cleartext traffic permission in Network Security Config or Manifest.',
            remediation: 'Ensure all network traffic uses TLS/SSL and disable cleartext traffic.',
            detection_logic: ->(context) { detect(context) }
          )
        end

        def detect(context)
          doc = context[:manifest_doc]
          decoded_dir = context[:decoded_dir]
          return [] unless doc && decoded_dir

          findings = []
          app = doc.root.elements["application"]
          return [] unless app

          ns_config = app.attributes["android:networkSecurityConfig"]

          if ns_config
            # Check Network Security Config file
            config_name = ns_config.split('/').last
            config_path = Dir.glob("#{decoded_dir}/res/xml/#{config_name}.xml").first

            if config_path && File.exist?(config_path)
              xml_content = BaseRule.safe_read(config_path)
              begin
                config_doc = REXML::Document.new(xml_content)
                base_config = config_doc.root.elements["base-config"]
                if base_config && base_config.attributes["cleartextTrafficPermitted"] == "true"
                  findings << {
                    id: "cleartext_traffic_allowed_nsc",
                    owasp: 'M5',
                    severity: :high,
                    description: "Network Security Config explicitly allows cleartext traffic (HTTP)",
                    component: "NetworkSecurityConfig (#{config_name}.xml)",
                    evidence: "cleartextTrafficPermitted=\"true\""
                  }
                end
              rescue => e
                # Parse error or otherwise
              end
            end
          else
            # Check manifest attribute usesCleartextTraffic
            if app.attributes["android:usesCleartextTraffic"] == "true"
              findings << {
                id: "cleartext_traffic_allowed_manifest",
                owasp: 'M5',
                severity: :high,
                description: "Manifest allows cleartext traffic globally",
                component: "AndroidManifest.xml",
                evidence: "android:usesCleartextTraffic=\"true\""
              }
            end
          end

          findings
        end
      end
    end
  end
end
