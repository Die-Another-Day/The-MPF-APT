module MPF
  module Analysis
    module Rules
      class BaseRule
        attr_reader :id, :name, :owasp_category, :severity, :description, :remediation

        def initialize(id:, name:, owasp_category:, severity:, description:, remediation:, detection_logic:)
          @id = id
          @name = name
          @owasp_category = owasp_category
          @severity = severity
          @description = description
          @remediation = remediation
          @detection_logic = detection_logic
        end

        def run(context)
          @detection_logic.call(context)
        end

        def to_h
          {
            id: @id,
            name: @name,
            owasp: @owasp_category,
            severity: @severity,
            description: @description,
            remediation: @remediation
          }
        end

        # Safe file reading with encoding handling — used by all rule subclasses
        def self.safe_read(file)
          File.read(file, mode: 'rb')
              .force_encoding('UTF-8')
              .encode('UTF-8', 'UTF-8', invalid: :replace, undef: :replace, replace: '')
        rescue
          ''
        end
      end
    end
  end
end
