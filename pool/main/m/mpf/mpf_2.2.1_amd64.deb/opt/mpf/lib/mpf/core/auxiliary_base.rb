module MPF
  module Core
    class AuxiliaryBase
      attr_reader :info, :options

      def initialize
        @info = {}
        @options = {}
        
        register_info
        register_options
      end

      # Must be implemented by auxiliary modules
      def register_info
        raise NotImplementedError, "Auxiliary must implement register_info"
      end

      def register_options
        # Override to add auxiliary-specific options
      end

      # Execute the auxiliary module
      def run(target_info = {})
        raise NotImplementedError, "Auxiliary must implement run"
      end

      # Set option value
      def set_option(key, value)
        key_sym = key.to_s.upcase.to_sym
        if @options.key?(key_sym)
          @options[key_sym][:value] = value
          true
        else
          false
        end
      end

      # Get option value
      def get_option(key)
        key_sym = key.to_s.upcase.to_sym
        @options[key_sym][:value] if @options.key?(key_sym)
      end

      # Display auxiliary information
      def show_info
        output = "\n"
        output += "Name: #{@info[:name]}\n"
        output += "Module: #{@info[:module]}\n"
        output += "Description:\n  #{@info[:description]}\n"
        output += "\nAuthor:\n"
        @info[:authors]&.each { |a| output += "  #{a}\n" }
        output
      end

      # Display auxiliary options
      def show_options
        return "No options available" if @options.empty?
        
        output = "\nModule Options:\n\n"
        output += sprintf("%-20s %-10s %-15s %s\n", "Name", "Required", "Current", "Description")
        output += "-" * 80 + "\n"
        
        @options.each do |key, opt|
          current = opt[:value] || opt[:default] || ""
          required = opt[:required] ? "yes" : "no"
          output += sprintf("%-20s %-10s %-15s %s\n", 
                           key.to_s, 
                           required, 
                           current.to_s[0..14], 
                           opt[:description])
        end
        
        output
      end

      protected

      def add_option(name, description, required: false, default: nil)
        @options[name.to_s.upcase.to_sym] = {
          description: description,
          required: required,
          default: default,
          value: default
        }
      end
    end
  end
end