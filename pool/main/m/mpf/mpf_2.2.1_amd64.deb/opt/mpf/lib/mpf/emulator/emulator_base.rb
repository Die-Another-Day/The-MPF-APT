# frozen_string_literal: true

module MPF
  module Emulator
    ##
    # Base class for all emulator providers
    # Defines the standard interface for emulator lifecycle management
    ##
    class EmulatorBase
      attr_reader :name, :config, :state, :adb_device_id

      # Emulator states
      STATE_STOPPED = :stopped
      STATE_STARTING = :starting
      STATE_BOOTING = :booting
      STATE_READY = :ready
      STATE_STOPPING = :stopping
      STATE_ERROR = :error

      def initialize(name, config = {})
        @name = name
        @config = default_config.merge(config)
        @state = STATE_STOPPED
        @adb_device_id = nil
        @start_time = nil
        @process_pid = nil
      end

      ##
      # Start the emulator instance
      # @return [Hash] Result with :success, :message, :adb_device_id
      ##
      def start
        raise NotImplementedError, "#{self.class} must implement #start"
      end

      ##
      # Stop the emulator instance
      # @return [Hash] Result with :success, :message
      ##
      def stop
        raise NotImplementedError, "#{self.class} must implement #stop"
      end

      ##
      # Get current emulator status
      # @return [Hash] Status information
      ##
      def status
        {
          name: @name,
          state: @state,
          adb_device_id: @adb_device_id,
          uptime: uptime,
          config: @config
        }
      end


      ##
      # Get ADB port for this emulator
      # @return [Integer, nil] Port number or nil if not running
      ##
      def adb_port
        return nil unless @adb_device_id
        @adb_device_id.split('-').last.to_i
      end

      ##
      # Create a snapshot of current emulator state
      # @param snapshot_name [String] Name for the snapshot
      # @return [Hash] Result with :success, :message
      ##
      def snapshot(snapshot_name)
        raise NotImplementedError, "#{self.class} must implement #snapshot"
      end

      ##
      # Restore emulator from a snapshot
      # @param snapshot_name [String] Name of snapshot to restore
      # @return [Hash] Result with :success, :message
      ##
      def restore(snapshot_name)
        raise NotImplementedError, "#{self.class} must implement #restore"
      end

      ##
      # Reset emulator to clean state
      # @return [Hash] Result with :success, :message
      ##
      def reset
        result = stop
        return result unless result[:success]
        
        # Clear data and restart
        start
      end

      ##
      # Wait for emulator to fully boot
      # @param timeout [Integer] Maximum wait time in seconds
      # @return [Boolean] True if booted successfully
      ##
      def wait_for_boot(timeout = 120)
        raise NotImplementedError, "#{self.class} must implement #wait_for_boot"
      end

      ##
      # Check if emulator is running
      # @return [Boolean]
      ##
      def running?
        @state == STATE_READY || @state == STATE_BOOTING
      end

      ##
      # Get emulator uptime
      # @return [String] Formatted uptime or nil
      ##
      def uptime
        return nil unless @start_time
        seconds = Time.now - @start_time
        format_duration(seconds)
      end

      protected

      ##
      # Default configuration for emulators
      ##
      def default_config
        {
          headless: true,
          memory: 2048,
          api_level: 30,
          arch: 'x86_64',
          auto_snapshot: true,
          boot_timeout: 120
        }
      end

      ##
      # Format duration in human-readable format
      ##
      def format_duration(seconds)
        minutes = (seconds / 60).to_i
        secs = (seconds % 60).to_i
        "#{minutes}m #{secs}s"
      end

      ##
      # Execute shell command with timeout
      ##
      def execute_command(command, timeout = 30)
        require 'open3'
        require 'timeout'

        output = ""
        error = ""
        status = nil

        begin
          Timeout.timeout(timeout) do
            output, error, status = Open3.capture3(command)
          end
        rescue Timeout::Error
          return { success: false, output: output, error: "Command timed out", status: nil }
        end

        {
          success: status.success?,
          output: output,
          error: error,
          status: status
        }
      end

      ##
      # Check if ADB is available
      ##
      def adb_available?
        result = execute_command('adb version', 5)
        result[:success]
      end
    end
  end
end
