require 'json'
require 'time'
require 'fileutils'
require 'zip'
require_relative 'plist_parser'
require_relative 'macho_inspector'
require_relative '../rules/rule_registry'

module MPF
  module Analysis
    module IOS
      class Analyzer
        def run(ipa, output_dir, workspace)
          print_status("Starting iOS static analysis...")
          print_status("Target IPA: #{ipa}")

          timestamp = Time.now.to_i
          workdir = "#{workspace}/static_ios_#{timestamp}"
          decoded_dir = "#{workdir}/decoded"

          FileUtils.mkdir_p(workdir)
          FileUtils.mkdir_p(output_dir)

          # 1. Extract IPA using Zip::File
          print_status("Extracting IPA archive...")
          begin
            Zip::File.open(ipa) do |zip|
              zip.each do |entry|
                next if entry.name.include?('..')
                dest_path = File.join(decoded_dir, entry.name)
                FileUtils.mkdir_p(File.dirname(dest_path))
                entry.extract(dest_path) { true } # overwrite
              end
            end
            print_good("IPA extracted successfully")
          rescue => e
            print_error("Failed to extract IPA: #{e.message}")
            return {
              "summary" => "IPA extraction failed",
              "error" => e.message
            }
          end

          findings = []
          evidence = {
            "platform" => "ios"
          }

          # 2. Locate App bundle inside Payload/
          app_dir = Dir.glob(File.join(decoded_dir, "Payload", "*.app")).first
          unless app_dir
            print_error("No .app bundle found in Payload/")
            return {
              "summary" => "No .app bundle found",
              "error" => "Malformed IPA structure"
            }
          end

          # Context for iOS rules
          context = {
            decoded_dir: decoded_dir,
            app_dir: app_dir,
            info_plist: {},
            entitlements: {},
            provisioning: {},
            binary_info: {},
            findings: findings
          }

          # 3. Parse Info.plist
          plist_path = File.join(app_dir, "Info.plist")
          if File.exist?(plist_path)
            print_status("Parsing Info.plist...")
            info_plist = PlistParser.parse(plist_path) || {}
            context[:info_plist] = info_plist

            # Populate metadata evidence
            bundle_id = info_plist['CFBundleIdentifier'] || 'unknown'
            evidence["package"] = bundle_id
            evidence["bundle_id"] = bundle_id
            evidence["bundle_name"] = info_plist['CFBundleName'] || info_plist['CFBundleDisplayName']
            evidence["version"] = info_plist['CFBundleShortVersionString'] || info_plist['CFBundleVersion']
            evidence["min_os"] = info_plist['MinimumOSVersion']
            print_good("Bundle ID: #{bundle_id}")

            # Parse URL Schemes
            url_schemes = []
            url_types = info_plist['CFBundleURLTypes']
            if url_types.is_a?(Array)
              url_types.each do |t|
                if t.is_a?(Hash) && t['CFBundleURLSchemes'].is_a?(Array)
                  url_schemes += t['CFBundleURLSchemes']
                end
              end
            end
            evidence["url_schemes"] = url_schemes
            print_status("URL Schemes: #{url_schemes.join(', ')}") if url_schemes.any?

            # Parse ATS Configuration
            ats = info_plist['NSAppTransportSecurity']
            evidence["ats"] = ats if ats

            # Parse Permissions (Privacy Descriptions)
            privacy_perms = {}
            info_plist.each do |k, v|
              if k.start_with?('NS') && k.end_with?('UsageDescription')
                privacy_perms[k] = v
              end
            end
            evidence["permissions"] = privacy_perms
          else
            print_error("Info.plist not found in app bundle")
            return {
              "summary" => "Info.plist not found"
            }
          end

          # 4. Parse Provisioning Profile & Entitlements
          prov_path = File.join(app_dir, "embedded.mobileprovision")
          if File.exist?(prov_path)
            print_status("Parsing embedded.mobileprovision...")
            begin
              prov_data = File.read(prov_path, mode: 'rb')
              if (start_idx = prov_data.index('<?xml')) && (end_idx = prov_data.index('</plist>'))
                plist_xml = prov_data[start_idx..end_idx + 7]
                prov_plist = PlistParser.parse_xml(plist_xml) || {}
                context[:provisioning] = prov_plist
                
                entitlements = prov_plist['Entitlements'] || {}
                context[:entitlements] = entitlements
                evidence["entitlements"] = entitlements
                print_good("Entitlements parsed successfully")
              end
            rescue => e
              print_error("Failed to parse provisioning profile: #{e.message}")
            end
          else
            print_status("embedded.mobileprovision not found (likely App Store build or simulator slice)")
          end

          # 5. Inspect executable binary
          exec_name = info_plist['CFBundleExecutable']
          binary_path = File.join(app_dir, exec_name) if exec_name
          if binary_path && File.exist?(binary_path)
            print_status("Inspecting executable binary: #{exec_name}...")
            bin_info = MachOInspector.inspect_binary(binary_path)
            context[:binary_info] = bin_info
            evidence["binary_info"] = bin_info
            print_good("Binary protections inspected")
          else
            print_error("Main executable binary not found")
          end

          # 6. Execute Rule Engine
          print_status("Executing OWASP iOS Rule Engine...")
          registry = MPF::Analysis::Rules::RuleRegistry.new
          
          # Run iOS rules from registry
          # We'll pass the platform info so registry filter works
          ios_rules = registry.all_rules.select { |r| r.id.to_s.start_with?('IOS-') || r.class.name.include?('IOS') }
          
          print_status("Found #{ios_rules.length} iOS rule(s) to execute.")
          ios_rules.each do |rule|
            print_status("Running rule: #{rule.name} (#{rule.owasp_category})")
            begin
              rule_findings = rule.run(context)
              findings.concat(rule_findings)
            rescue => e
              print_error("Rule #{rule.name} failed: #{e.message}")
              puts e.backtrace if ENV['DEBUG']
            end
          end

          # 7. Generate results
          result = {
            "summary" => "Static analysis completed",
            "timestamp" => Time.now.iso8601,
            "ipa" => ipa,
            "platform" => "ios",
            "package" => evidence["package"],
            "findings" => findings,
            "evidence" => evidence,
            "workspace" => workdir
          }

          # Save results
          output_file = File.join(output_dir, "static_analysis_#{timestamp}.json")
          File.write(output_file, JSON.pretty_generate(result))

          # Generate HTML using ReportManager
          MPF::Reporting::ReportManager.generate_reports(output_file, "static", evidence["package"])

          print_good("Static analysis complete")
          print_status("Findings: #{findings.length}")
          print_status("Results saved to: #{output_file}")

          result
        end

        private

        def print_status(msg)
          puts "[*] #{msg}"
        end

        def print_good(msg)
          puts "[+] #{msg}"
        end

        def print_error(msg)
          puts "[-] #{msg}"
        end
      end
    end
  end
end
