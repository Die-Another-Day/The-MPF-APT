require_relative '../../analysis/rules/base_rule'
require 'pathname'

module MPF
  module Analysis
    module Rules
      class M1SecretsRule < BaseRule
        def initialize
          super(
            id: 'M1-SECRETS',
            name: 'Improper Credential Usage',
            owasp_category: 'M1',
            severity: :high,
            description: 'Hardcoded secrets (API keys, private keys, tokens) found in the application code.',
            remediation: 'Store secrets in Android Keystore or retrieve them securely at runtime.',
            detection_logic: ->(context) { detect(context) }
          )
        end

        def detect(context)
          decoded_dir = context[:decoded_dir]
          findings = []

          patterns = {
            "google_api_key" => /AIza[0-9A-Za-z\\-_]{35}/,
            "aws_access_key" => /AKIA[0-9A-Z]{16}/,
            "firebase_url" => /https:\/\/.*\.firebaseio\.com/,
            "private_key" => /-----BEGIN PRIVATE KEY-----/,
            "generic_api_key" => /api_key\s*=\s*['"][a-zA-Z0-9\-_]{20,}['"]/i,
            "jwt_token" => /eyJ[a-zA-Z0-9\-_]+\.eyJ[a-zA-Z0-9\-_]+\.[a-zA-Z0-9\-_]+/
          }

          Dir.glob("#{decoded_dir}/**/*.{smali,xml,java,kt}") do |file|
            next if File.directory?(file)
            
            content = BaseRule.safe_read(file)
            next if content.empty?

            patterns.each do |id, regex|
              if content.match?(regex)
                relative_path = Pathname.new(file).relative_path_from(Pathname.new(decoded_dir)).to_s
                
                findings << {
                  id: "hardcoded_#{id}",
                  owasp: 'M1',
                  severity: :high,
                  description: "Potential hardcoded secret found: #{id}",
                  component: relative_path,
                  evidence: content.match(regex).to_s[0..50] + "..."
                }
              end
            end
          end

          findings
        end
      end
    end
  end
end
