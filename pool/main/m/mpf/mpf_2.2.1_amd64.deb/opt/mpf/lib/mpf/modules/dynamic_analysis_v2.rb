require_relative '../core/auxiliary_base'
require 'json'
require 'open3'
require 'time'

module MPF
  module Modules
    class DynamicAnalysis < MPF::Core::AuxiliaryBase

      def register_info
        @info = {
          name: 'Android Dynamic Analysis',
          module: 'auxiliary/dynamic_analysis',
          description: 'Performs runtime analysis of Android applications. ' \
                      'Installs APK, monitors behavior, captures network traffic, ' \
                      'analyzes SSL/TLS configuration, and tracks permission usage.',
          authors: ['MPF Research Team']
        }
      end

      def register_options
        add_option('APK', 'Path to APK file for analysis', required: true)
        add_option('PACKAGE', 'Application package name', required: true)
        add_option('DEVICE', 'Target device ID', default: 'emulator-5554')
        add_option('DURATION', 'Analysis duration in seconds', default: '60')
        add_option('OUTPUT_DIR', 'Output directory for results', default: 'reports/dynamic')
      end

      def run(target_info = {})
        apk = get_option('APK')
        package = get_option('PACKAGE')
        device = get_option('DEVICE')
        duration = get_option('DURATION').to_i
        output_dir = get_option('OUTPUT_DIR')

        unless apk
          return { "summary" => "No APK provided. Use: set APK <path>" }
        end

        unless File.exist?(apk)
          return { "summary" => "APK file not found: #{apk}" }
        end

        unless package
          return { "summary" => "No package name provided. Use: set PACKAGE <name>" }
        end

        # Check ADB availability
        unless system("adb version > /dev/null 2>&1")
          return {
            "summary" => "ADB not installed or not in PATH",
            "error" => "Install Android Debug Bridge (ADB) to perform dynamic analysis"
          }
        end

        print_status("Starting dynamic analysis...")
        print_status("Target APK: #{apk}")
        print_status("Package: #{package}")
        print_status("Device: #{device}")

        findings = []
        logs = []
        runtime_behaviors = []

        # 1. Install APK
        print_status("Installing APK...")
        install_output = `adb -s #{device} install -r "#{apk}" 2>&1`
        
        if $?.success?
          print_good("APK installed successfully")
        else
          print_error("APK installation failed")
          return {
            "summary" => "APK installation failed",
            "error" => install_output
          }
        end

        # 2. Clear logcat
        `adb -s #{device} logcat -c`

        # 3. Launch app
        print_status("Launching application...")
        launch_output = `adb -s #{device} shell monkey -p #{package} -c android.intent.category.LAUNCHER 1 2>&1`
        sleep(3)

        # 4. Perform automated testing
        print_status("Performing automated UI testing for #{duration} seconds...")
        monkey_output = `adb -s #{device} shell monkey -p #{package} --throttle 500 --pct-touch 70 --pct-motion 20 --pct-nav 10 -v #{duration * 2} 2>&1`
        
        # 5. Capture logcat
        print_status("Capturing runtime logs...")
        logcat_output = `adb -s #{device} logcat -d 2>&1`
        logs << logcat_output

        # 6. Analyze runtime behavior
        print_status("Analyzing runtime behavior...")
        
        # Check for crashes
        if logcat_output =~ /FATAL EXCEPTION|AndroidRuntime|crash/i
          findings << {
            "id" => "runtime_crash",
            "severity" => "high",
            "description" => "Application crash detected during testing",
            "evidence" => extract_crash_info(logcat_output)
          }
          runtime_behaviors << "Application crashed during automated testing"
        end

        # Check for security exceptions
        if logcat_output =~ /SecurityException|Permission denied/i
          findings << {
            "id" => "security_exception",
            "severity" => "medium",
            "description" => "Security exception detected",
            "evidence" => extract_security_exceptions(logcat_output)
          }
          runtime_behaviors << "Security exceptions encountered"
        end

        # Check for SQL injection indicators
        if logcat_output =~ /SQLiteException|SQL.*error|syntax error/i
          findings << {
            "id" => "sql_error",
            "severity" => "high",
            "description" => "Potential SQL injection vulnerability",
            "evidence" => extract_sql_errors(logcat_output)
          }
          runtime_behaviors << "SQL errors detected - possible injection point"
        end

        # Check for insecure data storage
        if logcat_output =~ /SharedPreferences|password|token|api[_-]?key/i
          findings << {
            "id" => "insecure_logging",
            "severity" => "medium",
            "description" => "Sensitive data logged to logcat",
            "evidence" => extract_sensitive_logs(logcat_output)
          }
          runtime_behaviors << "Sensitive data exposed in logs"
        end

        # Network traffic analysis
        network_analysis = analyze_network_traffic(device, package)
        findings.concat(network_analysis[:findings]) if network_analysis[:findings].any?

        # Runtime permission monitoring
        permission_analysis = analyze_runtime_permissions(device, package, logcat_output)
        findings.concat(permission_analysis[:findings]) if permission_analysis[:findings].any?

        # File system monitoring
        fs_analysis = analyze_file_system_access(device, package, logcat_output)
        findings.concat(fs_analysis[:findings]) if fs_analysis[:findings].any?

        # SSL/TLS analysis
        ssl_analysis = analyze_ssl_configuration(device, package, logcat_output)
        findings.concat(ssl_analysis[:findings]) if ssl_analysis[:findings].any?

        # 7. Enumerate runtime components
        print_status("Enumerating runtime components...")
        dumpsys_output = `adb -s #{device} shell dumpsys package #{package} 2>&1`
        
        # Extract activities
        activities = dumpsys_output.scan(/Activity.*?name=([^\s]+)/).flatten
        runtime_behaviors << "#{activities.length} activities detected" if activities.any?

        # Extract services
        services = dumpsys_output.scan(/Service.*?name=([^\s]+)/).flatten
        runtime_behaviors << "#{services.length} services detected" if services.any?

        # Extract receivers
        receivers = dumpsys_output.scan(/Receiver.*?name=([^\s]+)/).flatten
        runtime_behaviors << "#{receivers.length} broadcast receivers detected" if receivers.any?

        print_good("Dynamic analysis complete")

        # Generate results
        timestamp = Time.now.to_i
        result = {
          "summary"  => "Dynamic analysis completed",
          "timestamp" => Time.now.iso8601,
          "device"   => device,
          "package"  => package,
          "apk"      => apk,
          "duration" => duration,
          "findings" => findings,
          "runtime_behaviors" => runtime_behaviors,
          "components" => {
            "activities" => activities,
            "services" => services,
            "receivers" => receivers
          },
          "logs_captured" => logs.length
        }

        # Save results
        FileUtils.mkdir_p(output_dir)
        output_file = File.join(output_dir, "dynamic_analysis_#{timestamp}.json")
        File.write(output_file, JSON.pretty_generate(result))

        print_status("Findings: #{findings.length}")
        print_status("Runtime behaviors: #{runtime_behaviors.length}")
        print_status("Results saved to: #{output_file}")

        result
      end

      private

      def extract_crash_info(logcat)
        crashes = []
        logcat.lines.each_with_index do |line, idx|
          if line =~ /FATAL EXCEPTION|AndroidRuntime/
            crashes << logcat.lines[idx, 10].join
          end
        end
        crashes.first(3).join("\n---\n")
      end

      def extract_security_exceptions(logcat)
        exceptions = []
        logcat.lines.each do |line|
          if line =~ /SecurityException|Permission denied/
            exceptions << line.strip
          end
        end
        exceptions.first(5).join("\n")
      end

      def extract_sql_errors(logcat)
        errors = []
        logcat.lines.each do |line|
          if line =~ /SQLiteException|SQL.*error/i
            errors << line.strip
          end
        end
        errors.first(5).join("\n")
      end

      def extract_sensitive_logs(logcat)
        sensitive = []
        logcat.lines.each do |line|
          if line =~ /password|token|api[_-]?key|secret/i
            sensitive << line.strip
          end
        end
        sensitive.first(5).join("\n")
      end

      def analyze_network_traffic(device, package)
        findings = []
        
        # Check for network security config
        nsc_cmd = "adb -s #{device} shell dumpsys package #{package} | grep -i 'network.*security'"
        nsc_output = `#{nsc_cmd} 2>&1`

        if nsc_output.empty?
          findings << {
            "id" => "missing_network_security_config",
            "severity" => "medium",
            "description" => "No Network Security Configuration detected",
            "evidence" => "App may accept cleartext traffic"
          }
        end

        # Monitor active connections
        netstat_cmd = "adb -s #{device} shell netstat | grep #{package}"
        netstat_output = `#{netstat_cmd} 2>&1`

        if netstat_output.include?(':80 ') || netstat_output.include?(':8080 ')
          findings << {
            "id" => "cleartext_connections",
            "severity" => "high",
            "description" => "Cleartext HTTP connections detected",
            "evidence" => netstat_output.lines.first(3).join
          }
        end

        { findings: findings }
      end

      def analyze_runtime_permissions(device, package, logcat)
        findings = []

        dangerous_permissions = [
          'READ_CONTACTS', 'WRITE_CONTACTS',
          'READ_SMS', 'SEND_SMS', 'RECEIVE_SMS',
          'READ_CALL_LOG', 'WRITE_CALL_LOG',
          'CAMERA', 'RECORD_AUDIO',
          'ACCESS_FINE_LOCATION', 'ACCESS_COARSE_LOCATION',
          'READ_EXTERNAL_STORAGE', 'WRITE_EXTERNAL_STORAGE'
        ]

        dangerous_permissions.each do |perm|
          if logcat =~ /#{perm}.*granted/i
            findings << {
              "id" => "dangerous_permission_granted",
              "severity" => "medium",
              "description" => "Dangerous permission granted at runtime: #{perm}",
              "evidence" => "Permission #{perm} was granted during testing"
            }
          end
        end

        { findings: findings }
      end

      def analyze_file_system_access(device, package, logcat)
        findings = []

        # Check for world-readable/writable files
        if logcat =~ /MODE_WORLD_READABLE|MODE_WORLD_WRITABLE/i
          findings << {
            "id" => "world_accessible_files",
            "severity" => "high",
            "description" => "World-accessible file modes detected",
            "evidence" => "App uses MODE_WORLD_READABLE or MODE_WORLD_WRITABLE"
          }
        end

        # Check for external storage usage
        if logcat =~ /getExternalStorageDirectory|\/sdcard\//i
          findings << {
            "id" => "external_storage_usage",
            "severity" => "medium",
            "description" => "External storage usage detected",
            "evidence" => "App accesses external storage (world-readable)"
          }
        end

        { findings: findings }
      end

      def analyze_ssl_configuration(device, package, logcat)
        findings = []

        # Check for SSL errors being ignored
        if logcat =~ /onReceivedSslError.*proceed/i
          findings << {
            "id" => "ssl_bypass",
            "severity" => "critical",
            "description" => "SSL certificate validation bypass detected",
            "evidence" => "App ignores SSL certificate errors"
          }
        end

        # Check for custom TrustManager
        if logcat =~ /TrustManager|X509TrustManager/i
          if logcat =~ /checkServerTrusted.*return|checkClientTrusted.*return/i
            findings << {
              "id" => "custom_trust_manager",
              "severity" => "high",
              "description" => "Custom TrustManager that may bypass certificate validation",
              "evidence" => "App implements custom certificate validation"
            }
          end
        end

        { findings: findings }
      end

      def print_status(msg)
        puts "[*] #{msg}"
      end

      def print_good(msg)
        puts "[+] #{msg}"
      end

      def print_error(msg)
        puts "[-] #{msg}"
      end
    end
  end
end