require_relative 'module_base'
require 'json'
require 'open3'
require 'time'

module MPF
  class Dynamic < ModuleBase

    def run(target)
      apk = target[:apk]
      device = target[:device] || "emulator-5554"
      package = target[:package]

      return {"summary" => "APK not provided"} unless apk && File.exist?(apk)

      findings = []
      logs = []
      runtime_behaviors = []

      # Check ADB availability
      adb_exists = system("adb version > /dev/null 2>&1")

      unless adb_exists
        return {
          "summary" => "ADB not installed or not in PATH",
          "error" => "Install Android Debug Bridge (ADB) to perform dynamic analysis"
        }
      end

      print_status("Starting dynamic analysis...")
      print_status("Device: #{device}")

      # 1. Install APK
      print_status("Installing APK...")
      install_output = `adb -s #{device} install -r "#{apk}" 2>&1`
      
      if $?.success?
        print_good("APK installed successfully")
      else
        print_error("APK installation failed")
        return {
          "summary" => "APK installation failed",
          "error" => install_output
        }
      end

      # 2. Extract package name if not provided
      unless package
        package = extract_package_name(apk)
        return {"summary" => "Failed to extract package name"} unless package
      end

      print_status("Target package: #{package}")

      # 3. Clear logcat
      `adb -s #{device} logcat -c`

      # 4. Launch app
      print_status("Launching application...")
      launch_output = `adb -s #{device} shell monkey -p #{package} -c android.intent.category.LAUNCHER 1 2>&1`
      sleep(3)

      # 5. Perform automated testing
      print_status("Performing automated UI testing...")
      monkey_output = `adb -s #{device} shell monkey -p #{package} --throttle 500 --pct-touch 70 --pct-motion 20 --pct-nav 10 -v 100 2>&1`
      
      # 6. Capture logcat
      print_status("Capturing runtime logs...")
      logcat_output = `adb -s #{device} logcat -d 2>&1`
      logs << logcat_output

      # 7. Analyze runtime behavior
      print_status("Analyzing runtime behavior...")
      
      # Check for crashes
      if logcat_output =~ /FATAL EXCEPTION|AndroidRuntime|crash/i
        findings << {
          "id" => "runtime_crash",
          "severity" => "high",
          "description" => "Application crash detected during testing",
          "evidence" => extract_crash_info(logcat_output)
        }
        runtime_behaviors << "Application crashed during automated testing"
      end

      # Check for security exceptions
      if logcat_output =~ /SecurityException|Permission denied/i
        findings << {
          "id" => "security_exception",
          "severity" => "medium",
          "description" => "Security exception detected",
          "evidence" => extract_security_exceptions(logcat_output)
        }
        runtime_behaviors << "Security exceptions encountered"
      end

      # Check for SQL injection indicators
      if logcat_output =~ /SQLiteException|SQL.*error|syntax error/i
        findings << {
          "id" => "sql_error",
          "severity" => "high",
          "description" => "Potential SQL injection vulnerability",
          "evidence" => extract_sql_errors(logcat_output)
        }
        runtime_behaviors << "SQL errors detected - possible injection point"
      end

      # Check for insecure data storage
      if logcat_output =~ /SharedPreferences|password|token|api[_-]?key/i
        findings << {
          "id" => "insecure_logging",
          "severity" => "medium",
          "description" => "Sensitive data logged to logcat",
          "evidence" => extract_sensitive_logs(logcat_output)
        }
        runtime_behaviors << "Sensitive data exposed in logs"
      end

      # Check for network activity
      if logcat_output =~ /http:\/\/|HttpURLConnection|OkHttp/i
        findings << {
          "id" => "insecure_network",
          "severity" => "medium",
          "description" => "Insecure HTTP communication detected",
          "evidence" => extract_network_activity(logcat_output)
        }
        runtime_behaviors << "Insecure HTTP traffic detected"
      end

      # Check for WebView vulnerabilities
      if logcat_output =~ /WebView|addJavascriptInterface|loadUrl/i
        findings << {
          "id" => "webview_usage",
          "severity" => "medium",
          "description" => "WebView usage detected - potential XSS/RCE risk",
          "evidence" => extract_webview_usage(logcat_output)
        }
        runtime_behaviors << "WebView component in use"
      end

      # 8. Check for debuggable flag at runtime
      debuggable_check = `adb -s #{device} shell "run-as #{package} echo 'debuggable'" 2>&1`
      if $?.success?
        findings << {
          "id" => "runtime_debuggable",
          "severity" => "high",
          "description" => "Application is debuggable at runtime",
          "evidence" => "run-as command succeeded"
        }
        runtime_behaviors << "Application is debuggable"
      end

      # 9. Enumerate runtime components
      print_status("Enumerating runtime components...")
      dumpsys_output = `adb -s #{device} shell dumpsys package #{package} 2>&1`
      
      # Extract activities
      activities = dumpsys_output.scan(/Activity.*?name=([^\s]+)/).flatten
      runtime_behaviors << "#{activities.length} activities detected" if activities.any?

      # Extract services
      services = dumpsys_output.scan(/Service.*?name=([^\s]+)/).flatten
      runtime_behaviors << "#{services.length} services detected" if services.any?

      # Extract receivers
      receivers = dumpsys_output.scan(/Receiver.*?name=([^\s]+)/).flatten
      runtime_behaviors << "#{receivers.length} broadcast receivers detected" if receivers.any?

      # 10. Network traffic analysis
      print_status("Analyzing network traffic...")
      network_analysis = analyze_network_traffic(device, package)
      findings.concat(network_analysis[:findings]) if network_analysis[:findings].any?

      # 11. Runtime permission monitoring
      print_status("Monitoring runtime permissions...")
      permission_analysis = analyze_runtime_permissions(device, package, logcat_output)
      findings.concat(permission_analysis[:findings]) if permission_analysis[:findings].any?

      # 12. File system monitoring
      print_status("Monitoring file system access...")
      fs_analysis = analyze_file_system_access(device, package, logcat_output)
      findings.concat(fs_analysis[:findings]) if fs_analysis[:findings].any?

      # 13. SSL/TLS analysis
      print_status("Analyzing SSL/TLS configuration...")
      ssl_analysis = analyze_ssl_configuration(device, package, logcat_output)
      findings.concat(ssl_analysis[:findings]) if ssl_analysis[:findings].any?

      print_good("Dynamic analysis complete")

      {
        "summary"  => "Dynamic analysis completed",
        "device"   => device,
        "package"  => package,
        "apk"      => apk,
        "findings" => findings,
        "runtime_behaviors" => runtime_behaviors,
        "components" => {
          "activities" => activities,
          "services" => services,
          "receivers" => receivers
        },
        "logs_captured" => logs.length,
        "timestamp" => Time.now.iso8601
      }
    end

    private

    def extract_package_name(apk)
      output = `aapt dump badging "#{apk}" 2>&1 | grep package:`
      if output =~ /package: name='([^']+)'/
        $1
      else
        nil
      end
    end

    def extract_crash_info(logcat)
      crashes = []
      logcat.lines.each_with_index do |line, idx|
        if line =~ /FATAL EXCEPTION|AndroidRuntime/
          crashes << logcat.lines[idx, 10].join
        end
      end
      crashes.first(3).join("\n---\n")
    end

    def extract_security_exceptions(logcat)
      exceptions = []
      logcat.lines.each do |line|
        if line =~ /SecurityException|Permission denied/
          exceptions << line.strip
        end
      end
      exceptions.first(5).join("\n")
    end

    def extract_sql_errors(logcat)
      errors = []
      logcat.lines.each do |line|
        if line =~ /SQLiteException|SQL.*error/i
          errors << line.strip
        end
      end
      errors.first(5).join("\n")
    end

    def extract_sensitive_logs(logcat)
      sensitive = []
      logcat.lines.each do |line|
        if line =~ /password|token|api[_-]?key|secret/i
          sensitive << line.strip
        end
      end
      sensitive.first(5).join("\n")
    end

    def extract_network_activity(logcat)
      network = []
      logcat.lines.each do |line|
        if line =~ /http:\/\/[^\s]+/i
          network << line.strip
        end
      end
      network.first(5).join("\n")
    end

    def extract_webview_usage(logcat)
      webview = []
      logcat.lines.each do |line|
        if line =~ /WebView|addJavascriptInterface|loadUrl/i
          webview << line.strip
        end
      end
      webview.first(5).join("\n")
    end

    def print_status(msg)
      puts "[*] #{msg}"
    end

    def print_good(msg)
      puts "[+] #{msg}"
    end

    def print_error(msg)
      puts "[-] #{msg}"
    end

    def analyze_network_traffic(device, package)
      findings = []
      
      # Check for network security config
      nsc_cmd = "adb -s #{device} shell dumpsys package #{package} | grep -i 'network.*security'"
      nsc_output = `#{nsc_cmd} 2>&1`

      if nsc_output.empty?
        findings << {
          "id" => "missing_network_security_config",
          "severity" => "medium",
          "description" => "No Network Security Configuration detected",
          "evidence" => "App may accept cleartext traffic"
        }
      end

      # Monitor active connections
      netstat_cmd = "adb -s #{device} shell netstat | grep #{package}"
      netstat_output = `#{netstat_cmd} 2>&1`

      if netstat_output.include?(':80 ') || netstat_output.include?(':8080 ')
        findings << {
          "id" => "cleartext_connections",
          "severity" => "high",
          "description" => "Cleartext HTTP connections detected",
          "evidence" => netstat_output.lines.first(3).join
        }
      end

      { findings: findings }
    end

    def analyze_runtime_permissions(device, package, logcat)
      findings = []

      dangerous_permissions = [
        'READ_CONTACTS', 'WRITE_CONTACTS',
        'READ_SMS', 'SEND_SMS', 'RECEIVE_SMS',
        'READ_CALL_LOG', 'WRITE_CALL_LOG',
        'CAMERA', 'RECORD_AUDIO',
        'ACCESS_FINE_LOCATION', 'ACCESS_COARSE_LOCATION',
        'READ_EXTERNAL_STORAGE', 'WRITE_EXTERNAL_STORAGE'
      ]

      dangerous_permissions.each do |perm|
        if logcat =~ /#{perm}.*granted/i
          findings << {
            "id" => "dangerous_permission_granted",
            "severity" => "medium",
            "description" => "Dangerous permission granted at runtime: #{perm}",
            "evidence" => "Permission #{perm} was granted during testing"
          }
        elsif logcat =~ /#{perm}.*denied/i
          # Permission properly requested but denied - good
        end
      end

      { findings: findings }
    end

    def analyze_file_system_access(device, package, logcat)
      findings = []

      # Check for world-readable/writable files
      if logcat =~ /MODE_WORLD_READABLE|MODE_WORLD_WRITABLE/i
        findings << {
          "id" => "world_accessible_files",
          "severity" => "high",
          "description" => "World-accessible file modes detected",
          "evidence" => "App uses MODE_WORLD_READABLE or MODE_WORLD_WRITABLE"
        }
      end

      # Check for external storage usage
      if logcat =~ /getExternalStorageDirectory|\/sdcard\//i
        findings << {
          "id" => "external_storage_usage",
          "severity" => "medium",
          "description" => "External storage usage detected",
          "evidence" => "App accesses external storage (world-readable)"
        }
      end

      # Check for temp file creation
      if logcat =~ /createTempFile|\.tmp/i
        findings << {
          "id" => "temp_file_usage",
          "severity" => "low",
          "description" => "Temporary file creation detected",
          "evidence" => "App creates temporary files - ensure proper cleanup"
        }
      end

      { findings: findings }
    end

    def analyze_ssl_configuration(device, package, logcat)
      findings = []

      # Check for SSL errors being ignored
      if logcat =~ /onReceivedSslError.*proceed/i
        findings << {
          "id" => "ssl_bypass",
          "severity" => "critical",
          "description" => "SSL certificate validation bypass detected",
          "evidence" => "App ignores SSL certificate errors"
        }
      end

      # Check for custom TrustManager
      if logcat =~ /TrustManager|X509TrustManager/i
        if logcat =~ /checkServerTrusted.*return|checkClientTrusted.*return/i
          findings << {
            "id" => "custom_trust_manager",
            "severity" => "high",
            "description" => "Custom TrustManager that may bypass certificate validation",
            "evidence" => "App implements custom certificate validation"
          }
        end
      end

      # Check for hostname verification
      if logcat =~ /setHostnameVerifier.*ALLOW_ALL/i
        findings << {
          "id" => "hostname_verification_disabled",
          "severity" => "high",
          "description" => "Hostname verification disabled",
          "evidence" => "App allows all hostnames"
        }
      end

      { findings: findings }
    end
  end
end
