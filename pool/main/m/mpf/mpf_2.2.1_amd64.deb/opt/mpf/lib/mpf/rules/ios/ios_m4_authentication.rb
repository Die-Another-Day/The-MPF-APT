require_relative '../../analysis/rules/base_rule'
require 'pathname'

module MPF
  module Analysis
    module Rules
      class IOSM4AuthenticationRule < BaseRule
        def initialize
          super(
            id: 'IOS-M4-AUTHENTICATION',
            name: 'iOS Insecure Authentication and Session Management',
            owasp_category: 'M4',
            severity: :high,
            description: 'Checks for insecure Keychain accessibility parameters, basic auth headers, and local authentication weaknesses.',
            remediation: 'Use kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly or kSecAttrAccessibleWhenUnlocked. Enforce biometric authentication securely with proper error checks.',
            detection_logic: ->(context) { detect(context) }
          )
        end

        def detect(context)
          findings = []
          decoded_dir = context[:decoded_dir]
          return [] unless decoded_dir

          # 1. Deprecated / Insecure Keychain Accessibility Flags
          keychain_patterns = {
            "kSecAttrAccessibleAlways" => /kSecAttrAccessibleAlways/i,
            "kSecAttrAccessibleAlwaysThisDeviceOnly" => /kSecAttrAccessibleAlwaysThisDeviceOnly/i
          }

          # 2. Hardcoded Authentication Headers or credentials
          auth_patterns = {
            "hardcoded_basic_auth" => /Authorization.*Basic\s+[A-Za-z0-9+\/={4}]+/i,
            "insecure_lacontext" => /LAContext|evaluatePolicy/i
          }

          Dir.glob("#{decoded_dir}/**/*.{swift,m,h,json,txt}") do |file|
            next if File.directory?(file)
            content = BaseRule.safe_read(file)
            next if content.empty?

            relative_path = Pathname.new(file).relative_path_from(Pathname.new(decoded_dir)).to_s

            keychain_patterns.each do |id, regex|
              if content.match?(regex)
                findings << {
                  id: "ios_keychain_#{id.downcase}",
                  owasp: 'M4',
                  severity: :high,
                  description: "Use of deprecated and insecure Keychain accessibility attribute: #{id}",
                  component: relative_path,
                  evidence: content.match(regex).to_s,
                  confidence: 90
                }
              end
            end

            auth_patterns.each do |id, regex|
              if content.match?(regex)
                severity = id == "hardcoded_basic_auth" ? :high : :medium
                desc = id == "hardcoded_basic_auth" ? "Potential hardcoded Basic Authentication header found" : "Local authentication (LAContext) usage found. Verify that biometric/passcode access is properly enforced and not bypassable."
                findings << {
                  id: "ios_#{id}",
                  owasp: 'M4',
                  severity: severity,
                  description: desc,
                  component: relative_path,
                  evidence: content.match(regex).to_s[0..60] + "...",
                  confidence: 80
                }
              end
            end
          end

          findings
        end
      end
    end
  end
end
