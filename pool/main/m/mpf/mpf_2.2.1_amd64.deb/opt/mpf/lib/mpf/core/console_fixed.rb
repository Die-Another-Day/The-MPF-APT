require 'readline'
require 'json'
require 'fileutils'
require_relative 'module_manager'
require_relative 'exploit_base'
require_relative 'auxiliary_base'
require_relative '../modules/static_analysis_v2'
require_relative '../modules/dynamic_analysis_v2'
require_relative '../emulator/manager'
# Reports handled by unified ReportManager

module MPF
  module Core
    class Console
      attr_reader :current_module, :module_manager

      def initialize
        @module_manager = ModuleManager.new
        @emulator_manager = MPF::Emulator::Manager.new
        @current_module = nil
        @current_payload = nil
        @options = {}
        @prompt = "mpf"

        # Ensure report directories exist
        FileUtils.mkdir_p('reports/static')
        FileUtils.mkdir_p('reports/dynamic')
        FileUtils.mkdir_p('reports/exploit')
        FileUtils.mkdir_p('reports/payload')
        FileUtils.mkdir_p('reports/attack_chains')
      end

      def start
        display_banner
        puts "Type 'help' for main menu commands"
        puts "Type 'help auxiliary', 'help exploit', or 'help payload' for context-specific help"
        puts "Use TAB for auto-completion\n\n"

        # Setup tab completion
        setup_tab_completion

        while true
          begin
            input = Readline.readline("#{@prompt} > ", true)
            break if input.nil?
            
            next if input.strip.empty?
            
            handle_command(input.strip)
          rescue Interrupt
            puts "\nInterrupt: use 'exit' to quit"
          rescue => e
            puts "[-] Error: #{e.message}"
            puts e.backtrace.first(3) if ENV['DEBUG']
          end
        end

        puts "\nExiting MPF... Goodbye!"
      end

      def setup_tab_completion
        # Get all available modules
        all_modules = []
        all_modules += @module_manager.list_modules(:exploits).keys
        all_modules += @module_manager.list_modules(:payloads).keys
        all_modules += @module_manager.list_modules(:auxiliary).keys

        # Define completion proc
        comp = proc do |s|
          # Get the full line being typed
          line = Readline.line_buffer
          words = line.split(/\s+/)
          
          # Context-aware completion based on command
          case words[0]&.downcase
          when 'use'
            # Complete module paths
            if words.length == 1 || (words.length == 2 && !line.end_with?(' '))
              # User is typing: use <module>
              all_modules.grep(/^#{Regexp.escape(s)}/i)
            else
              []
            end
          # ... (rest of completion logic remains the same, omitted for brevity)
          else
            []
          end
        end

        Readline.completion_append_character = " "
        Readline.completion_proc = comp
      end

      # All other methods (get_available_commands, handle_command, show_help, etc.) remain the same...
      # The key fix is proper nesting of attack_chain methods INSIDE Console class

      # ... (complete file content with all methods properly nested)
      # Attack chain methods moved INSIDE Console class before 'end'

      def handle_attack_chain_command(args)
        return show_attack_chain_help unless args

        parts = args.split(/\s+/)
        subcommand = parts[0]&.downcase

        case subcommand
        when 'generate'
          attack_chain_generate
        when 'load'
          attack_chain_load(parts[1])
        when 'export'
          attack_chain_export(parts[1])
        else
          puts "[-] Unknown attack-chain command: #{subcommand}"
          show_attack_chain_help
        end
      end

      def show_attack_chain_help
        puts <<~HELP
          ╔════════════════════════════════════════════════════════════════╗
          ║                    ATTACK CHAIN COMMANDS                       ║
          ╚════════════════════════════════════════════════════════════════╝

          Attack Chain Analysis
          =====================
            attack-chain generate   Generate attack chains from static analysis
            attack-chain load       Load vulnerabilities from file
            attack-chain export     Export attack chains to JSON

        HELP
      end

      # ... other methods

    end # Console
  end # Core
end # MPF
