require_relative 'base_rule'
require 'pathname'

module MPF
  module Analysis
    module Rules
      class M7BinaryProtectionRule < BaseRule
        def initialize
          super(
            id: 'M7-BINARY-PROTECTION',
            name: 'Insufficient Binary Protections',
            owasp_category: 'M7',
            severity: :medium,
            description: 'Checks for presence of root detection and anti-debugging mechanisms.',
            remediation: 'Implement root detection, anti-debugging, and code obfuscation to impede tampering.',
            detection_logic: ->(context) { detect(context) }
          )
        end

        def detect(context)
          decoded_dir = context[:decoded_dir]
          return [] unless decoded_dir

          findings = []

          # Root Detection Checks
          root_indicators = [
            "test-keys",
            "/system/app/Superuser.apk",
            "/system/xbin/su",
            "RootTools"
          ]
          
          found_root_checks = false
          
          # Anti-Debugging Checks
          anti_debug_indicators = [
            "android.os.Debug.isDebuggerConnected",
            "android.os.Debug.waitForDebugger"
          ]
          
          found_anti_debug = false

          Dir.glob("#{decoded_dir}/**/*.{smali,java,kt}") do |file|
            content = BaseRule.safe_read(file)
            next if content.empty?

            root_indicators.each do |indicator|
              found_root_checks = true if content.include?(indicator)
            end
            
            anti_debug_indicators.each do |indicator|
              found_anti_debug = true if content.include?(indicator)
            end
          end
          
          unless found_root_checks
            findings << {
              id: "root_detection_missing",
              owasp: 'M7',
              severity: :medium,
              description: "No common root detection mechanisms found",
              component: "Application Logic",
              evidence: "Scanned for: #{root_indicators.join(', ')}"
            }
          end
          
          unless found_anti_debug
            findings << {
              id: "anti_debug_missing",
              owasp: 'M7',
              severity: :low,
              description: "No anti-debugging checks found",
              component: "Application Logic",
              evidence: "Scanned for: #{anti_debug_indicators.join(', ')}"
            }
          end

          findings
        end
      end
    end
  end
end
