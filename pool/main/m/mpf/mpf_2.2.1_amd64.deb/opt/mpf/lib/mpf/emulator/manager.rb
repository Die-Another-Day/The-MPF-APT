# frozen_string_literal: true

require_relative 'qemu_android'

module MPF
  module Emulator
    ##
    # Emulator Manager
    # Central orchestration for emulator lifecycle management
    ##
    class Manager
      attr_reader :emulators, :active_emulator

      def initialize
        @emulators = {}
        @active_emulator = nil
        load_emulator_configs
      end

      ##
      # List all configured emulators
      # @return [Hash] Emulator name => status
      ##
      def list
        @emulators.transform_values { |emu| emu.status }
      end

      ##
      # Start an emulator by name
      # @param name [String] Emulator name
      # @return [Hash] Result with :success, :message
      ##
      def start(name)
        emulator = @emulators[name]
        return { success: false, message: "Emulator '#{name}' not found" } unless emulator

        result = emulator.start
        @active_emulator = name if result[:success]
        result
      end

      ##
      # Stop an emulator by name
      # @param name [String] Emulator name (nil for active)
      # @return [Hash] Result with :success, :message
      ##
      def stop(name = nil)
        name ||= @active_emulator
        return { success: false, message: "No emulator specified or active" } unless name

        emulator = @emulators[name]
        return { success: false, message: "Emulator '#{name}' not found" } unless emulator

        result = emulator.stop
        @active_emulator = nil if name == @active_emulator
        result
      end

      ##
      # Get status of an emulator
      # @param name [String] Emulator name (nil for active)
      # @return [Hash] Status information
      ##
      def status(name = nil)
        name ||= @active_emulator
        return { error: "No emulator specified or active" } unless name

        emulator = @emulators[name]
        return { error: "Emulator '#{name}' not found" } unless emulator

        emulator.status
      end


      ##
      # Create snapshot of active emulator
      # @param snapshot_name [String] Snapshot name
      # @return [Hash] Result with :success, :message
      ##
      def snapshot(snapshot_name)
        return { success: false, message: "No active emulator" } unless @active_emulator

        emulator = @emulators[@active_emulator]
        emulator.snapshot(snapshot_name)
      end

      ##
      # Restore emulator from snapshot
      # @param name [String] Emulator name
      # @param snapshot_name [String] Snapshot name
      # @return [Hash] Result with :success, :message
      ##
      def restore(name, snapshot_name)
        emulator = @emulators[name]
        return { success: false, message: "Emulator '#{name}' not found" } unless emulator

        emulator.restore(snapshot_name)
      end

      ##
      # Reset emulator to clean state
      # @param name [String] Emulator name (nil for active)
      # @return [Hash] Result with :success, :message
      ##
      def reset(name = nil)
        name ||= @active_emulator
        return { success: false, message: "No emulator specified or active" } unless name

        emulator = @emulators[name]
        return { success: false, message: "Emulator '#{name}' not found" } unless emulator

        emulator.reset
      end

      ##
      # Register a new emulator
      # @param name [String] Emulator name
      # @param type [Symbol] Emulator type (:qemu, :genymotion, etc.)
      # @param config [Hash] Configuration options
      ##
      def register(name, type, config = {})
        emulator = case type
                   when :qemu
                     QemuAndroid.new(name, config)
                   else
                     raise ArgumentError, "Unknown emulator type: #{type}"
                   end

        @emulators[name] = emulator
        { success: true, message: "Emulator '#{name}' registered successfully" }
      end

      ##
      # Get ADB device ID for active emulator
      # @return [String, nil] ADB device ID
      ##
      def active_device_id
        return nil unless @active_emulator
        emulator = @emulators[@active_emulator]
        emulator&.adb_device_id
      end

      ##
      # Auto-start emulator if configured
      # @param config [Hash] Configuration with :emulator_name
      # @return [Hash] Result
      ##
      def auto_start(config)
        emulator_name = config[:emulator_name] || config[:emulator]
        return { success: false, message: "No emulator specified" } unless emulator_name

        # Check if already running
        emulator = @emulators[emulator_name]
        return { success: true, message: "Emulator already running", adb_device_id: emulator.adb_device_id } if emulator&.running?

        # Start emulator
        start(emulator_name)
      end

      ##
      # Stop all running emulators
      ##
      def stop_all
        results = []
        @emulators.each do |name, emulator|
          results << stop(name) if emulator.running?
        end
        results
      end

      private

      ##
      # Load emulator configurations from file or defaults
      ##
      def load_emulator_configs
        # Default QEMU configurations
        register('qemu-api30-x86', :qemu, {
          api_level: 30,
          arch: 'x86_64',
          memory: 2048,
          headless: true
        })

        register('qemu-api29-x86', :qemu, {
          api_level: 29,
          arch: 'x86_64',
          memory: 2048,
          headless: true
        })

        register('qemu-api30-arm', :qemu, {
          api_level: 30,
          arch: 'arm64-v8a',
          memory: 2048,
          headless: true
        })

        # Load custom configs if available
        load_custom_configs if File.exist?('config/emulators.yml')
      end

      ##
      # Load custom emulator configurations
      ##
      def load_custom_configs
        require 'yaml'
        config = YAML.load_file('config/emulators.yml')
        
        config['emulators']&.each do |name, settings|
          type = settings['type']&.to_sym || :qemu
          register(name, type, symbolize_keys(settings))
        end
      rescue => e
        puts "Warning: Failed to load custom emulator configs: #{e.message}"
      end

      ##
      # Convert string keys to symbols
      ##
      def symbolize_keys(hash)
        hash.transform_keys(&:to_sym)
      end
    end
  end
end
