require 'json'

module MPF
  module Core
    class ModuleManager
      attr_reader :modules

      def initialize
        @modules = {
          exploits: {},
          payloads: {},
          auxiliary: {}
        }
        
        load_all_modules
      end

      def load_all_modules
        # Load exploits
        load_exploits
        
        # Load payloads
        load_payloads
        
        # Load auxiliary modules
        load_auxiliary
      end

      def load_exploits
        exploit_files = Dir.glob('lib/mpf/exploits/**/*.rb')
        exploit_files.each do |file|
          begin
            # Just register the path, don't require yet
            relative_path = file.sub('lib/mpf/exploits/', '').sub('.rb', '')
            module_path = "exploit/#{relative_path}"
            
            @modules[:exploits][module_path] = file
          rescue => e
            # Skip files that can't be loaded
          end
        end
      end

      def load_payloads
        payload_files = Dir.glob('lib/mpf/payloads/**/*.rb')
        payload_files.each do |file|
          begin
            # Just register the path, don't require yet
            relative_path = file.sub('lib/mpf/payloads/', '').sub('.rb', '')
            # Normalize module path to match console expectation (payload/android/...) by removing 'singles|stagers|stages' prefixes.
            # Example: lib/mpf/payloads/singles/android/intent_injection.rb => payload/android/singles/intent_injection
            parts = relative_path.split('/')
            if parts.length >= 3 && ['singles', 'stagers', 'stages', 'meterpreter'].include?(parts[0])
              type = parts[0]
              platform = parts[1]
              rest = parts[2..].join('/')
              module_path = "payload/#{platform}/#{type}/#{rest}"
            else
              module_path = "payload/#{relative_path}"
            end
            
            @modules[:payloads][module_path] = file

          rescue => e
            # Skip files that can't be loaded
          end
        end
      end

      def load_auxiliary
        # Load static analysis
        @modules[:auxiliary]['auxiliary/static_analysis'] = 'lib/mpf/modules/static_analysis.rb'
        # Load dynamic analysis
@modules[:auxiliary]['auxiliary/dynamic_analysis'] = 'lib/mpf/modules/dynamic.rb'
        @modules[:auxiliary]['auxiliary/intel_analysis'] = 'lib/mpf/modules/intel_analysis.rb'
      end

      def search(query)
        results = []
        
        @modules.each do |type, modules|
          modules.each do |path, file|
            if path.downcase.include?(query.downcase)
              results << {
                type: type,
                path: path,
                file: file
              }
            end
          end
        end
        
        results
      end

      def get_module(path)
        type = path.split('/').first.to_sym
        @modules[type]&.[](path)
      end

      def list_modules(type = nil)
        if type
          @modules[type.to_sym] || {}
        else
          @modules
        end
      end

      def instantiate_exploit(path)
        return nil unless @modules[:exploits][path]
        
        # Load the file with absolute path
        file_path = File.expand_path(@modules[:exploits][path])
        require file_path
        
        # Convert path to class name
        # exploit/android/exported_provider -> MPF::Exploits::Android::ExportedProvider
        parts = path.split('/')[1..-1]
        class_name = parts.map { |p| p.split('_').map(&:capitalize).join }.join('::')
        full_class = "MPF::Exploits::#{class_name}"
        
        begin
          Object.const_get(full_class).new
        rescue NameError => e
          puts "[DEBUG] Failed to instantiate: #{full_class}" if ENV['DEBUG']
          nil
        end
      end

      def instantiate_payload(path)
        return nil unless @modules[:payloads][path]
        
        # Load the file with absolute path
        file_path = File.expand_path(@modules[:payloads][path])
          require file_path

          # Convert path to class name
          # Expected constant for: payload/android/singles/intent_injection
          # => MPF::Payloads::Singles::Android::IntentInjection
          parts = path.split('/')
          # parts[0] = 'payload'
          # parts[1] = 'android'
          # parts[2] = 'singles'|'stagers'|'stages'|'meterpreter'
          # parts[3].. = payload name tokens
          platform = parts[1]&.capitalize
          group = parts[2]&.split('_')&.map(&:capitalize)&.join

          # Payload constants are nested as MPF::Payloads::<Group>::Android::<PayloadClass>
          # where PayloadClass is a single class (e.g. IntentInjection), not a namespace chain.
          payload_tokens = parts[3..]&.map { |p| p.split('_').map(&:capitalize).join } || []
          payload_class = payload_tokens.join('')

          full_class = "MPF::Payloads::#{group}::#{platform}::#{payload_class}"

          begin
            Object.const_get(full_class).new
          rescue NameError => e
            puts "[DEBUG] Failed to instantiate: #{full_class}" if ENV['DEBUG']
            nil
          end
      end
    end
  end
end
