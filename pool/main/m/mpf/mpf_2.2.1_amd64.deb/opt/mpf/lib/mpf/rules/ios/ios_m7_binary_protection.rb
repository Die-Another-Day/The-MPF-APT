require_relative '../../analysis/rules/base_rule'
require 'pathname'

module MPF
  module Analysis
    module Rules
      class IOSM7BinaryProtectionRule < BaseRule
        def initialize
          super(
            id: 'IOS-M7-BINARY-PROTECTION',
            name: 'iOS Insufficient Binary Protections',
            owasp_category: 'M7',
            severity: :high,
            description: 'Inspects Mach-O compilation flags (ARC, PIE, Stack Canary) and verifies App Store binary encryption.',
            remediation: 'Compile the application with ARC, PIE, and stack protectors enabled. Ensure the final release is processed through the App Store to apply Apple FairPlay encryption.',
            detection_logic: ->(context) { detect(context) }
          )
        end

        def detect(context)
          findings = []
          bin_info = context[:binary_info] || {}
          info_plist = context[:info_plist] || {}
          exec_name = info_plist['CFBundleExecutable'] || 'Executable'

          return [] if bin_info.empty? || bin_info[:error]

          # 1. PIE check
          unless bin_info[:pie]
            findings << {
              id: "ios_pie_disabled",
              owasp: 'M7',
              severity: :high,
              description: "Mach-O binary does not have Position Independent Executable (PIE) enabled",
              component: "Mach-O Executable (#{exec_name})",
              evidence: "MH_PIE flag not found in binary headers",
              confidence: 100
            }
          end

          # 2. ARC check
          unless bin_info[:arc]
            findings << {
              id: "ios_arc_disabled",
              owasp: 'M7',
              severity: :medium,
              description: "Automatic Reference Counting (ARC) not enabled in Mach-O binary",
              component: "Mach-O Executable (#{exec_name})",
              evidence: "Objective-C / Swift memory release symbols not found",
              confidence: 90
            }
          end

          # 3. Stack Canary check
          unless bin_info[:stack_canary]
            findings << {
              id: "ios_stack_canary_disabled",
              owasp: 'M7',
              severity: :high,
              description: "Stack smashing protection (Stack Canary) not detected in Mach-O binary",
              component: "Mach-O Executable (#{exec_name})",
              evidence: "___stack_chk_fail symbol reference missing",
              confidence: 90
            }
          end

          # 4. App Store encryption check
          enc_details = bin_info[:encrypted_details] || {}
          if enc_details[:cryptid] == 0
            findings << {
              id: "ios_binary_not_encrypted",
              owasp: 'M7',
              severity: :medium,
              description: "Mach-O binary is not encrypted (App Store FairPlay cryptid is 0)",
              component: "Mach-O Executable (#{exec_name})",
              evidence: "LC_ENCRYPTION_INFO cryptid = 0 (Likely simulator slice or debug build)",
              confidence: 100
            }
          end

          findings
        end
      end
    end
  end
end
