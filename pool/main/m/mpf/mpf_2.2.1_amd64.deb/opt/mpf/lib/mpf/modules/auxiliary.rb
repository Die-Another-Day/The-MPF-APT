require_relative "module_base"

module MPF
  class Auxiliary < ModuleBase
    def run(target)
      {
        "summary" => "Auxiliary module loaded. No direct actions.",
        "info"    => "Use specific auxiliary modules like static_analysis or dynamic."
      }
    end
  end
end
