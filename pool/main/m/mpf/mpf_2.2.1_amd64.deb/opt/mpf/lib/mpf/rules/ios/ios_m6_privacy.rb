require_relative '../../analysis/rules/base_rule'
require 'pathname'

module MPF
  module Analysis
    module Rules
      class IOSM6PrivacyRule < BaseRule
        def initialize
          super(
            id: 'IOS-M6-PRIVACY',
            name: 'iOS Inadequate Privacy Controls',
            owasp_category: 'M6',
            severity: :medium,
            description: 'Audits privacy permission descriptions in Info.plist and detects excessive PII collection (location, contacts, device identifiers) in code.',
            remediation: 'Ensure all requested permissions have descriptive, user-friendly explanations. Minimize data collection to only what is required.',
            detection_logic: ->(context) { detect(context) }
          )
        end

        def detect(context)
          findings = []
          info_plist = context[:info_plist] || {}
          decoded_dir = context[:decoded_dir]

          # 1. Info.plist Privacy Permission Descriptions Check
          info_plist.each do |key, val|
            if key.start_with?('NS') && key.end_with?('UsageDescription')
              # Check for empty or generic description (less than 15 chars)
              if val.to_s.strip.empty? || val.to_s.strip.length < 15
                findings << {
                  id: "ios_privacy_permission_empty_description",
                  owasp: 'M6',
                  severity: :medium,
                  description: "Privacy permission description key '#{key}' is empty or too generic",
                  component: "Info.plist",
                  evidence: "#{key}: \"#{val}\"",
                  confidence: 90
                }
              end
            end
          end

          # 2. Source Code Scan for PII access APIs
          if decoded_dir
            pii_patterns = {
              "pii_location" => /CLLocationManager|startUpdatingLocation|requestLocation/i,
              "pii_contacts" => /CNContactStore|ABAddressBook/i,
              "pii_advertising_id" => /advertisingIdentifier|ASIdentifierManager/i
            }

            Dir.glob("#{decoded_dir}/**/*.{swift,m,h,json}") do |file|
              next if File.directory?(file)
              content = BaseRule.safe_read(file)
              next if content.empty?

              relative_path = Pathname.new(file).relative_path_from(Pathname.new(decoded_dir)).to_s

              pii_patterns.each do |id, regex|
                if content.match?(regex)
                  findings << {
                    id: "ios_#{id}",
                    owasp: 'M6',
                    severity: :medium,
                    description: "PII access detected in code: #{id.gsub('pii_', '').capitalize} access",
                    component: relative_path,
                    evidence: content.match(regex).to_s,
                    confidence: 75
                  }
                end
              end
            end
          end

          findings
        end
      end
    end
  end
end
