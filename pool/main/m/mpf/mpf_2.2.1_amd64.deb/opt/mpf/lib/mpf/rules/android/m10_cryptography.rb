require_relative '../../analysis/rules/base_rule'
require 'pathname'

module MPF
  module Analysis
    module Rules
      class M10CryptographyRule < BaseRule
        def initialize
          super(
            id: 'M10-INSUFFICIENT-CRYPTO',
            name: 'Insufficient Cryptography',
            owasp_category: 'M10',
            severity: :high,
            description: 'Detection of weak algorithms (MD5, SHA-1, DES, AES/ECB) and hardcoded IVs.',
            remediation: 'Use strong algorithms (AES/GCM/NoPadding, SHA-256+) and random IVs.',
            detection_logic: ->(context) { detect(context) }
          )
        end

        def detect(context)
          decoded_dir = context[:decoded_dir]
          return [] unless decoded_dir

          findings = []

          crypto_patterns = {
            "weak_algorithm_usage" => /MessageDigest\.getInstance\(\s*"(MD5|SHA-1)"\s*\)/i,
            "ecb_mode_usage" => /Cipher\.getInstance\(\s*"[A-Z]+\/ECB\/[A-Z]+"\s*\)/i,
            "des_usage" => /Cipher\.getInstance\(\s*"DES"\s*\)/i,
            "hardcoded_iv" => /IvParameterSpec\(\s*new\s+byte\[\]\s*\{/
          }

          Dir.glob("#{decoded_dir}/**/*.{smali,java,kt}") do |file|
             next if File.directory?(file)
             content = BaseRule.safe_read(file)
             next if content.empty?

             crypto_patterns.each do |key, regex|
               if content.match?(regex)
                  relative_path = Pathname.new(file).relative_path_from(Pathname.new(decoded_dir)).to_s
                  findings << {
                   id: key,
                   owasp: 'M10',
                   severity: :high,
                   description: "Weak cryptography detected: #{key}",
                   component: relative_path,
                   evidence: content.match(regex).to_s[0..50] + "..."
                 }
               end
             end
           end

          findings
        end
      end
    end
  end
end
