require_relative 'base_rule'
require 'pathname'

module MPF
  module Analysis
    module Rules
      class M6PrivacyRule < BaseRule
        def initialize
          super(
            id: 'M6-INADEQUATE-PRIVACY',
            name: 'Inadequate Privacy Controls',
            owasp_category: 'M6',
            severity: :medium,
            description: 'Detection of PII access (IMEI, Phone Number, Location, MAC Address).',
            remediation: 'Minimize PII collection and ensure valid business purpose and user consent.',
            detection_logic: ->(context) { detect(context) }
          )
        end

        def detect(context)
          decoded_dir = context[:decoded_dir]
          return [] unless decoded_dir

          findings = []

          patterns = {
            "pii_device_id" => /getDeviceId|getImei|getMeid/,
            "pii_sim_serial" => /getSimSerialNumber/,
            "pii_phone_number" => /getLine1Number/,
            "pii_location" => /getLastKnownLocation|requestLocationUpdates/,
            "pii_mac_address" => /getMacAddress/
          }

          Dir.glob("#{decoded_dir}/**/*.{smali,java,kt}") do |file|
            next if File.directory?(file)
            content = BaseRule.safe_read(file)
            next if content.empty?

            patterns.each do |key, regex|
              if content.match?(regex)
                relative_path = Pathname.new(file).relative_path_from(Pathname.new(decoded_dir)).to_s
                findings << {
                  id: key,
                  owasp: 'M6',
                  severity: :medium,
                  description: "Potential PII access: #{key.gsub('pii_', '')}",
                  component: relative_path,
                  evidence: content.match(regex).to_s[0..50] + "..."
                }
              end
            end
          end

          findings
        end
      end
    end
  end
end
