require_relative '../../analysis/rules/base_rule'
require 'pathname'

module MPF
  module Analysis
    module Rules
      class M9InsecureStorageRule < BaseRule
        def initialize
          super(
            id: 'M9-INSECURE-STORAGE',
            name: 'Insecure Data Storage',
            owasp_category: 'M9',
            severity: :high,
            description: 'Detection of world-readable/writable files and external storage usage.',
            remediation: 'Use internal storage with default privacy (MODE_PRIVATE) or EncryptedSharedPreferences.',
            detection_logic: ->(context) { detect(context) }
          )
        end

        def detect(context)
          decoded_dir = context[:decoded_dir]
          return [] unless decoded_dir

          findings = []

          Dir.glob("#{decoded_dir}/**/*.{smali,java,kt}") do |file|
            content = BaseRule.safe_read(file)
            next if content.empty?

            if content.match?(/getSharedPreferences.*0x1/) || content.match?(/openFileOutput.*0x1/)
              relative_path = Pathname.new(file).relative_path_from(Pathname.new(decoded_dir)).to_s
              findings << {
                id: "world_readable_files",
                owasp: 'M9',
                severity: :high,
                description: "Code creates world-readable files (MODE_WORLD_READABLE)",
                component: relative_path,
                evidence: "0x1 (MODE_WORLD_READABLE) usage found"
              }
            end
            
            if content.match?(/getSharedPreferences.*0x2/) || content.match?(/openFileOutput.*0x2/)
               relative_path = Pathname.new(file).relative_path_from(Pathname.new(decoded_dir)).to_s
               findings << {
                id: "world_writeable_files",
                owasp: 'M9',
                severity: :high,
                description: "Code creates world-writeable files (MODE_WORLD_WRITEABLE)",
                component: relative_path,
                evidence: "0x2 (MODE_WORLD_WRITEABLE) usage found"
              }
            end
            
            if content.include?("getExternalStorageDirectory") || content.include?("getExternalFilesDir")
               relative_path = Pathname.new(file).relative_path_from(Pathname.new(decoded_dir)).to_s
               findings << {
                id: "insecure_external_storage",
                owasp: 'M9',
                severity: :medium,
                description: "App writes to external storage (SD Card), which is not secure",
                component: relative_path,
                evidence: "External storage API usage found"
              }
            end
          end

          findings
        end
      end
    end
  end
end
