require_relative '../../analysis/rules/base_rule'
require 'pathname'

module MPF
  module Analysis
    module Rules
      class IOSM1InsecureArchitectureRule < BaseRule
        def initialize
          super(
            id: 'IOS-M1-INSECURE-ARCHITECTURE',
            name: 'iOS Improper Credential Usage / Insecure Architecture',
            owasp_category: 'M1',
            severity: :high,
            description: 'Hardcoded secrets (API keys, private keys, tokens), custom URL schemes, or dangerous entitlements in the iOS application.',
            remediation: 'Retrieve credentials securely from Keychain at runtime. Validate all inputs from custom URL schemes. Restrict app entitlements.',
            detection_logic: ->(context) { detect(context) }
          )
        end

        def detect(context)
          findings = []
          decoded_dir = context[:decoded_dir]
          entitlements = context[:entitlements] || {}
          info_plist = context[:info_plist] || {}

          return [] unless decoded_dir

          # 1. Hardcoded Secrets Scan
          secret_patterns = {
            "google_api_key" => /AIza[0-9A-Za-z\\-_]{35}/,
            "aws_access_key" => /AKIA[0-9A-Z]{16}/,
            "firebase_url" => /https:\/\/.*\.firebaseio\.com/,
            "private_key" => /-----BEGIN PRIVATE KEY-----/,
            "generic_api_key" => /api_key\s*=\s*['"][a-zA-Z0-9\-_]{20,}['"]/i,
            "jwt_token" => /eyJ[a-zA-Z0-9\-_]+\.eyJ[a-zA-Z0-9\-_]+\.[a-zA-Z0-9\-_]+/
          }

          Dir.glob("#{decoded_dir}/**/*.{swift,m,h,plist,json,storyboard}") do |file|
            next if File.directory?(file)
            
            content = BaseRule.safe_read(file)
            next if content.empty?

            secret_patterns.each do |id, regex|
              if content.match?(regex)
                relative_path = Pathname.new(file).relative_path_from(Pathname.new(decoded_dir)).to_s
                findings << {
                  id: "ios_hardcoded_#{id}",
                  owasp: 'M1',
                  severity: :high,
                  description: "Potential hardcoded iOS secret found: #{id}",
                  component: relative_path,
                  evidence: content.match(regex).to_s[0..50] + "..."
                }
              end
            end
          end

          # 2. Custom URL Schemes Check
          url_types = info_plist['CFBundleURLTypes']
          if url_types.is_a?(Array)
            url_types.each do |t|
              if t.is_a?(Hash) && t['CFBundleURLSchemes'].is_a?(Array)
                t['CFBundleURLSchemes'].each do |scheme|
                  findings << {
                    id: "ios_custom_url_scheme",
                    owasp: 'M1',
                    severity: :medium,
                    description: "Application registers custom URL scheme: #{scheme}. Validate all incoming parameters to prevent URL hijacking / Injection.",
                    component: "Info.plist",
                    evidence: "CFBundleURLSchemes: #{scheme}"
                  }
                end
              end
            end
          end

          # 3. Dangerous Entitlements Check
          if entitlements['keychain-access-groups'].is_a?(Array) && entitlements['keychain-access-groups'].any?
            findings << {
              id: "ios_keychain_sharing_enabled",
              owasp: 'M1',
              severity: :medium,
              description: "Keychain sharing groups are defined. Ensure access groups are restricted only to trusted bundle identifiers.",
              component: "embedded.mobileprovision (Entitlements)",
              evidence: "keychain-access-groups: #{entitlements['keychain-access-groups'].join(', ')}"
            }
          end

          if entitlements['com.apple.developer.parental-controls'] == true
            findings << {
              id: "ios_dangerous_parental_controls",
              owasp: 'M1',
              severity: :high,
              description: "App requests dangerous parental controls developer entitlement.",
              component: "embedded.mobileprovision (Entitlements)",
              evidence: "com.apple.developer.parental-controls: true"
            }
          end

          findings
        end
      end
    end
  end
end
