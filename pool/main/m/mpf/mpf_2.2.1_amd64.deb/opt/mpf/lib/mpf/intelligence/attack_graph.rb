require_relative 'cvss_scorer'

module MPF
  module Intelligence
    # Graph-based attack chain reasoning engine
    # Models vulnerabilities as nodes and exploitation relationships as directed edges
    class AttackGraph

      Node = Struct.new(:id, :type, :label, :cvss, :severity, :owasp, keyword_init: true)
      Edge = Struct.new(:from, :to, :label, :probability, keyword_init: true)

      # Node types
      ENTRY_POINT   = :entry_point
      PIVOT         = :pivot
      OBJECTIVE     = :objective
      PRECONDITION  = :precondition

      # Exploitation relationship definitions
      EXPLOIT_EDGES = {
        'exported_provider_without_permission' => {
          enables: ['sql_injection_via_provider', 'data_exfiltration', 'path_traversal_read'],
          type: ENTRY_POINT, probability: 0.95
        },
        'exported_activity_without_permission' => {
          enables: ['authentication_bypass', 'ui_manipulation', 'intent_data_theft'],
          type: ENTRY_POINT, probability: 0.90
        },
        'exported_service_without_permission' => {
          enables: ['background_execution', 'privilege_escalation_service'],
          type: ENTRY_POINT, probability: 0.85
        },
        'exported_receiver_without_permission' => {
          enables: ['broadcast_injection', 'intent_spoofing'],
          type: ENTRY_POINT, probability: 0.80
        },
        'debuggable_enabled' => {
          enables: ['runtime_memory_dump', 'authentication_bypass_debug', 'secret_extraction_runtime'],
          type: PRECONDITION, probability: 0.88
        },
        'allow_backup_enabled' => {
          enables: ['offline_data_extraction', 'credential_recovery_backup'],
          type: PRECONDITION, probability: 0.92
        },
        'sql_injection' => {
          enables: ['full_db_dump', 'credential_extraction_sql', 'schema_enumeration'],
          type: PIVOT, probability: 0.85
        },
        'webview_js_enabled' => {
          enables: ['xss_execution', 'js_bridge_abuse'],
          type: PIVOT, probability: 0.75
        },
        'webview_add_js_interface' => {
          enables: ['native_code_execution', 'filesystem_access_webview'],
          type: PIVOT, probability: 0.80
        },
        'cleartext_traffic_allowed' => {
          enables: ['mitm_credential_theft', 'session_hijacking', 'api_key_interception'],
          type: PRECONDITION, probability: 0.70
        },
        'hardcoded_google_api_key' => {
          enables: ['api_abuse', 'quota_exhaustion', 'data_access_via_api'],
          type: OBJECTIVE, probability: 0.99
        },
        'hardcoded_aws_access_key' => {
          enables: ['cloud_resource_access', 'data_exfiltration_cloud', 's3_bucket_access'],
          type: OBJECTIVE, probability: 0.99
        },
        'weak_algorithm_usage' => {
          enables: ['offline_decryption', 'hash_collision_attack'],
          type: PRECONDITION, probability: 0.65
        },
        'world_readable_files' => {
          enables: ['cross_app_data_theft', 'credential_file_read'],
          type: PRECONDITION, probability: 0.88
        },
        'path_traversal' => {
          enables: ['arbitrary_file_read', 'config_file_theft'],
          type: PIVOT, probability: 0.80
        },
        'root_detection_missing' => {
          enables: ['root_bypass', 'frida_injection', 'ssl_unpinning'],
          type: PRECONDITION, probability: 0.85
        }
      }.freeze

      # Multi-step attack path templates
      ATTACK_PATHS = [
        {
          id: 'path_full_compromise',
          name: 'Full Application Compromise',
          description: 'Complete takeover of application data and functionality',
          required_nodes: ['exported_provider_without_permission', 'debuggable_enabled'],
          steps: [
            { action: 'Enumerate exported ContentProvider', node: 'exported_provider_without_permission', technique: 'T1426' },
            { action: 'Query provider to extract database schema', node: 'sql_injection_via_provider', technique: 'T1409' },
            { action: 'Attach JDWP debugger to running process', node: 'debuggable_enabled', technique: 'T1422' },
            { action: 'Dump runtime memory for in-memory secrets', node: 'runtime_memory_dump', technique: 'T1417' },
            { action: 'Extract all application data', node: 'data_exfiltration', technique: 'T1409' }
          ],
          risk_multiplier: 1.8
        },
        {
          id: 'path_credential_harvest',
          name: 'Credential Harvesting Attack',
          description: 'Systematic extraction of all credentials from the application',
          required_nodes: ['allow_backup_enabled', 'hardcoded_google_api_key'],
          steps: [
            { action: 'Extract APK and decompile', node: 'static_analysis', technique: 'T1418' },
            { action: 'Identify hardcoded API keys in source', node: 'hardcoded_google_api_key', technique: 'T1411' },
            { action: 'Perform ADB backup extraction', node: 'allow_backup_enabled', technique: 'T1429' },
            { action: 'Parse SharedPreferences for stored credentials', node: 'credential_recovery_backup', technique: 'T1409' },
            { action: 'Validate and abuse extracted credentials', node: 'api_abuse', technique: 'T1411' }
          ],
          risk_multiplier: 1.5
        },
        {
          id: 'path_webview_rce',
          name: 'WebView Remote Code Execution',
          description: 'Achieve code execution via malicious web content through WebView',
          required_nodes: ['webview_js_enabled', 'webview_add_js_interface'],
          steps: [
            { action: 'Identify WebView with JavaScript enabled', node: 'webview_js_enabled', technique: 'T1426' },
            { action: 'Locate addJavascriptInterface binding', node: 'webview_add_js_interface', technique: 'T1426' },
            { action: 'Craft malicious JavaScript payload', node: 'xss_execution', technique: 'T1411' },
            { action: 'Deliver payload via deep link or exported activity', node: 'native_code_execution', technique: 'T1416' },
            { action: 'Execute arbitrary native code', node: 'filesystem_access_webview', technique: 'T1409' }
          ],
          risk_multiplier: 1.7
        },
        {
          id: 'path_network_interception',
          name: 'Network Traffic Interception',
          description: 'Intercept and manipulate application network traffic',
          required_nodes: ['cleartext_traffic_allowed'],
          steps: [
            { action: 'Position on same network segment as target', node: 'network_position', technique: 'T1439' },
            { action: 'Intercept cleartext HTTP traffic', node: 'cleartext_traffic_allowed', technique: 'T1439' },
            { action: 'Extract credentials from HTTP requests', node: 'mitm_credential_theft', technique: 'T1439' },
            { action: 'Replay captured session tokens', node: 'session_hijacking', technique: 'T1439' }
          ],
          risk_multiplier: 1.3
        },
        {
          id: 'path_sql_data_dump',
          name: 'SQL Injection Full Database Dump',
          description: 'Extract complete database contents via SQL injection',
          required_nodes: ['exported_provider_without_permission', 'sql_injection'],
          steps: [
            { action: 'Identify exported ContentProvider', node: 'exported_provider_without_permission', technique: 'T1426' },
            { action: 'Test SQL injection in selection parameter', node: 'sql_injection', technique: 'T1409' },
            { action: 'Enumerate database tables via UNION injection', node: 'schema_enumeration', technique: 'T1409' },
            { action: 'Extract all table contents', node: 'full_db_dump', technique: 'T1409' },
            { action: 'Parse and exfiltrate sensitive records', node: 'credential_extraction_sql', technique: 'T1409' }
          ],
          risk_multiplier: 1.6
        }
      ].freeze

      def initialize(findings)
        @findings = findings
        @finding_ids = findings.map { |f| (f['id'] || f[:id]).to_s }
        @nodes = {}
        @edges = []
        build_graph
      end

      def analyze
        active_paths = find_active_paths
        risk_propagation = propagate_risk(active_paths)
        {
          nodes:            @nodes.values.map(&:to_h),
          edges:            @edges.map(&:to_h),
          active_paths:     active_paths,
          risk_propagation: risk_propagation,
          critical_paths:   active_paths.select { |p| p[:risk_score] >= 9.0 },
          attack_surface_score: calculate_attack_surface_score,
          exploitation_probability: calculate_exploitation_probability(active_paths)
        }
      end

      private

      def build_graph
        @findings.each do |finding|
          fid = (finding['id'] || finding[:id]).to_s
          score_data = CVSSScorer.score(fid)
          edge_def = EXPLOIT_EDGES[fid]

          node = Node.new(
            id:       fid,
            type:     edge_def ? edge_def[:type] : PRECONDITION,
            label:    finding['description'] || finding[:description] || fid,
            cvss:     score_data[:hybrid_score],
            severity: score_data[:severity],
            owasp:    finding['owasp'] || finding[:owasp] || 'Unknown'
          )
          @nodes[fid] = node

          next unless edge_def
          edge_def[:enables].each do |target|
            @edges << Edge.new(
              from:        fid,
              to:          target,
              label:       "enables",
              probability: edge_def[:probability]
            )
          end
        end
      end

      def find_active_paths
        active = []
        ATTACK_PATHS.each do |path_def|
          matched = path_def[:required_nodes].all? do |req|
            @finding_ids.any? { |id| id.include?(req) }
          end
          next unless matched

          source_findings = @findings.select do |f|
            path_def[:required_nodes].any? { |req| (f['id'] || f[:id]).to_s.include?(req) }
          end

          chain = CVSSScorer.score_chain(source_findings)
          risk  = [chain[:chain_score] * path_def[:risk_multiplier], 10.0].min

          active << {
            id:          path_def[:id],
            name:        path_def[:name],
            description: path_def[:description],
            steps:       path_def[:steps],
            risk_score:  risk.round(1),
            severity:    CVSSScorer.classify(risk),
            feasibility: calculate_path_feasibility(path_def, source_findings),
            source_vulns: source_findings.map { |f| f['id'] || f[:id] }
          }
        end
        active.sort_by { |p| -p[:risk_score] }
      end

      def propagate_risk(paths)
        return { overall_risk: 0.0, severity: :none } if paths.empty?
        scores = paths.map { |p| p[:risk_score] }
        # Risk propagation: highest path + 10% of each additional path
        base = scores.max
        propagated = scores.reject { |s| s == base }.sum { |s| s * 0.10 }
        total = [base + propagated, 10.0].min
        {
          overall_risk:    total.round(1),
          severity:        CVSSScorer.classify(total),
          path_count:      paths.length,
          critical_paths:  paths.count { |p| p[:severity] == :critical },
          high_paths:      paths.count { |p| p[:severity] == :high }
        }
      end

      def calculate_path_feasibility(path_def, source_findings)
        # Based on number of required vulns found and their CVSS scores
        found_ratio = source_findings.length.to_f / path_def[:required_nodes].length
        avg_cvss = source_findings.empty? ? 0 :
          source_findings.sum { |f| CVSSScorer.score((f['id'] || f[:id]).to_s)[:hybrid_score] } / source_findings.length
        score = (found_ratio * 0.6 + (avg_cvss / 10.0) * 0.4) * 100
        case score
        when 80..100 then 'very_high'
        when 60...80 then 'high'
        when 40...60 then 'medium'
        when 20...40 then 'low'
        else 'very_low'
        end
      end

      def calculate_attack_surface_score
        return 0.0 if @nodes.empty?
        entry_points = @nodes.values.count { |n| n.type == ENTRY_POINT }
        total_cvss   = @nodes.values.sum(&:cvss)
        avg_cvss     = total_cvss / @nodes.length
        surface = (entry_points * 1.5 + avg_cvss) / 2.0
        [surface, 10.0].min.round(1)
      end

      def calculate_exploitation_probability(paths)
        return 0.0 if paths.empty?
        probs = paths.map do |path|
          case path[:feasibility]
          when 'very_high' then 0.95
          when 'high'      then 0.80
          when 'medium'    then 0.60
          when 'low'       then 0.35
          else 0.15
          end
        end
        # P(at least one path succeeds) = 1 - P(all fail)
        prob = 1.0 - probs.reduce(1.0) { |acc, p| acc * (1.0 - p) }
        (prob * 100).round(1)
      end
    end
  end
end
