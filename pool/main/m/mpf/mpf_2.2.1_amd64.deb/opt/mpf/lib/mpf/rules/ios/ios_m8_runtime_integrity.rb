require_relative '../../analysis/rules/base_rule'
require 'pathname'

module MPF
  module Analysis
    module Rules
      class IOSM8RuntimeIntegrityRule < BaseRule
        def initialize
          super(
            id: 'IOS-M8-RUNTIME-INTEGRITY',
            name: 'iOS Runtime Integrity and Anti-Tampering',
            owasp_category: 'M8',
            severity: :medium,
            description: 'Scans for presence of jailbreak detection and anti-tampering logic in source code.',
            remediation: 'Implement multi-layered jailbreak detection (file path existence checks, fork checks, symbolic links) and Frida detection.',
            detection_logic: ->(context) { detect(context) }
          )
        end

        def detect(context)
          findings = []
          decoded_dir = context[:decoded_dir]
          return [] unless decoded_dir

          # Common Jailbreak Indicators
          jailbreak_indicators = [
            "/Applications/Cydia.app",
            "/Library/MobileSubstrate/MobileSubstrate.dylib",
            "/bin/bash",
            "/usr/sbin/sshd",
            "/etc/apt",
            "/private/jailbreak.txt"
          ]

          # Frida/Reverse Engineering Tools Indicators
          frida_indicators = [
            "27042", # Default Frida port
            "frida-server",
            "frida",
            "cydia",
            "substrate"
          ]

          found_jailbreak_checks = false
          found_frida_checks = false

          Dir.glob("#{decoded_dir}/**/*.{swift,m,h,json}") do |file|
            next if File.directory?(file)
            content = BaseRule.safe_read(file)
            next if content.empty?

            jailbreak_indicators.each do |indicator|
              found_jailbreak_checks = true if content.include?(indicator)
            end

            frida_indicators.each do |indicator|
              found_frida_checks = true if content.include?(indicator)
            end
          end

          unless found_jailbreak_checks
            findings << {
              id: "ios_jailbreak_detection_missing",
              owasp: 'M8',
              severity: :medium,
              description: "No common jailbreak detection mechanisms found in code",
              component: "Application Logic",
              evidence: "Scanned for: Cydia, /bin/bash, /usr/sbin/sshd, MobileSubstrate",
              confidence: 85
            }
          end

          unless found_frida_checks
            findings << {
              id: "ios_tampering_protection_missing",
              owasp: 'M8',
              severity: :medium,
              description: "No Frida or anti-tampering hook detection found in code",
              component: "Application Logic",
              evidence: "Scanned for: Frida, Substrate hooks, port 27042",
              confidence: 85
            }
          end

          findings
        end
      end
    end
  end
end
