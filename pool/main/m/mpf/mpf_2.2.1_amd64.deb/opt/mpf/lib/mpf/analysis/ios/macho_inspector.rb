module MPF
  module Analysis
    module IOS
      class MachOInspector
        MH_MAGIC = 0xfeedface
        MH_CIGAM = 0xcefaedfe
        MH_MAGIC_64 = 0xfeedfacf
        MH_CIGAM_64 = 0xcffaedfe
        FAT_MAGIC = 0xcafebabe
        FAT_CIGAM = 0xbebafeca

        # Flags
        MH_PIE = 0x00200000

        def self.inspect_binary(path)
          return { error: 'Binary file does not exist' } unless File.exist?(path)

          content = File.read(path, mode: 'rb')
          return { error: 'Empty binary' } if content.size < 32

          # Read magic bytes
          magic = content[0, 4].unpack1('N')

          offset = 0
          if magic == FAT_MAGIC || magic == FAT_CIGAM
            # Fat binary, resolve the slice
            offset = resolve_fat_slice(content)
            if offset >= content.size
              return { error: 'Invalid fat slice offset' }
            end
            magic = content[offset, 4].unpack1('N')
          end

          # Determine 32 vs 64 bit
          is_64 = (magic == MH_MAGIC_64 || magic == MH_CIGAM_64)
          is_swap = (magic == MH_CIGAM || magic == MH_CIGAM_64)

          # Parse header
          header_data = content[offset, is_64 ? 32 : 28]
          return { error: 'Malformed Mach-O header' } unless header_data && header_data.size >= (is_64 ? 32 : 28)

          # Unpack fields
          # magic, cputype, cpusubtype, filetype, ncmds, sizeofcmds, flags
          fields = if is_swap
                     header_data.unpack('V7')
                   else
                     header_data.unpack('N7')
                   end

          flags = fields[6]

          # Verify flags
          pie_enabled = (flags & MH_PIE) != 0

          # Heuristics for Stack Canary and ARC
          # Searching for symbol imports embedded in the binary strings
          canary_found = content.include?('___stack_chk_fail') || content.include?('___stack_chk_guard')
          arc_found = content.include?('_objc_release') || content.include?('_objc_retain') || content.include?('swift_release') || content.include?('swift_retain')

          {
            pie: pie_enabled,
            stack_canary: canary_found,
            arc: arc_found,
            encrypted: false, # Static analysis heuristic: Apple cryptid requires checking encryption load commands
            encrypted_details: check_encryption(content, offset, fields[4], is_swap, is_64)
          }
        rescue => e
          { error: "Mach-O parse error: #{e.message}" }
        end

        private

        def self.resolve_fat_slice(content)
          # Fat header contains: magic (4), num_archs (4)
          num_archs = content[4, 4].unpack1('N')
          return 0 if num_archs.nil? || num_archs <= 0 || num_archs > 10

          best_offset = 0
          num_archs.times do |i|
            # Each arch entry is 20 bytes: cputype (4), cpusubtype (4), offset (4), size (4), align (4)
            entry_offset = 8 + (i * 20)
            cputype, _, arch_offset, _, _ = content[entry_offset, 20].unpack('N5')
            next unless arch_offset

            # CPU_TYPE_ARM64 = 0x0100000c
            if cputype == 0x0100000c
              return arch_offset
            end
            best_offset = arch_offset if best_offset == 0
          end
          best_offset
        end

        def self.check_encryption(content, offset, ncmds, is_swap, is_64)
          # Header size
          hdr_size = is_64 ? 32 : 28
          pos = offset + hdr_size

          # Scan load commands for LC_ENCRYPTION_INFO (0x21) or LC_ENCRYPTION_INFO_64 (0x2C)
          ncmds.times do
            break if pos + 8 > content.size
            cmd = is_swap ? content[pos, 4].unpack1('V') : content[pos, 4].unpack1('N')
            cmdsize = is_swap ? content[pos + 4, 4].unpack1('V') : content[pos + 4, 4].unpack1('N')

            if cmd == 0x21 || cmd == 0x2c
              # LC_ENCRYPTION_INFO / LC_ENCRYPTION_INFO_64
              # Format: cmd (4), cmdsize (4), cryptoff (4), cryptsize (4), cryptid (4)
              cryptid = is_swap ? content[pos + 16, 4].unpack1('V') : content[pos + 16, 4].unpack1('N')
              return { cryptid: cryptid, encrypted: (cryptid > 0) }
            end

            pos += cmdsize
            break if cmdsize <= 0
          end
          { cryptid: 0, encrypted: false }
        end
      end
    end
  end
end
