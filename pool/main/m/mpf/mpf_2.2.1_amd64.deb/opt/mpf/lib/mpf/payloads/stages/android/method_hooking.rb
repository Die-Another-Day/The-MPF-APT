require_relative '../../../core/payload_base'

module MPF
  module Payloads
    module Stages
      module Android
        class MethodHooking < MPF::Core::PayloadBase
          
          def register_info
            @info = {
              name: 'Android Method Hooking via Frida',
              module: 'payload/android/stages/method_hooking',
              platform: :android,
              description: 'Hooks Java methods at runtime using Frida to intercept calls, ' \
                          'modify parameters, and extract sensitive data.',
              authors: ['MPF Research Team'],
              severity: 'critical'
            }
            @payload_type = :stage
          end

          def register_options
            add_option('TARGET_PACKAGE', 'Target application package name', required: true)
            add_option('TARGET_CLASS', 'Java class to hook', required: true)
            add_option('TARGET_METHOD', 'Method name to hook', required: true)
            add_option('HOOK_TYPE', 'Type: intercept, modify, log', default: 'intercept')
            add_option('DEVICE', 'Target device ID', default: 'emulator-5554')
            add_option('OUTPUT_FILE', 'Output file for hooked data', default: 'method_hooks.log')
          end

          def generate(opts = {})
            target_class = get_option('TARGET_CLASS')
            target_method = get_option('TARGET_METHOD')
            hook_type = get_option('HOOK_TYPE')

            script = generate_frida_script(target_class, target_method, hook_type)

            {
              type: 'method_hooking',
              target_class: target_class,
              target_method: target_method,
              hook_type: hook_type,
              frida_script: script,
              description: "Hook #{target_class}.#{target_method}() - #{hook_type}"
            }
          end

          def execute(target_info)
            validation = validate
            unless validation[:valid]
              return { success: false, error: validation[:errors] }
            end

            # Check if Frida is available
            unless frida_available?
              return {
                success: false,
                error: 'Frida not installed. Install with: pip install frida-tools'
              }
            end

            package = get_option('TARGET_PACKAGE')
            device = get_option('DEVICE')
            output_file = get_option('OUTPUT_FILE')

            print_status("Setting up method hooking...")
            print_status("Target: #{get_option('TARGET_CLASS')}.#{get_option('TARGET_METHOD')}()")

            # Generate Frida script
            payload_data = generate({})
            script_path = save_frida_script(payload_data[:frida_script])

            # Launch Frida
            print_status("Launching Frida...")
            print_status("Script: #{script_path}")

            result = launch_frida(package, script_path, device, output_file)

            if result[:success]
              print_good("Method hooking successful!")
              {
                success: true,
                hooked_class: get_option('TARGET_CLASS'),
                hooked_method: get_option('TARGET_METHOD'),
                output_file: result[:output_file],
                impact: 'Runtime method interception active'
              }
            else
              print_error("Method hooking failed")
              result
            end
          end

          private

          def frida_available?
            system("which frida > /dev/null 2>&1")
          end

          def generate_frida_script(target_class, target_method, hook_type)
            case hook_type
            when 'intercept'
              generate_intercept_script(target_class, target_method)
            when 'modify'
              generate_modify_script(target_class, target_method)
            when 'log'
              generate_log_script(target_class, target_method)
            else
              generate_intercept_script(target_class, target_method)
            end
          end

          def generate_intercept_script(target_class, target_method)
            <<~JAVASCRIPT
              Java.perform(function() {
                  console.log("[*] Starting method hooking...");
                  
                  var targetClass = Java.use("#{target_class}");
                  
                  targetClass.#{target_method}.overload().implementation = function() {
                      console.log("[+] Method called: #{target_class}.#{target_method}()");
                      console.log("[*] Arguments: " + JSON.stringify(arguments));
                      
                      // Call original method
                      var result = this.#{target_method}.apply(this, arguments);
                      
                      console.log("[*] Return value: " + result);
                      
                      return result;
                  };
                  
                  console.log("[+] Hook installed successfully");
              });
            JAVASCRIPT
          end

          def generate_modify_script(target_class, target_method)
            <<~JAVASCRIPT
              Java.perform(function() {
                  console.log("[*] Starting method modification hook...");
                  
                  var targetClass = Java.use("#{target_class}");
                  
                  targetClass.#{target_method}.overload().implementation = function() {
                      console.log("[+] Method intercepted: #{target_class}.#{target_method}()");
                      console.log("[*] Original arguments: " + JSON.stringify(arguments));
                      
                      // Modify arguments
                      var modifiedArgs = Array.prototype.slice.call(arguments);
                      console.log("[!] Modified arguments: " + JSON.stringify(modifiedArgs));
                      
                      // Call with modified arguments
                      var result = this.#{target_method}.apply(this, modifiedArgs);
                      
                      // Modify return value
                      console.log("[*] Original return: " + result);
                      console.log("[!] Returning modified value");
                      
                      return result;
                  };
                  
                  console.log("[+] Modification hook installed");
              });
            JAVASCRIPT
          end

          def generate_log_script(target_class, target_method)
            <<~JAVASCRIPT
              Java.perform(function() {
                  console.log("[*] Starting logging hook...");
                  
                  var targetClass = Java.use("#{target_class}");
                  var callCount = 0;
                  
                  targetClass.#{target_method}.overload().implementation = function() {
                      callCount++;
                      
                      console.log("\\n" + "=".repeat(60));
                      console.log("[+] Call #" + callCount + ": #{target_class}.#{target_method}()");
                      console.log("Timestamp: " + new Date().toISOString());
                      console.log("Thread: " + Java.use("java.lang.Thread").currentThread().getName());
                      
                      // Log arguments
                      console.log("\\nArguments:");
                      for (var i = 0; i < arguments.length; i++) {
                          console.log("  [" + i + "] " + arguments[i]);
                      }
                      
                      // Log stack trace
                      console.log("\\nStack Trace:");
                      console.log(Java.use("android.util.Log").getStackTraceString(
                          Java.use("java.lang.Exception").$new()
                      ));
                      
                      // Call original
                      var result = this.#{target_method}.apply(this, arguments);
                      
                      console.log("\\nReturn Value: " + result);
                      console.log("=".repeat(60) + "\\n");
                      
                      return result;
                  };
                  
                  console.log("[+] Logging hook installed");
              });
            JAVASCRIPT
          end

          def save_frida_script(script_content)
            script_dir = 'reports/payload/frida_scripts'
            `mkdir -p #{script_dir}` unless Dir.exist?(script_dir)
            
            timestamp = Time.now.strftime('%Y%m%d_%H%M%S')
            script_path = File.join(script_dir, "hook_#{timestamp}.js")
            
            File.write(script_path, script_content)
            print_good("Frida script saved: #{script_path}")
            
            script_path
          end

          def launch_frida(package, script_path, device, output_file)
            output_path = "reports/payload/#{output_file}"
            
            print_status("Attaching Frida to #{package}...")
            print_warning("This will run until interrupted (Ctrl+C)")
            print_status("Output will be saved to: #{output_path}")
            
            # Launch Frida in background
            cmd = "frida -U -f #{package} -l #{script_path} --no-pause > #{output_path} 2>&1 &"
            pid = spawn(cmd)
            
            sleep(3)
            
            # Check if Frida is running
            if Process.waitpid(pid, Process::WNOHANG).nil?
              print_good("Frida attached successfully (PID: #{pid})")
              print_status("Use 'kill #{pid}' to stop hooking")
              
              {
                success: true,
                frida_pid: pid,
                output_file: output_path,
                script_path: script_path
              }
            else
              print_error("Frida failed to attach")
              {
                success: false,
                error: 'Frida attachment failed. Check if app is running and Frida server is installed on device.'
              }
            end
          rescue => e
            {
              success: false,
              error: "Frida launch error: #{e.message}"
            }
          end

          def print_status(msg)
            puts "[*] #{msg}"
          end

          def print_good(msg)
            puts "[+] #{msg}"
          end

          def print_warning(msg)
            puts "[!] #{msg}"
          end

          def print_error(msg)
            puts "[-] #{msg}"
          end
        end
      end
    end
  end
end
