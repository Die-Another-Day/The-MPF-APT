require_relative '../../analysis/rules/base_rule'
require 'pathname'

module MPF
  module Analysis
    module Rules
      class IOSM9ReverseEngineeringRule < BaseRule
        def initialize
          super(
            id: 'IOS-M9-REVERSE-ENGINEERING',
            name: 'iOS Reverse Engineering Exposure',
            owasp_category: 'M9',
            severity: :medium,
            description: 'Audits Mach-O binary and code for symbols stripping, debug sections, and anti-debugging protection.',
            remediation: 'Ensure the release build is stripped (Deployment Postprocessing enabled, Strip Linked Product = YES). Implement ptrace PT_DENY_ATTACH or sysctl anti-debugging checks.',
            detection_logic: ->(context) { detect(context) }
          )
        end

        def detect(context)
          findings = []
          decoded_dir = context[:decoded_dir]
          app_dir = context[:app_dir]
          info_plist = context[:info_plist] || {}
          exec_name = info_plist['CFBundleExecutable']

          return [] unless decoded_dir

          # 1. Check for anti-debugging (PT_DENY_ATTACH) or ptrace references in source code
          anti_debug_found = false
          Dir.glob("#{decoded_dir}/**/*.{swift,m,h,json}") do |file|
            next if File.directory?(file)
            content = BaseRule.safe_read(file)
            next if content.empty?

            if content.include?("PT_DENY_ATTACH") || content.include?("sysctl") && content.include?("amIAnallyzed") || content.include?("ptrace")
              anti_debug_found = true
            end
          end

          # Check executable binary directly
          if app_dir && exec_name
            binary_path = File.join(app_dir, exec_name)
            if File.exist?(binary_path)
              bin_content = File.read(binary_path, mode: 'rb').force_encoding('UTF-8').encode('UTF-8', 'UTF-8', invalid: :replace, undef: :replace, replace: '')
              
              if bin_content.include?("PT_DENY_ATTACH") || bin_content.include?("ptrace")
                anti_debug_found = true
              end

              # Check if debug symbols (DWARF/dSYM reference) are present in the binary
              if bin_content.include?("__DWARF") || bin_content.include?(".dSYM")
                findings << {
                  id: "ios_debug_symbols_present",
                  owasp: 'M9',
                  severity: :low,
                  description: "Debug symbols (DWARF/dSYM reference) detected in production binary",
                  component: "Mach-O Executable (#{exec_name})",
                  evidence: "Found debug symbol indicators in binary body",
                  confidence: 80
                }
              end

              # Simple heuristic check for unstripped symbols: check if symbol table commands are loaded or symbols like "main.swift" exist
              if bin_content.include?(".swift") || bin_content.include?("_main") && bin_content.include?("AppDelegate")
                # Since Xcode release builds strip these symbols by default, their presence is an indicator of unstripped build
                findings << {
                  id: "ios_symbols_not_stripped",
                  owasp: 'M9',
                  severity: :medium,
                  description: "Application binary contains unstripped Swift/ObjC symbols, making reverse engineering easier",
                  component: "Mach-O Executable (#{exec_name})",
                  evidence: "Discovered developer symbols and class structures in binary",
                  confidence: 75
                }
              end
            end
          end

          unless anti_debug_found
            findings << {
              id: "ios_anti_debugging_missing",
              owasp: 'M9',
              severity: :medium,
              description: "No common anti-debugging (e.g. PT_DENY_ATTACH) checks found in code or binary",
              component: "Application Logic",
              evidence: "Scanned for: PT_DENY_ATTACH, ptrace, sysctl debugger detection",
              confidence: 85
            }
          end

          findings
        end
      end
    end
  end
end
