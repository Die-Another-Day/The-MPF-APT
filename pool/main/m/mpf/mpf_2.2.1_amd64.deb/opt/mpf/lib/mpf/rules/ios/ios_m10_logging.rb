require_relative '../../analysis/rules/base_rule'
require 'pathname'

module MPF
  module Analysis
    module Rules
      class IOSM10LoggingRule < BaseRule
        def initialize
          super(
            id: 'IOS-M10-LOGGING',
            name: 'iOS Insufficient Monitoring and Logging',
            owasp_category: 'M10',
            severity: :low,
            description: 'Scans for NSLog, print, and os_log usage in source files that might leak sensitive operational details or user credentials.',
            remediation: 'Disable debug logs in production builds. Wrap logging calls inside debug-only compiler directives (e.g., #if DEBUG) or use logging frameworks with log level filtering.',
            detection_logic: ->(context) { detect(context) }
          )
        end

        def detect(context)
          findings = []
          decoded_dir = context[:decoded_dir]
          return [] unless decoded_dir

          log_patterns = {
            "nslog_usage" => /NSLog\s*\(/i,
            "swift_print" => /print\s*\(/,
            "os_log_usage" => /os_log\s*\(/
          }

          Dir.glob("#{decoded_dir}/**/*.{swift,m,h}") do |file|
            next if File.directory?(file)
            content = BaseRule.safe_read(file)
            next if content.empty?

            relative_path = Pathname.new(file).relative_path_from(Pathname.new(decoded_dir)).to_s

            log_patterns.each do |key, regex|
              if content.match?(regex)
                # Check if it has sensitive keywords near the log statement to identify potentially critical leaks
                sensitive_leak = content.match?(/log.*(pass|key|token|auth|secret|credential|user)/i)
                severity = sensitive_leak ? :medium : :low
                desc = sensitive_leak ? "Potential sensitive data leak in log statement" : "Use of print/logging statement (may leak operational details in console logs)"

                findings << {
                  id: "ios_verbose_logging_#{key}",
                  owasp: 'M10',
                  severity: severity,
                  description: desc,
                  component: relative_path,
                  evidence: content.match(regex).to_s + "...",
                  confidence: 70
                }
              end
            end
          end

          findings
        end
      end
    end
  end
end
