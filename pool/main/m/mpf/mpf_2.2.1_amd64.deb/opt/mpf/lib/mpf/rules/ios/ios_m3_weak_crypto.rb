require_relative '../../analysis/rules/base_rule'
require 'pathname'

module MPF
  module Analysis
    module Rules
      class IOSM3WeakCryptoRule < BaseRule
        def initialize
          super(
            id: 'IOS-M3-WEAK-CRYPTO',
            name: 'iOS Weak Cryptography',
            owasp_category: 'M3',
            severity: :high,
            description: 'Usage of deprecated or weak cryptographic APIs and algorithms (DES, 3DES, RC4, MD5, SHA1).',
            remediation: 'Migrate to strong algorithms (AES-GCM 256, SHA256) using CryptoKit or CommonCrypto high-level APIs.',
            detection_logic: ->(context) { detect(context) }
          )
        end

        def detect(context)
          findings = []
          decoded_dir = context[:decoded_dir]
          return [] unless decoded_dir

          crypto_patterns = {
            "des_algorithm" => /kCCAlgorithmDES|CCAlgorithmDES/i,
            "rc4_algorithm" => /kCCAlgorithmRC4|CCAlgorithmRC4/i,
            "md5_hashing" => /CC_MD5|CC_MD5_Init|CC_MD5_Update/i,
            "sha1_hashing" => /CC_SHA1|CC_SHA1_Init|CC_SHA1_Update/i,
            "ecb_mode" => /kCCOptionECBMode/i
          }

          Dir.glob("#{decoded_dir}/**/*.{swift,m,h,txt,json}") do |file|
            next if File.directory?(file)
            
            content = BaseRule.safe_read(file)
            next if content.empty?

            crypto_patterns.each do |id, regex|
              if content.match?(regex)
                relative_path = Pathname.new(file).relative_path_from(Pathname.new(decoded_dir)).to_s
                findings << {
                  id: "ios_weak_crypto_#{id}",
                  owasp: 'M3',
                  severity: :high,
                  description: "Weak cryptographic algorithm or hash API detected in iOS: #{id}",
                  component: relative_path,
                  evidence: content.match(regex).to_s
                }
              end
            end
          end

          # Also check the executable binary strings
          # Check info binary info
          info_plist = context[:info_plist] || {}
          exec_name = info_plist['CFBundleExecutable']
          app_dir = context[:app_dir]
          
          if app_dir && exec_name
            binary_path = File.join(app_dir, exec_name)
            if File.exist?(binary_path)
              bin_content = File.read(binary_path, mode: 'rb').force_encoding('UTF-8').encode('UTF-8', 'UTF-8', invalid: :replace, undef: :replace, replace: '')
              
              crypto_patterns.each do |id, regex|
                if bin_content.match?(regex)
                  findings << {
                    id: "ios_binary_weak_crypto_#{id}",
                    owasp: 'M3',
                    severity: :high,
                    description: "Weak cryptographic symbol or API found in Mach-O binary: #{id}",
                    component: "Mach-O Executable (#{exec_name})",
                    evidence: "Weak API symbol reference detected in binary"
                  }
                end
              end
            end
          end

          findings
        end
      end
    end
  end
end
