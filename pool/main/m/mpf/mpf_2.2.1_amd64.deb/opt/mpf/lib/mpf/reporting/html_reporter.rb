require 'json'
require 'fileutils'
require 'time'

module MPF
  module Reporting
    class HTMLReporter
      def self.generate(json_path, output_dir, app_name, type = nil)
        return unless File.exist?(json_path)

        # Create output directory
        html_dir = if type && !type.to_s.empty?
                     File.join(output_dir, 'html', type, app_name)
                   else
                     File.join(output_dir, 'html', app_name)
                   end
        FileUtils.mkdir_p(html_dir)

        # Read JSON report
        report = JSON.parse(File.read(json_path))

        # Generate HTML
        html_content = generate_html(report, app_name, File.basename(json_path))

        # Save HTML report
        report_html = File.join(html_dir, 'report.html')
        File.write(report_html, html_content)

        # Return path for logging
        report_html
      end

      def self.generate_html(report, app_name, json_filename)
        scan_time = begin
          ts = report['timestamp']
          ts ? Time.parse(ts).strftime('%Y-%m-%d %H:%M:%S') : 'unknown'
        rescue StandardError
          'unknown'
        end
        
        severity_colors_hash = {
          'critical' => '#ff003c', # Neon Red
          'high' => '#ff8a00',     # Neon Orange
          'medium' => '#fcd000',   # Neon Yellow
          'low' => '#00f0ff',      # Neon Cyan
          'none' => '#4a4a4a'
        }
        severity_colors = severity_colors_hash.to_json

        findings = report['findings'] || []
        fs = report['findings_summary'] || {}
        cvss = report['cvss_analysis'] || {}
        attack_graph = report['attack_graph'] || {}
        payloads = report['payload_recommendations'] || {}
        owasp = report['owasp_compliance'] || { 'compliance_score' => 0 }
        risk = report['risk_summary'] || {}

        platform = report['platform'] || (report['ipa'] ? 'ios' : 'android')
        
        platform_details_html = ""
        if platform == 'ios'
          url_schemes = report.dig('evidence', 'url_schemes') || []
          entitlements = report.dig('evidence', 'entitlements') || {}
          ats = report.dig('evidence', 'ats') || {}
          permissions = report.dig('evidence', 'permissions') || {}
          binary_info = report.dig('evidence', 'binary_info') || {}

          platform_details_html = <<~HTML
            <div class="panel" style="margin-top: 2rem;">
              <div class="panel-header">
                <span>iOS CONFIGURATION ANALYSIS</span>
                <span style="font-family: 'Fira Code'; font-size: 0.8rem; color: var(--accent-glow);">[INFO.PLIST & PROVISIONING]</span>
              </div>
              
              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; margin-bottom: 2rem;">
                <!-- Info.plist / Metadata -->
                <div>
                  <h3 style="color: var(--accent-cyan); margin-bottom: 1rem; font-family: Orbitron; font-size: 1rem;">INFO.PLIST METADATA</h3>
                  <table class="data-table" style="width: 100%;">
                    <tr><td style="font-weight: bold; width: 40%;">Bundle ID</td><td>#{report.dig('evidence', 'bundle_id') || 'N/A'}</td></tr>
                    <tr><td style="font-weight: bold;">Bundle Name</td><td>#{report.dig('evidence', 'bundle_name') || 'N/A'}</td></tr>
                    <tr><td style="font-weight: bold;">Version</td><td>#{report.dig('evidence', 'version') || 'N/A'}</td></tr>
                    <tr><td style="font-weight: bold;">Minimum OS</td><td>#{report.dig('evidence', 'min_os') || 'N/A'}</td></tr>
                  </table>
                  
                  <h3 style="color: var(--accent-cyan); margin-top: 1.5rem; margin-bottom: 1rem; font-family: Orbitron; font-size: 1rem;">CUSTOM URL SCHEMES</h3>
                  #{if url_schemes.any?
                    "<ul>" + url_schemes.map { |s| "<li style='margin-left: 1.5rem; font-family: Fira Code; color: var(--accent-glow);'>#{s}://</li>" }.join + "</ul>"
                  else
                    "<p style='color: var(--text-muted);'>No custom URL schemes registered.</p>"
                  end}
                </div>

                <!-- Entitlements & ATS -->
                <div>
                  <h3 style="color: var(--accent-cyan); margin-bottom: 1rem; font-family: Orbitron; font-size: 1rem;">ENTITLEMENTS</h3>
                  #{if entitlements.any?
                    "<table class='data-table' style='width: 100%;'>" + entitlements.map { |k, v| "<tr><td style='font-family: Fira Code; font-size: 0.85rem;'>#{k}</td><td style='font-family: Fira Code; font-size: 0.85rem; color: var(--accent-glow);'>#{v}</td></tr>" }.join + "</table>"
                  else
                    "<p style='color: var(--text-muted);'>No custom entitlements parsed (App Store or Simulator build).</p>"
                  end}

                  <h3 style="color: var(--accent-cyan); margin-top: 1.5rem; margin-bottom: 1rem; font-family: Orbitron; font-size: 1rem;">APP TRANSPORT SECURITY (ATS)</h3>
                  #{if ats.any?
                    "<pre>#{JSON.pretty_generate(ats)}</pre>"
                  else
                    "<p style='color: var(--text-muted);'>ATS defaults (strict HTTPS enforced).</p>"
                  end}
                </div>
              </div>

              <!-- iOS Privacy Permissions -->
              <h3 style="color: var(--accent-cyan); margin-bottom: 1rem; font-family: Orbitron; font-size: 1rem;">PRIVACY PERMISSIONS (USAGE DESCRIPTIONS)</h3>
              #{if permissions.any?
                "<table class='data-table' style='width: 100%;'>" + permissions.map { |k, v| "<tr><td style='font-weight: bold; width: 40%;'>#{k}</td><td>#{v}</td></tr>" }.join + "</table>"
              else
                "<p style='color: var(--text-muted);'>No privacy permissions requested in Info.plist.</p>"
              end}

              <!-- Mach-O Binary Protections Summary -->
              <h3 style="color: var(--accent-cyan); margin-top: 1.5rem; margin-bottom: 1rem; font-family: Orbitron; font-size: 1rem;">MACH-O BINARY PROTECTIONS</h3>
              #{if binary_info.any?
                "
                <div style='display: grid; grid-template-columns: repeat(4, 1fr); gap: 1rem;'>
                  <div class='widget' style='padding: 1rem; text-align: center;'>
                    <div class='widget-title'>PIE</div>
                    <div class='widget-value' style='font-size: 1.5rem; color: #{binary_info[:pie] || binary_info['pie'] ? 'var(--accent-glow)' : 'var(--accent-red)'}'>#{binary_info[:pie] || binary_info['pie'] ? 'ENABLED' : 'DISABLED'}</div>
                  </div>
                  <div class='widget' style='padding: 1rem; text-align: center;'>
                    <div class='widget-title'>ARC</div>
                    <div class='widget-value' style='font-size: 1.5rem; color: #{binary_info[:arc] || binary_info['arc'] ? 'var(--accent-glow)' : 'var(--accent-red)'}'>#{binary_info[:arc] || binary_info['arc'] ? 'ENABLED' : 'DISABLED'}</div>
                  </div>
                  <div class='widget' style='padding: 1rem; text-align: center;'>
                    <div class='widget-title'>Stack Canary</div>
                    <div class='widget-value' style='font-size: 1.5rem; color: #{binary_info[:stack_canary] || binary_info['stack_canary'] ? 'var(--accent-glow)' : 'var(--accent-red)'}'>#{binary_info[:stack_canary] || binary_info['stack_canary'] ? 'PRESENT' : 'MISSING'}</div>
                  </div>
                  <div class='widget' style='padding: 1rem; text-align: center;'>
                    <div class='widget-title'>App Encryption</div>
                    <div class='widget-value' style='font-size: 1.5rem; color: #{binary_info.dig('encrypted_details', 'encrypted') || binary_info.dig(:encrypted_details, :encrypted) ? 'var(--accent-glow)' : 'var(--accent-red)'}'>#{binary_info.dig('encrypted_details', 'encrypted') || binary_info.dig(:encrypted_details, :encrypted) ? 'ENCRYPTED' : 'UNENCRYPTED'}</div>
                  </div>
                </div>
                "
              else
                "<p style='color: var(--text-muted);'>No Mach-O binary info available.</p>"
              end}
            </div>
          HTML
        else
          permissions = report.dig('evidence', 'permissions') || []
          dangerous_perms = report.dig('evidence', 'dangerous_permissions') || []
          
          activities = findings.count { |f| f['id'] == 'exported_activity_without_permission' }
          services = findings.count { |f| f['id'] == 'exported_service_without_permission' }
          receivers = findings.count { |f| f['id'] == 'exported_receiver_without_permission' }
          providers = findings.count { |f| f['id'] == 'exported_provider_without_permission' }

          platform_details_html = <<~HTML
            <div class="panel" style="margin-top: 2rem;">
              <div class="panel-header">
                <span>Android MANIFEST & PERMISSIONS ANALYSIS</span>
                <span style="font-family: 'Fira Code'; font-size: 0.8rem; color: var(--accent-glow);">[ANDROIDMANIFEST.XML]</span>
              </div>

              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; margin-bottom: 2rem;">
                <!-- Component summary -->
                <div>
                  <h3 style="color: var(--accent-cyan); margin-bottom: 1rem; font-family: Orbitron; font-size: 1rem;">EXPORTED COMPONENT SUMMARY</h3>
                  <table class="data-table" style="width: 100%;">
                    <tr><td style="font-weight: bold; width: 60%;">Exported Activities Without Permission</td><td style="color: #{activities > 0 ? 'var(--accent-red)' : 'var(--accent-glow)'}; font-weight: bold;">#{activities}</td></tr>
                    <tr><td style="font-weight: bold;">Exported Services Without Permission</td><td style="color: #{services > 0 ? 'var(--accent-red)' : 'var(--accent-glow)'}; font-weight: bold;">#{services}</td></tr>
                    <tr><td style="font-weight: bold;">Exported Broadcast Receivers Without Permission</td><td style="color: #{receivers > 0 ? 'var(--accent-red)' : 'var(--accent-glow)'}; font-weight: bold;">#{receivers}</td></tr>
                    <tr><td style="font-weight: bold;">Exported Content Providers Without Permission</td><td style="color: #{providers > 0 ? 'var(--accent-red)' : 'var(--accent-glow)'}; font-weight: bold;">#{providers}</td></tr>
                  </table>
                </div>

                <!-- Permissions Summary -->
                <div>
                  <h3 style="color: var(--accent-cyan); margin-bottom: 1rem; font-family: Orbitron; font-size: 1rem;">DANGEROUS PERMISSIONS REQUESTED</h3>
                  #{if dangerous_perms.any?
                    "<ul>" + dangerous_perms.map { |p| "<li style='margin-left: 1.5rem; font-family: Fira Code; color: var(--accent-red);'>#{p}</li>" }.join + "</ul>"
                  else
                    "<p style='color: var(--accent-glow);'>No dangerous permissions requested.</p>"
                  end}
                </div>
              </div>

              <h3 style="color: var(--accent-cyan); margin-bottom: 1rem; font-family: Orbitron; font-size: 1rem;">ALL REQUESTED PERMISSIONS</h3>
              <div style="max-height: 200px; overflow-y: auto; background: rgba(0,0,0,0.3); padding: 1rem; border-radius: 8px; border: 1px solid rgba(255,255,255,0.05);">
                #{if permissions.any?
                  permissions.map { |p| "<div style='font-family: Fira Code; font-size: 0.85rem; margin-bottom: 4px; color: var(--text-muted);'>#{p}</div>" }.join
                else
                  "<p style='color: var(--text-muted);'>No permissions requested.</p>"
                end}
              </div>
            </div>
          HTML
        end

        <<~HTML
<!DOCTYPE html>
<html lang="en" class="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MPF | #{app_name} Security Intel</title>
  <link href="https://fonts.googleapis.com/css2?family=Fira+Code:wght@400;600&family=Orbitron:wght@500;700&family=Inter:wght@400;500;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg-base: #050505;
      --bg-panel: rgba(15, 20, 25, 0.7);
      --bg-panel-hover: rgba(25, 30, 35, 0.9);
      --accent-glow: #00ff88;
      --accent-cyan: #00f0ff;
      --accent-red: #ff003c;
      --text-main: #e2e8f0;
      --text-muted: #94a3b8;
      --border-color: rgba(0, 255, 136, 0.15);
      --glass-blur: blur(12px);
    }
    
    * { box-sizing: border-box; margin: 0; padding: 0; }
    
    body {
      font-family: 'Inter', sans-serif;
      background-color: var(--bg-base);
      color: var(--text-main);
      background-image: 
        radial-gradient(circle at 15% 50%, rgba(0, 255, 136, 0.03) 0%, transparent 50%),
        radial-gradient(circle at 85% 30%, rgba(0, 240, 255, 0.03) 0%, transparent 50%),
        linear-gradient(rgba(0,255,136,0.02) 1px, transparent 1px),
        linear-gradient(90deg, rgba(0,255,136,0.02) 1px, transparent 1px);
      background-size: 100% 100%, 100% 100%, 30px 30px, 30px 30px;
      overflow-x: hidden;
    }

    /* Cinematic Boot Sequence */
    #boot-sequence {
      position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
      background: #000; z-index: 9999;
      display: flex; flex-direction: column; justify-content: center; align-items: center;
      font-family: 'Fira Code', monospace; color: var(--accent-glow);
      transition: opacity 0.8s ease-out;
    }
    .boot-log { width: 80%; max-width: 600px; height: 300px; overflow: hidden; font-size: 0.9rem; text-shadow: 0 0 5px var(--accent-glow); }
    .boot-cursor { display: inline-block; width: 10px; height: 1.2em; background: var(--accent-glow); animation: blink 1s step-end infinite; }
    @keyframes blink { 50% { opacity: 0; } }
    
    .dashboard-container { max-width: 1600px; margin: 0 auto; padding: 2rem; opacity: 0; transform: translateY(20px); transition: all 1s ease-out; }
    .dashboard-container.loaded { opacity: 1; transform: translateY(0); }

    /* Top Navigation / Controls */
    .top-bar {
      display: flex; justify-content: space-between; align-items: center;
      margin-bottom: 2rem; padding: 1rem 2rem;
      background: var(--bg-panel); backdrop-filter: var(--glass-blur);
      border: 1px solid var(--border-color); border-radius: 12px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.3);
    }
    .logo { font-family: 'Orbitron', sans-serif; font-size: 1.5rem; letter-spacing: 2px; color: var(--accent-glow); text-shadow: 0 0 10px rgba(0,255,136,0.5); }
    .view-toggles button {
      background: transparent; border: 1px solid var(--border-color); color: var(--text-muted);
      padding: 0.5rem 1.5rem; border-radius: 4px; font-family: 'Fira Code', monospace; font-size: 0.85rem;
      cursor: pointer; transition: all 0.3s ease; margin-left: 10px;
    }
    .view-toggles button.active {
      background: rgba(0, 255, 136, 0.1); border-color: var(--accent-glow); color: var(--accent-glow);
      box-shadow: 0 0 15px rgba(0,255,136,0.2) inset;
    }

    /* Header Info */
    .target-header {
      display: grid; grid-template-columns: 1fr auto; gap: 2rem; margin-bottom: 2rem;
      background: linear-gradient(145deg, var(--bg-panel), rgba(5,5,5,0.8));
      border: 1px solid var(--border-color); border-radius: 16px; padding: 2.5rem;
      position: relative; overflow: hidden;
    }
    .target-header::before {
      content: ''; position: absolute; top: 0; left: 0; width: 4px; height: 100%;
      background: linear-gradient(to bottom, var(--accent-glow), var(--accent-cyan));
      box-shadow: 0 0 15px var(--accent-glow);
    }
    .target-info h1 { font-family: 'Orbitron', sans-serif; font-size: 3rem; margin-bottom: 0.5rem; text-transform: uppercase; }
    .target-meta { display: flex; gap: 2rem; font-family: 'Fira Code', monospace; color: var(--text-muted); font-size: 0.9rem; }
    .risk-badge {
      display: flex; flex-direction: column; align-items: center; justify-content: center;
      width: 120px; height: 120px; border-radius: 50%;
      background: rgba(0,0,0,0.5); border: 2px solid;
      box-shadow: inset 0 0 20px rgba(0,0,0,0.8);
    }
    .risk-score { font-family: 'Orbitron', sans-serif; font-size: 2.5rem; font-weight: bold; }
    .risk-label { font-size: 0.8rem; text-transform: uppercase; letter-spacing: 1px; }

    /* Widgets Grid */
    .widgets-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem; margin-bottom: 2rem; }
    .widget {
      background: var(--bg-panel); backdrop-filter: var(--glass-blur);
      border: 1px solid rgba(255,255,255,0.05); border-radius: 12px;
      padding: 1.5rem; position: relative; overflow: hidden;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .widget:hover { transform: translateY(-3px); box-shadow: 0 10px 20px rgba(0,0,0,0.4), inset 0 0 0 1px var(--border-color); }
    .widget-title { font-family: 'Fira Code', monospace; font-size: 0.8rem; color: var(--text-muted); text-transform: uppercase; margin-bottom: 1rem; }
    .widget-value { font-family: 'Orbitron', sans-serif; font-size: 2.5rem; font-weight: bold; }
    
    .glow-red { color: var(--accent-red); text-shadow: 0 0 15px rgba(255,0,60,0.4); }
    .glow-orange { color: #ff8a00; text-shadow: 0 0 15px rgba(255,138,0,0.4); }
    .glow-green { color: var(--accent-glow); text-shadow: 0 0 15px rgba(0,255,136,0.4); }

    /* Panels */
    .panel-container { display: grid; grid-template-columns: 2fr 1fr; gap: 2rem; margin-bottom: 2rem; }
    @media (max-width: 1024px) { .panel-container { grid-template-columns: 1fr; } }
    
    .panel {
      background: var(--bg-panel); backdrop-filter: var(--glass-blur);
      border: 1px solid rgba(255,255,255,0.05); border-radius: 16px;
      padding: 2rem;
    }
    .panel-header { font-family: 'Orbitron', sans-serif; font-size: 1.2rem; margin-bottom: 1.5rem; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 1rem; }

    /* Tables */
    .data-table { width: 100%; border-collapse: separate; border-spacing: 0 8px; }
    .data-table th { text-align: left; padding: 1rem; font-family: 'Fira Code', monospace; font-size: 0.8rem; color: var(--text-muted); text-transform: uppercase; border-bottom: 1px solid rgba(255,255,255,0.05); }
    .data-table td { padding: 1rem; background: rgba(0,0,0,0.2); transition: background 0.2s ease; }
    .data-table tr { cursor: pointer; }
    .data-table tr:hover td { background: rgba(0,255,136,0.05); }
    .data-table td:first-child { border-top-left-radius: 8px; border-bottom-left-radius: 8px; font-family: 'Fira Code', monospace; }
    .data-table td:last-child { border-top-right-radius: 8px; border-bottom-right-radius: 8px; }
    
    .badge { padding: 0.25rem 0.75rem; border-radius: 12px; font-size: 0.75rem; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; font-family: 'Orbitron', sans-serif; }
    .badge.critical { background: rgba(255,0,60,0.15); color: var(--accent-red); border: 1px solid var(--accent-red); box-shadow: 0 0 10px rgba(255,0,60,0.3); }
    .badge.high { background: rgba(255,138,0,0.15); color: #ff8a00; border: 1px solid #ff8a00; box-shadow: 0 0 10px rgba(255,138,0,0.3); }
    .badge.medium { background: rgba(252,208,0,0.15); color: #fcd000; border: 1px solid #fcd000; }
    .badge.low { background: rgba(0,240,255,0.15); color: var(--accent-cyan); border: 1px solid var(--accent-cyan); }

    /* Expandable Row Content */
    .row-detail { display: none; background: rgba(0,0,0,0.5); padding: 1.5rem; margin-top: -8px; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; border-top: 1px solid rgba(255,255,255,0.05); }
    tr.expanded + .row-detail-row .row-detail { display: block; animation: slideDown 0.3s ease-out; }
    @keyframes slideDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }

    /* Attack Paths Matrix */
    .attack-path {
      padding: 1rem; background: rgba(0,0,0,0.3); border-radius: 8px; margin-bottom: 1rem;
      border-left: 3px solid var(--accent-glow); position: relative;
    }
    .attack-path::before {
      content: ''; position: absolute; left: -3px; top: 0; width: 3px; height: 100%;
      background: var(--accent-glow); filter: blur(4px);
    }
    .path-step { display: inline-flex; align-items: center; margin-top: 0.5rem; font-family: 'Fira Code', monospace; font-size: 0.85rem; }
    .path-arrow { color: var(--text-muted); margin: 0 0.5rem; }

    /* Terminal Code Block */
    pre { background: #000; border-radius: 8px; padding: 1rem; border: 1px solid rgba(255,255,255,0.1); color: var(--accent-glow); font-family: 'Fira Code', monospace; font-size: 0.85rem; overflow-x: auto; white-space: pre-wrap; }
    
    /* Technical Only Elements */
    .tech-only { display: none; }
    body.technical-mode .tech-only { display: block; }
    body.technical-mode .exec-only { display: none; }

    /* Radar/Scanner Animation for Chart Placeholder */
    .scanner-box { position: relative; width: 100%; aspect-ratio: 1; border-radius: 50%; border: 1px solid rgba(0,255,136,0.2); overflow: hidden; display: flex; justify-content: center; align-items: center; }
    .scanner-line { position: absolute; top: 0; left: 50%; width: 50%; height: 50%; background: linear-gradient(90deg, transparent, rgba(0,255,136,0.5)); transform-origin: bottom left; animation: scan 4s linear infinite; }
    @keyframes scan { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
  </style>
</head>
<body>
  
  <!-- Cinematic Boot Sequence -->
  <div id="boot-sequence">
    <div style="font-family: 'Orbitron'; font-size: 3rem; margin-bottom: 2rem;">MPF CORE INITIALIZATION</div>
    <div class="boot-log" id="bootLog"></div>
    <div><span class="boot-cursor"></span></div>
  </div>

  <div class="dashboard-container" id="mainDashboard">
    
    <!-- Top Bar -->
    <div class="top-bar">
      <div class="logo">MPF // INTELLIGENCE</div>
      <div class="view-toggles">
        <button class="active" onclick="setViewMode('executive')">EXECUTIVE</button>
        <button onclick="setViewMode('technical')">TECHNICAL</button>
      </div>
    </div>

    <!-- Target Header -->
    <div class="target-header">
      <div class="target-info">
        <h1>#{app_name}</h1>
        <div class="target-meta">
          <span class="badge #{platform == 'ios' ? 'low' : 'high'}" style="font-size: 0.8rem; padding: 0.2rem 0.6rem; vertical-align: middle; margin-right: 8px;">#{platform.upcase}</span>
          <span>PKG: #{report['package']}</span>
          <span>SCAN DATE: #{scan_time}</span>
          <span class="tech-only">ENGINE_VERSION: MPF-V2.1.0</span>
        </div>
      </div>
      <div class="risk-badge" style="border-color: #{severity_colors_hash[risk['overall_severity']] || '#4a4a4a'}">
        <div class="risk-score" style="color: #{severity_colors_hash[risk['overall_severity']] || '#fff'}">
          #{risk['overall_risk'] || 0}
        </div>
        <div class="risk-label">RISK FACTOR</div>
      </div>
    </div>

    <!-- Executive Summary Widgets -->
    <div class="widgets-grid">
      <div class="widget">
        <div class="widget-title">Total Findings</div>
        <div class="widget-value">#{fs['total'] || 0}</div>
      </div>
      <div class="widget">
        <div class="widget-title">Critical & High</div>
        <div class="widget-value glow-red">#{(fs['critical'] || 0) + (fs['high'] || 0)}</div>
      </div>
      <div class="widget">
        <div class="widget-title">OWASP Compliance</div>
        <div class="widget-value #{ (owasp['compliance_score'] || 0) < 50 ? 'glow-red' : (owasp['compliance_score'] || 0) < 80 ? 'glow-orange' : 'glow-green' }">
          #{owasp['compliance_score'] || 0}%
        </div>
      </div>
      <div class="widget">
        <div class="widget-title">Exploit Probability</div>
        <div class="widget-value glow-orange">#{risk['exploitation_probability'] || 0}%</div>
      </div>
    </div>

    <!-- Panels -->
    <div class="panel-container">
      
      <!-- Main Findings -->
      <div class="panel">
        <div class="panel-header">
          <span>VULNERABILITY MATRIX</span>
          <span class="tech-only" style="font-family: 'Fira Code'; font-size: 0.8rem; color: var(--accent-glow);">[RAW DATA DECODED]</span>
        </div>
        <table class="data-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Severity</th>
              <th>Vulnerability</th>
              <th>OWASP Area</th>
              <th class="tech-only">CVSS</th>
            </tr>
          </thead>
          <tbody>
            #{findings.map { |f|
              sev = (f['cvss_severity'] || f[:cvss_severity] || 'unknown').downcase
              desc = f['description'] || f[:description] || 'N/A'
              reason = f.dig('explanation', 'why_matters') || 'No deep explanation available.'
              attacker_can = f.dig('explanation', 'attacker_can') ? Array(f['explanation']['attacker_can']).join(", ") : 'Undetermined impacts.'
              "
              <tr onclick='toggleExpand(this)'>
                <td>#{f['id']}</td>
                <td><span class='badge #{sev}'>#{sev}</span></td>
                <td>#{desc.slice(0, 50)}#{desc.length > 50 ? '...' : ''}</td>
                <td>#{f['owasp_category'] || 'N/A'}</td>
                <td class='tech-only' style='font-family: Fira Code'>#{f['cvss_score'] || f[:cvss_score] || 'N/A'}</td>
              </tr>
              <tr class='row-detail-row'>
                <td colspan='5' style='padding:0;'>
                  <div class='row-detail'>
                    <h4 style='color: var(--accent-glow); margin-bottom: 10px; font-family: Orbitron;'>ANALYSIS TRACE: #{f['id']}</h4>
                    <p style='margin-bottom: 15px; color: #fff;'>#{desc}</p>
                    <div style='display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; font-size: 0.9rem; color: var(--text-muted);'>
                      <div>
                        <strong style='color: #fff;'>Impact:</strong><br>#{reason}
                      </div>
                      <div>
                        <strong style='color: #fff;'>Attacker Capability:</strong><br>#{attacker_can}
                      </div>
                    </div>
                    <div class='tech-only' style='margin-top: 15px;'>
                      <strong style='color: #fff;'>Raw Context:</strong>
                      <pre>#{JSON.pretty_generate(f.reject{|k,v| k == 'explanation'})}</pre>
                    </div>
                  </div>
                </td>
              </tr>
              "
            }.join}
          </tbody>
        </table>
      </div>

      <!-- Right Column -->
      <div>
        <div class="panel" style="margin-bottom: 2rem;">
          <div class="panel-header">SEVERITY DISTRIBUTION</div>
          <div class="scanner-box" style="margin: 0 auto; max-width: 250px;">
            <div class="scanner-line"></div>
            <!-- Canvas positioned over scanner -->
            <canvas id="severityChart" style="position: absolute; width: 100%; height: 100%; z-index: 10;"></canvas>
          </div>
          <div style="margin-top: 1rem; text-align: center; font-family: 'Fira Code'; font-size: 0.8rem; color: var(--text-muted);">
            RADAR ANALYSIS COMPLETE
          </div>
        </div>

        <div class="panel tech-only">
          <div class="panel-header">ATTACK CHAINS</div>
          #{if attack_graph['active_paths'] && !attack_graph['active_paths'].empty?
            attack_graph['active_paths'].map { |path|
              "
              <div class='attack-path'>
                <div style='color: #fff; font-weight: bold;'>#{path['name'] || path[:name]}</div>
                <div style='color: var(--accent-red); font-family: Fira Code; font-size: 0.8rem; margin: 4px 0;'>Risk Score: #{path['risk_score'] || path[:risk_score]}</div>
                <div style='color: var(--text-muted); font-size: 0.85rem;'>#{path['description'] || path[:description] || 'Exported Component Analysis'}</div>
                <div class='path-step'>
                  <span style='background: rgba(0,255,136,0.2); padding: 2px 6px; border-radius: 4px;'>ENTRY</span>
                  <span class='path-arrow'>→</span>
                  <span style='background: rgba(255,138,0,0.2); padding: 2px 6px; border-radius: 4px;'>EXPLOIT</span>
                  <span class='path-arrow'>→</span>
                  <span style='background: rgba(255,0,60,0.2); padding: 2px 6px; border-radius: 4px;'>IMPACT</span>
                </div>
              </div>
              "
            }.join
          else
            '<p style="color: var(--text-muted); font-family: Fira Code;">NO ATTACK CHAINS COMPILED</p>'
          end}
        </div>

        <div class="panel tech-only" style="margin-top: 2rem;">
          <div class="panel-header">RECOMMENDED PAYLOADS</div>
          #{if payloads['recommendations'] && !payloads['recommendations'].empty?
            payloads['recommendations'].first(5).map { |r|
              "
              <div class='attack-path' style='border-left-color: var(--accent-cyan);'>
                <div style='color: #fff; font-weight: bold;'>#{r['payload'] || r[:payload]}</div>
                <div style='color: var(--accent-cyan); font-family: Fira Code; font-size: 0.8rem; margin: 4px 0;'>Confidence: #{r['confidence'] || r[:confidence]}%</div>
                <div style='color: var(--text-muted); font-size: 0.85rem;'>#{r['reason'] || r[:reason]}</div>
              </div>
              "
            }.join
          else
            '<p style="color: var(--text-muted); font-family: Fira Code;">NO PAYLOADS RECOMMENDED</p>'
          end}
        </div>
      </div>
      
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script>
    // Boot sequence animation
    const bootLines = [
      "INIT: Establishing secure connection...",
      "AUTH: Verifying agent credentials... [SUCCESS]",
      "KERNEL: Loading virtual memory modules...",
      "SCAN: Parsing AndroidManifest.xml...",
      "SCAN: Decompiling native binaries...",
      "ENGINE: Cross-referencing OWASP matrices...",
      "ENGINE: Generating attack paths...",
      "SYSTEM: Decrypting intelligence payload...",
      "SYSTEM: Welcome to MPF."
    ];
    
    document.addEventListener("DOMContentLoaded", () => {
      const logContainer = document.getElementById('bootLog');
      let lineIdx = 0;
      
      function printLine() {
        if (lineIdx < bootLines.length) {
          logContainer.innerHTML += `<div>> ${bootLines[lineIdx]}</div>`;
          lineIdx++;
          setTimeout(printLine, Math.random() * 150 + 50);
        } else {
          setTimeout(() => {
            document.getElementById('boot-sequence').style.opacity = '0';
            setTimeout(() => {
              document.getElementById('boot-sequence').style.display = 'none';
              document.getElementById('mainDashboard').classList.add('loaded');
              initChart();
            }, 800);
          }, 500);
        }
      }
      setTimeout(printLine, 300);
    });

    // View Modes
    function setViewMode(mode) {
      document.body.className = mode === 'technical' ? 'technical-mode dark' : 'dark';
      const btns = document.querySelectorAll('.view-toggles button');
      btns[0].className = mode === 'executive' ? 'active' : '';
      btns[1].className = mode === 'technical' ? 'active' : '';
    }

    // Toggle Expansion
    function toggleExpand(row) {
      row.classList.toggle('expanded');
    }

    // Chart.js init
    function initChart() {
      const ctx = document.getElementById('severityChart').getContext('2d');
      const dist = {
        critical: #{cvss['distribution']&.[]('critical') || 0},
        high: #{cvss['distribution']&.[]('high') || 0},
        medium: #{cvss['distribution']&.[]('medium') || 0},
        low: #{cvss['distribution']&.[]('low') || 0}
      };
      
      // If all zero, put a dummy
      if(Object.values(dist).reduce((a,b)=>a+b,0) === 0) { dist.low = 1; }

      new Chart(ctx, {
        type: 'doughnut',
        data: {
          labels: ['Critical', 'High', 'Medium', 'Low'],
          datasets: [{
            data: [dist.critical, dist.high, dist.medium, dist.low],
            backgroundColor: ['#ff003c', '#ff8a00', '#fcd000', '#00f0ff'],
            borderWidth: 0,
            hoverOffset: 10
          }]
        },
        options: {
          cutout: '75%',
          plugins: {
            legend: { display: false }
          },
          animation: {
            animateScale: true,
            animateRotate: true
          }
        }
      });
    }
  </script>
</body>
</html>
        HTML
      end
    end
  end
end
