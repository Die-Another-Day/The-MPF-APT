require_relative '../../analysis/rules/base_rule'
require 'pathname'

module MPF
  module Analysis
    module Rules
      class IOSM2InsecureStorageRule < BaseRule
        def initialize
          super(
            id: 'IOS-M2-INSECURE-STORAGE',
            name: 'iOS Insecure Data Storage',
            owasp_category: 'M2',
            severity: :high,
            description: 'Detection of unencrypted NSUserDefaults usage, exposed database files, or certificate assets inside the application bundle.',
            remediation: 'Use Keychain services for sensitive values (tokens, keys). Store application databases in protected directories using encryption.',
            detection_logic: ->(context) { detect(context) }
          )
        end

        def detect(context)
          findings = []
          decoded_dir = context[:decoded_dir]
          app_dir = context[:app_dir]

          return [] unless decoded_dir

          # 1. NSUserDefaults Scan in code
          Dir.glob("#{decoded_dir}/**/*.{swift,m,h}") do |file|
            next if File.directory?(file)
            
            content = BaseRule.safe_read(file)
            next if content.empty?

            if content.match?(/UserDefaults\.standard/i) || content.match?(/NSUserDefaults/i)
              relative_path = Pathname.new(file).relative_path_from(Pathname.new(decoded_dir)).to_s
              findings << {
                id: "ios_nsuserdefaults_usage",
                owasp: 'M2',
                severity: :medium,
                description: "Usage of NSUserDefaults/UserDefaults standard store detected. Ensure no credentials or PII are stored here as they reside in plaintext plists.",
                component: relative_path,
                evidence: "UserDefaults standard store usage"
              }
            end
          end

          # 2. Sensitive files inside the App bundle
          if app_dir && File.directory?(app_dir)
            sensitive_exts = ['*.sqlite', '*.sqlite3', '*.db', '*.key', '*.pem', '*.p12', '*.cer', '*.pfx']
            sensitive_exts.each do |pattern|
              Dir.glob(File.join(app_dir, "**", pattern)) do |file|
                next if File.directory?(file)
                relative_path = Pathname.new(file).relative_path_from(Pathname.new(decoded_dir)).to_s
                findings << {
                  id: "ios_exposed_sensitive_file",
                  owasp: 'M2',
                  severity: :high,
                  description: "Exposed database, key, or certificate file packaged within the application bundle: #{File.basename(file)}.",
                  component: relative_path,
                  evidence: "Exposed asset file: #{File.basename(file)}"
                }
              end
            end
          end

          findings
        end
      end
    end
  end
end
