require_relative '../../../core/payload_base'
require 'readline'

module MPF
  module Payloads
    module Meterpreter
      module Android
        class AppShell < MPF::Core::PayloadBase
          
          def register_info
            @info = {
              name: 'Android App Shell (Meterpreter-style)',
              module: 'payload/android/meterpreter/app_shell',
              platform: :android,
              description: 'Interactive app-level shell for runtime manipulation. ' \
                          'Provides commands for data extraction, method hooking, and runtime analysis.',
              authors: ['MPF Research Team'],
              severity: 'critical'
            }
            @payload_type = :meterpreter
          end

          def register_options
            add_option('TARGET_PACKAGE', 'Target application package name', required: true)
            add_option('DEVICE', 'Target device ID', default: 'emulator-5554')
          end

          def generate(opts = {})
            {
              type: 'interactive_shell',
              description: 'App-level meterpreter shell',
              impact: 'Full runtime control over target application'
            }
          end

          def execute(target_info)
            validation = validate
            unless validation[:valid]
              return { success: false, error: validation[:errors] }
            end

            package = get_option('TARGET_PACKAGE')
            device = get_option('DEVICE')

            print_good("App Shell session established")
            print_status("Target: #{package}")
            print_status("Device: #{device}")
            print_status("Type 'help' for available commands")
            
            # Start interactive shell
            start_shell(package, device)
            
            {
              success: true,
              impact: 'Interactive session completed'
            }
          end

          private

          def start_shell(package, device)
            puts "\n" + "=" * 60
            puts "MPF App Shell - #{package}"
            puts "=" * 60 + "\n"

            @session_active = true
            @package = package
            @device = device

            while @session_active
              begin
                input = Readline.readline("app_shell > ", true)
                next if input.nil? || input.strip.empty?

                handle_command(input.strip)
              rescue Interrupt
                puts "\nUse 'exit' to close session"
              end
            end
          end

          def handle_command(cmd)
            case cmd
            when 'help'
              show_shell_help
            when 'exit', 'quit'
              @session_active = false
              puts "Session closed"
            when /^dump_data\s+(.+)/
              dump_app_data($1.strip)
            when /^list_activities/
              list_activities
            when /^list_services/
              list_services
            when /^list_providers/
              list_providers
            when /^screenshot/
              take_screenshot
            when /^logcat\s*(\d*)/
              show_logcat($1.to_i > 0 ? $1.to_i : 50)
            when /^pull\s+(.+)/
              pull_file($1.strip)
            when /^push\s+(.+)\s+(.+)/
              push_file($1.strip, $2.strip)
            when /^ps/
              show_process_info
            when /^intent\s+(.+)/
              send_intent($1.strip)
            when /^broadcast\s+(.+)/
              send_broadcast($1.strip)
            when /^start_activity\s+(.+)/
              start_activity($1.strip)
            when /^stop_app/
              stop_application
            when /^clear_data/
              clear_app_data
            when /^permissions/
              show_permissions
            when /^network/
              show_network_connections
            when /^storage/
              show_storage_usage
            when /^keylog\s+(\d+)/
              start_keylogging($1.to_i)
            when /^record\s+(\d+)/
              record_screen($1.to_i)
            when /^clipboard/
              get_clipboard
            else
              puts "Unknown command: #{cmd}"
              puts "Type 'help' for available commands"
            end
          end

          def show_shell_help
            puts "\nApp Shell Commands:\n\n"
            puts "  Core Commands:"
            puts "  help                    - Show this help"
            puts "  exit                    - Close session"
            puts ""
            puts "  Information Gathering:"
            puts "  list_activities         - List all activities"
            puts "  list_services           - List all services"
            puts "  list_providers          - List all content providers"
            puts "  ps                      - Show process information"
            puts "  permissions             - Show app permissions"
            puts "  network                 - Show network connections"
            puts "  storage                 - Show storage usage"
            puts ""
            puts "  Data Extraction:"
            puts "  dump_data <path>        - Dump app data directory"
            puts "  pull <remote_path>      - Pull file from device"
            puts "  push <local> <remote>   - Push file to device"
            puts "  screenshot              - Capture device screenshot"
            puts "  clipboard               - Get clipboard contents"
            puts ""
            puts "  Runtime Manipulation:"
            puts "  intent <component>      - Send intent to component"
            puts "  broadcast <action>      - Send broadcast intent"
            puts "  start_activity <name>   - Start specific activity"
            puts "  stop_app                - Force stop application"
            puts "  clear_data              - Clear application data"
            puts ""
            puts "  Monitoring:"
            puts "  logcat [lines]          - Show recent logcat entries"
            puts "  keylog <seconds>        - Monitor input events"
            puts "  record <seconds>        - Record screen activity"
            puts
          end

          def dump_app_data(path)
            print_status("Dumping app data from: #{path}")
            cmd = "adb -s #{@device} shell run-as #{@package} ls -laR #{path}"
            output = `#{cmd} 2>&1`
            puts output
          end

          def list_activities
            print_status("Enumerating activities...")
            cmd = "adb -s #{@device} shell dumpsys package #{@package} | grep -A 20 'Activity'"
            output = `#{cmd} 2>&1`
            puts output
          end

          def list_services
            print_status("Enumerating services...")
            cmd = "adb -s #{@device} shell dumpsys package #{@package} | grep -A 20 'Service'"
            output = `#{cmd} 2>&1`
            puts output
          end

          def list_providers
            print_status("Enumerating content providers...")
            cmd = "adb -s #{@device} shell dumpsys package #{@package} | grep -A 20 'Provider'"
            output = `#{cmd} 2>&1`
            puts output
          end

          def take_screenshot
            filename = "screenshot_#{Time.now.to_i}.png"
            print_status("Capturing screenshot...")
            `adb -s #{@device} shell screencap -p /sdcard/#{filename}`
            `adb -s #{@device} pull /sdcard/#{filename} reports/payload/#{filename}`
            print_good("Screenshot saved to: reports/payload/#{filename}")
          end

          def show_logcat(lines)
            print_status("Fetching logcat (#{lines} lines)...")
            cmd = "adb -s #{@device} logcat -d -t #{lines} | grep #{@package}"
            output = `#{cmd} 2>&1`
            puts output
          end

          def pull_file(remote_path)
            filename = File.basename(remote_path)
            print_status("Pulling file: #{remote_path}")
            cmd = "adb -s #{@device} shell run-as #{@package} cat #{remote_path}"
            output = `#{cmd} 2>&1`
            
            if $?.success?
              File.write("reports/payload/#{filename}", output)
              print_good("File saved to: reports/payload/#{filename}")
            else
              print_error("Failed to pull file")
            end
          end

          def show_process_info
            print_status("Process information:")
            cmd = "adb -s #{@device} shell ps | grep #{@package}"
            output = `#{cmd} 2>&1`
            puts output
          end

          def send_intent(component)
            print_status("Sending intent to: #{component}")
            cmd = "adb -s #{@device} shell am start -n #{@package}/#{component}"
            output = `#{cmd} 2>&1`
            puts output
          end

          def push_file(local_path, remote_path)
            unless File.exist?(local_path)
              print_error("Local file not found: #{local_path}")
              return
            end

            print_status("Pushing file: #{local_path} -> #{remote_path}")
            cmd = "adb -s #{@device} shell run-as #{@package} cp /sdcard/temp_upload #{remote_path}"
            
            # First push to sdcard
            `adb -s #{@device} push #{local_path} /sdcard/temp_upload 2>&1`
            
            # Then move to app directory
            output = `#{cmd} 2>&1`
            
            if $?.success?
              print_good("File uploaded successfully")
              `adb -s #{@device} shell rm /sdcard/temp_upload 2>&1`
            else
              print_error("Upload failed: #{output}")
            end
          end

          def send_broadcast(action)
            print_status("Sending broadcast: #{action}")
            cmd = "adb -s #{@device} shell am broadcast -a #{action} -p #{@package}"
            output = `#{cmd} 2>&1`
            puts output
          end

          def start_activity(activity_name)
            print_status("Starting activity: #{activity_name}")
            cmd = "adb -s #{@device} shell am start -n #{@package}/#{activity_name}"
            output = `#{cmd} 2>&1`
            puts output
          end

          def stop_application
            print_status("Stopping application...")
            cmd = "adb -s #{@device} shell am force-stop #{@package}"
            output = `#{cmd} 2>&1`
            print_good("Application stopped")
          end

          def clear_app_data
            print_warning("This will clear all app data!")
            print_status("Clearing application data...")
            cmd = "adb -s #{@device} shell pm clear #{@package}"
            output = `#{cmd} 2>&1`
            puts output
          end

          def show_permissions
            print_status("Application permissions:")
            cmd = "adb -s #{@device} shell dumpsys package #{@package} | grep -A 50 'granted='"
            output = `#{cmd} 2>&1`
            puts output
          end

          def show_network_connections
            print_status("Network connections:")
            cmd = "adb -s #{@device} shell netstat | grep #{@package}"
            output = `#{cmd} 2>&1`
            
            if output.empty?
              puts "No active connections"
            else
              puts output
            end
          end

          def show_storage_usage
            print_status("Storage usage:")
            cmd = "adb -s #{@device} shell du -sh /data/data/#{@package}/*"
            output = `#{cmd} 2>&1`
            puts output
          end

          def start_keylogging(duration)
            print_status("Monitoring input events for #{duration} seconds...")
            print_warning("Press Ctrl+C to stop early")
            
            cmd = "adb -s #{@device} shell getevent -t"
            pid = spawn(cmd, out: "reports/payload/keylog_#{Time.now.to_i}.txt")
            
            sleep(duration)
            Process.kill('TERM', pid)
            
            print_good("Keylog saved to reports/payload/")
          end

          def record_screen(duration)
            filename = "screenrecord_#{Time.now.to_i}.mp4"
            remote_path = "/sdcard/#{filename}"
            local_path = "reports/payload/#{filename}"
            
            print_status("Recording screen for #{duration} seconds...")
            cmd = "adb -s #{@device} shell screenrecord --time-limit #{duration} #{remote_path}"
            
            system(cmd)
            
            print_status("Pulling recording...")
            `adb -s #{@device} pull #{remote_path} #{local_path} 2>&1`
            `adb -s #{@device} shell rm #{remote_path} 2>&1`
            
            print_good("Recording saved: #{local_path}")
          end

          def get_clipboard
            print_status("Reading clipboard...")
            cmd = "adb -s #{@device} shell service call clipboard 1 | grep -o '\".*\"' | sed 's/\"//g'"
            output = `#{cmd} 2>&1`
            
            if output.strip.empty?
              puts "Clipboard is empty"
            else
              puts "Clipboard content: #{output}"
            end
          end

          def print_status(msg)
            puts "[*] #{msg}"
          end

          def print_good(msg)
            puts "[+] #{msg}"
          end

          def print_error(msg)
            puts "[-] #{msg}"
          end

          def print_warning(msg)
            puts "[!] #{msg}"
          end
        end
      end
    end
  end
end
