require_relative 'base_rule'

module MPF
  module Analysis
    module Rules
      class M3ExportedComponentsRule < BaseRule
        def initialize
          super(
            id: 'M3-EXPORTED-COMPONENTS',
            name: 'Insecure Authentication/Authorization',
            owasp_category: 'M3',
            severity: :high,
            description: 'Exported components (Activity, Service, Receiver, Provider) without permission protection.',
            remediation: 'Set android:exported="false" or require a permission to access the component.',
            detection_logic: ->(context) { detect(context) }
          )
        end

        def detect(context)
          app = context[:manifest_app] # Expecting parsed application element
          return [] unless app

          findings = []

          # Check Activities
          app.elements.each("activity") do |activity|
            check_component(activity, "Activity", findings)
          end

          # Check Services
          app.elements.each("service") do |service|
            check_component(service, "Service", findings)
          end

          # Check Broadcast Receivers
          app.elements.each("receiver") do |receiver|
            check_component(receiver, "BroadcastReceiver", findings)
          end

          # Check Content Providers
          app.elements.each("provider") do |provider|
            check_component(provider, "ContentProvider", findings, true)
          end

          findings
        end

        private

        def check_component(element, type, findings, is_provider=false)
          name = element.attributes["android:name"]
          exported = element.attributes["android:exported"]
          permission = element.attributes["android:permission"]
          has_intent_filter = !element.elements["intent-filter"].nil?
          authorities = element.attributes["android:authorities"] if is_provider

          # Logic:
          # If exported="true" AND no permission -> Vulnerable
          # If exported is not set AND it has intent-filter -> Default is exported="true" (older Android) or "false" (newer),
          # but for security usually treated as potentially exported if intent-filter exists.
          # Providers are critical.

          is_vulnerable = false
          if exported == "true" && permission.nil?
            is_vulnerable = true
          elsif exported.nil? && has_intent_filter && permission.nil?
            is_vulnerable = true
          end

          if is_vulnerable
            severity = is_provider ? :critical : :high
            comp_name = is_provider ? (authorities || name) : name
            # Normalize ID to match attack graph / correlator expectations
            id_map = {
              'Activity'          => 'exported_activity_without_permission',
              'Service'           => 'exported_service_without_permission',
              'BroadcastReceiver' => 'exported_receiver_without_permission',
              'ContentProvider'   => 'exported_provider_without_permission'
            }
            findings << {
              id: id_map[type] || "exported_#{type.downcase}_without_permission",
              owasp: 'M3',
              severity: severity,
              description: "Exported #{type} without permission protection (M3)",
              component: comp_name,
              evidence: "exported=#{exported}, permission=#{permission}, intent-filter=#{has_intent_filter}"
            }
          end
        end
      end
    end
  end
end
