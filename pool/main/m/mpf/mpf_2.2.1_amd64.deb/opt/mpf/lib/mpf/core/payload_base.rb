module MPF
  module Core
    class PayloadBase
      attr_reader :info, :options, :payload_type

      def initialize
        @info = {}
        @options = {}
        @payload_type = :single # :single, :stager, :stage
        @compatible_platforms = [:android]
        @compatible_archs = [:arm, :arm64, :x86, :x86_64]
        
        register_info
        register_options
      end

      # Must be implemented by payload modules
      def register_info
        raise NotImplementedError, "Payload must implement register_info"
      end

      def register_options
        # Override to add payload-specific options
      end

      # Generate the payload (intent, script, APK, etc.)
      def generate(opts = {})
        raise NotImplementedError, "Payload must implement generate"
      end

      # Execute the payload on target
      def execute(target_info)
        raise NotImplementedError, "Payload must implement execute"
      end

      # Validate payload configuration
      def validate
        required_opts = @options.select { |_, v| v[:required] }
        missing = required_opts.keys.select { |k| @options[k][:value].nil? }
        
        if missing.any?
          return { valid: false, errors: "Missing required options: #{missing.join(', ')}" }
        end
        
        { valid: true }
      end

      # Set option value
      def set_option(key, value)
        key_sym = key.to_s.upcase.to_sym
        if @options.key?(key_sym)
          @options[key_sym][:value] = value
          true
        else
          false
        end
      end

      # Get option value
      def get_option(key)
        key_sym = key.to_s.upcase.to_sym
        @options[key_sym][:value] if @options.key?(key_sym)
      end

      # Display payload information
      def show_info
        output = "\n"
        output += "Name: #{@info[:name]}\n"
        output += "Module: #{@info[:module]}\n"
        output += "Platform: #{@info[:platform]}\n"
        output += "Type: #{@payload_type}\n"
        output += "Description:\n  #{@info[:description]}\n"
        output += "\nAuthor:\n"
        @info[:authors]&.each { |a| output += "  #{a}\n" }
        output
      end

      # Display payload options
      def show_options
        return "No options available" if @options.empty?
        
        output = "\nPayload Options:\n\n"
        output += sprintf("%-20s %-10s %-15s %s\n", "Name", "Required", "Current", "Description")
        output += "-" * 80 + "\n"
        
        @options.each do |key, opt|
          current = opt[:value] || opt[:default] || ""
          required = opt[:required] ? "yes" : "no"
          output += sprintf("%-20s %-10s %-15s %s\n", 
                           key.to_s, 
                           required, 
                           current.to_s[0..14], 
                           opt[:description])
        end
        
        output
      end

      protected

      def add_option(name, description, required: false, default: nil)
        @options[name.to_s.upcase.to_sym] = {
          description: description,
          required: required,
          default: default,
          value: default
        }
      end
    end
  end
end
