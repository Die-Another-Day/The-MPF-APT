module MPF
  module Standards
    class OWASPMobileTop10
      MD_TOP10 = {
        "M1" => {
          name: "Improper Credential Usage",
          description: "Hardcoded credentials, storing api keys in version control, etc.",
          severity: "HIGH",
          detection_rules: [
            "hardcoded_api_key",
            "hardcoded_password",
            "insecure_shared_prefs",
            "firebase_db_exposure"
          ],
          remediation: "Do not hardcode credentials. Use Keystore system. Encrypt sensitive data."
        },
        "M2" => {
          name: "Inadequate Supply Chain Security",
          description: "Vulnerabilities in third-party libraries, patching mechanisms, etc.",
          severity: "MEDIUM",
          detection_rules: [
            "vulnerable_library",
            "outdated_component",
            "known_vulnerable_sdk"
          ],
          remediation: "Keep libraries updated. Sign code. Monitor third-party SDKs."
        },
        "M3" => {
          name: "Insecure Authentication/Authorization",
          description: "Failures in authentication or authorization mechanisms.",
          severity: "HIGH",
          detection_rules: [
            "exported_activity_without_permission",
            "exported_service_without_permission",
            "exported_provider_without_permission",
            "exported_receiver_without_permission"
          ],
          remediation: "Enforce authentication on server side. Do not trust client-side checks."
        },
        "M4" => {
          name: "Insufficient Input/Output Validation",
          description: "Injection flaws (SQLi, XSS, etc.) and other input validation issues.",
          severity: "MEDIUM",
          detection_rules: [
            "sql_injection",
            "path_traversal",
            "intent_injection",
            "deeplink_injection"
          ],
          remediation: "Validate and sanitize all input. Use parameterized queries."
        },
        "M5" => {
          name: "Insecure Communication",
          description: "Cleartext traffic, weak SSL/TLS, insufficient certificate validation.",
          severity: "HIGH",
          detection_rules: [
            "cleartext_traffic_allowed",
            "weak_ssl_configuration",
            "trust_all_certs"
          ],
          remediation: "Use TLS 1.2+. Implement Certificate Pinning. Disallow cleartext traffic."
        },
        "M6" => {
          name: "Inadequate Privacy Controls",
          description: "PII leakage, excessive permissions, etc.",
          severity: "MEDIUM",
          detection_rules: [
            "pii_leakage",
            "excessive_permissions",
            "analytics_exposure"
          ],
          remediation: "Minimize data collection. Anonymize PII. Use privacy-preserving libraries."
        },
        "M7" => {
          name: "Insufficient Binary Protections",
          description: "Lack of obfuscation, root detection, anti-debugging.",
          severity: "MEDIUM",
          detection_rules: [
            "root_detection_missing",
            "debuggable_enabled",
            "obfuscation_missing"
          ],
          remediation: "Use ProGuard/R8. Implement root/jailbreak detection. Disable debugging."
        },
        "M8" => {
          name: "Security Misconfiguration",
          description: "Insecure default settings, sensitive data in logs, etc.",
          severity: "MEDIUM",
          detection_rules: [
            "allow_backup_enabled",
            "debuggable_enabled", # Overlaps with M7, but also a config issue
            "unprotected_exported_component"
          ],
          remediation: "Harden configurations. Disable backup. Review manifest settings."
        },
        "M9" => {
          name: "Insecure Data Storage",
          description: "Storing sensitive data in plaintext on the device.",
          severity: "HIGH",
          detection_rules: [
            "insecure_sqlite_storage",
            "insecure_file_storage",
            "world_readable_files",
            "world_writeable_files"
          ],
          remediation: "Encrypt sensitive data using EncryptedSharedPreferences or SQLCipher."
        },
        "M10" => {
          name: "Insufficient Cryptography",
          description: "Using weak algorithms, hardcoded keys, etc.",
          severity: "HIGH",
          detection_rules: [
            "weak_algorithm_usage",
            "hardcoded_encryption_key",
            "ecb_mode_usage"
          ],
          remediation: "Use strong algorithms (AES-GCM, SHA-256). Store keys in Keystore."
        }
      }

      def self.all
        MD_TOP10
      end

      def self.get(id)
        MD_TOP10[id]
      end
    end
  end
end
