module MPF
  class ModuleBase
    def initialize(options={})
      @options = options
    end

    def run(target)
      raise NotImplementedError, "Module must implement run()"
    end
  end
end
