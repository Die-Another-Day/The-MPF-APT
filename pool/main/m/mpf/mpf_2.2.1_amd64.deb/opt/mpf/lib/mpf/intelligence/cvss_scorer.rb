module MPF
  module Intelligence
    # CVSS v3.1 + OWASP Hybrid Scoring Engine
    class CVSSScorer
      SEVERITY_THRESHOLDS = {
        critical: 9.0,
        high:     7.0,
        medium:   4.0,
        low:      0.1,
        none:     0.0
      }.freeze

      # CVSS v3.1 base metric weights
      AV_SCORES  = { network: 0.85, adjacent: 0.62, local: 0.55, physical: 0.20 }.freeze
      AC_SCORES  = { low: 0.77, high: 0.44 }.freeze
      PR_SCORES  = { none: 0.85, low: 0.62, high: 0.27 }.freeze
      UI_SCORES  = { none: 0.85, required: 0.62 }.freeze
      SCOPE_MULT = { unchanged: 1.0, changed: 1.08 }.freeze
      C_SCORES   = { none: 0.0, low: 0.22, high: 0.56 }.freeze
      I_SCORES   = { none: 0.0, low: 0.22, high: 0.56 }.freeze
      A_SCORES   = { none: 0.0, low: 0.22, high: 0.56 }.freeze

      # Vulnerability type → CVSS vector mappings for Android and iOS
      VULN_VECTORS = {
        # Android Vulnerabilities
        'exported_provider_without_permission' => {
          av: :network, ac: :low, pr: :none, ui: :none,
          scope: :changed, c: :high, i: :high, a: :low,
          owasp_weight: 1.2
        },
        'exported_activity_without_permission' => {
          av: :network, ac: :low, pr: :none, ui: :required,
          scope: :unchanged, c: :high, i: :low, a: :low,
          owasp_weight: 1.0
        },
        'exported_service_without_permission' => {
          av: :network, ac: :low, pr: :none, ui: :none,
          scope: :unchanged, c: :low, i: :high, a: :low,
          owasp_weight: 1.0
        },
        'exported_receiver_without_permission' => {
          av: :network, ac: :low, pr: :none, ui: :none,
          scope: :unchanged, c: :low, i: :low, a: :low,
          owasp_weight: 0.8
        },
        'sql_injection' => {
          av: :network, ac: :low, pr: :none, ui: :none,
          scope: :changed, c: :high, i: :high, a: :low,
          owasp_weight: 1.3
        },
        'webview_js_enabled' => {
          av: :network, ac: :low, pr: :none, ui: :required,
          scope: :changed, c: :high, i: :high, a: :low,
          owasp_weight: 1.2
        },
        'webview_add_js_interface' => {
          av: :network, ac: :low, pr: :none, ui: :required,
          scope: :changed, c: :high, i: :high, a: :high,
          owasp_weight: 1.3
        },
        'cleartext_traffic_allowed' => {
          av: :adjacent, ac: :high, pr: :none, ui: :none,
          scope: :unchanged, c: :high, i: :low, a: :none,
          owasp_weight: 1.1
        },
        'hardcoded_google_api_key' => {
          av: :network, ac: :low, pr: :none, ui: :none,
          scope: :unchanged, c: :high, i: :low, a: :none,
          owasp_weight: 1.0
        },
        'hardcoded_aws_access_key' => {
          av: :network, ac: :low, pr: :none, ui: :none,
          scope: :changed, c: :high, i: :high, a: :high,
          owasp_weight: 1.4
        },
        'debuggable_enabled' => {
          av: :local, ac: :low, pr: :low, ui: :none,
          scope: :changed, c: :high, i: :high, a: :low,
          owasp_weight: 1.1
        },
        'allow_backup_enabled' => {
          av: :local, ac: :low, pr: :low, ui: :none,
          scope: :unchanged, c: :high, i: :low, a: :none,
          owasp_weight: 0.9
        },
        'world_readable_files' => {
          av: :local, ac: :low, pr: :low, ui: :none,
          scope: :unchanged, c: :high, i: :none, a: :none,
          owasp_weight: 0.9
        },
        'weak_algorithm_usage' => {
          av: :network, ac: :high, pr: :none, ui: :none,
          scope: :unchanged, c: :high, i: :none, a: :none,
          owasp_weight: 1.0
        },
        'ecb_mode_usage' => {
          av: :network, ac: :high, pr: :none, ui: :none,
          scope: :unchanged, c: :high, i: :none, a: :none,
          owasp_weight: 1.0
        },
        'path_traversal' => {
          av: :network, ac: :low, pr: :none, ui: :none,
          scope: :changed, c: :high, i: :high, a: :low,
          owasp_weight: 1.2
        },
        'root_detection_missing' => {
          av: :local, ac: :low, pr: :low, ui: :none,
          scope: :changed, c: :high, i: :high, a: :low,
          owasp_weight: 0.8
        },
        'pii_device_id' => {
          av: :local, ac: :low, pr: :low, ui: :none,
          scope: :unchanged, c: :low, i: :none, a: :none,
          owasp_weight: 0.7
        },

        # iOS Vulnerabilities (M1-M10)
        'ios_hardcoded_google_api_key' => { av: :network, ac: :low, pr: :none, ui: :none, scope: :unchanged, c: :high, i: :low, a: :none, owasp_weight: 1.0 },
        'ios_hardcoded_aws_access_key' => { av: :network, ac: :low, pr: :none, ui: :none, scope: :changed, c: :high, i: :high, a: :high, owasp_weight: 1.4 },
        'ios_hardcoded_firebase_url' => { av: :network, ac: :low, pr: :none, ui: :none, scope: :unchanged, c: :high, i: :none, a: :none, owasp_weight: 1.0 },
        'ios_hardcoded_private_key' => { av: :network, ac: :low, pr: :none, ui: :none, scope: :unchanged, c: :high, i: :none, a: :none, owasp_weight: 1.3 },
        'ios_hardcoded_generic_api_key' => { av: :network, ac: :low, pr: :none, ui: :none, scope: :unchanged, c: :high, i: :none, a: :none, owasp_weight: 1.0 },
        'ios_hardcoded_jwt_token' => { av: :network, ac: :low, pr: :none, ui: :none, scope: :unchanged, c: :high, i: :none, a: :none, owasp_weight: 1.1 },
        'ios_custom_url_scheme' => { av: :network, ac: :low, pr: :none, ui: :required, scope: :changed, c: :high, i: :high, a: :low, owasp_weight: 1.1 },
        'ios_keychain_sharing_enabled' => { av: :local, ac: :low, pr: :low, ui: :none, scope: :unchanged, c: :low, i: :low, a: :none, owasp_weight: 1.0 },
        'ios_dangerous_parental_controls' => { av: :local, ac: :low, pr: :high, ui: :none, scope: :unchanged, c: :high, i: :high, a: :high, owasp_weight: 1.2 },
        'ios_nsuserdefaults_usage' => { av: :local, ac: :low, pr: :low, ui: :none, scope: :unchanged, c: :low, i: :none, a: :none, owasp_weight: 0.9 },
        'ios_exposed_sensitive_file' => { av: :local, ac: :low, pr: :none, ui: :none, scope: :unchanged, c: :high, i: :none, a: :none, owasp_weight: 1.1 },
        'ios_weak_crypto_des_algorithm' => { av: :network, ac: :high, pr: :none, ui: :none, scope: :unchanged, c: :high, i: :none, a: :none, owasp_weight: 1.0 },
        'ios_weak_crypto_rc4_algorithm' => { av: :network, ac: :high, pr: :none, ui: :none, scope: :unchanged, c: :high, i: :none, a: :none, owasp_weight: 1.0 },
        'ios_weak_crypto_md5_hashing' => { av: :network, ac: :high, pr: :none, ui: :none, scope: :unchanged, c: :high, i: :none, a: :none, owasp_weight: 1.0 },
        'ios_weak_crypto_sha1_hashing' => { av: :network, ac: :high, pr: :none, ui: :none, scope: :unchanged, c: :high, i: :none, a: :none, owasp_weight: 1.0 },
        'ios_weak_crypto_ecb_mode' => { av: :network, ac: :high, pr: :none, ui: :none, scope: :unchanged, c: :high, i: :none, a: :none, owasp_weight: 1.0 },
        'ios_binary_weak_crypto_des_algorithm' => { av: :network, ac: :high, pr: :none, ui: :none, scope: :unchanged, c: :high, i: :none, a: :none, owasp_weight: 1.0 },
        'ios_binary_weak_crypto_rc4_algorithm' => { av: :network, ac: :high, pr: :none, ui: :none, scope: :unchanged, c: :high, i: :none, a: :none, owasp_weight: 1.0 },
        'ios_binary_weak_crypto_md5_hashing' => { av: :network, ac: :high, pr: :none, ui: :none, scope: :unchanged, c: :high, i: :none, a: :none, owasp_weight: 1.0 },
        'ios_binary_weak_crypto_sha1_hashing' => { av: :network, ac: :high, pr: :none, ui: :none, scope: :unchanged, c: :high, i: :none, a: :none, owasp_weight: 1.0 },
        'ios_binary_weak_crypto_ecb_mode' => { av: :network, ac: :high, pr: :none, ui: :none, scope: :unchanged, c: :high, i: :none, a: :none, owasp_weight: 1.0 },
        'ios_keychain_ksecattraccessiblealways' => { av: :local, ac: :low, pr: :low, ui: :none, scope: :unchanged, c: :high, i: :none, a: :none, owasp_weight: 1.1 },
        'ios_keychain_ksecattraccessiblealwaysthisdeviceonly' => { av: :local, ac: :low, pr: :low, ui: :none, scope: :unchanged, c: :high, i: :none, a: :none, owasp_weight: 1.1 },
        'ios_hardcoded_basic_auth' => { av: :network, ac: :low, pr: :none, ui: :none, scope: :unchanged, c: :high, i: :low, a: :none, owasp_weight: 1.1 },
        'ios_insecure_lacontext' => { av: :network, ac: :low, pr: :none, ui: :none, scope: :changed, c: :high, i: :high, a: :none, owasp_weight: 1.2 },
        'ios_ats_disabled' => { av: :network, ac: :low, pr: :none, ui: :none, scope: :changed, c: :high, i: :high, a: :none, owasp_weight: 1.3 },
        'ios_ats_media_disabled' => { av: :network, ac: :low, pr: :none, ui: :none, scope: :changed, c: :low, i: :low, a: :none, owasp_weight: 1.0 },
        'ios_ats_webcontent_disabled' => { av: :network, ac: :low, pr: :none, ui: :none, scope: :changed, c: :low, i: :low, a: :none, owasp_weight: 1.0 },
        'ios_ats_exception_allows_insecure_http' => { av: :network, ac: :low, pr: :none, ui: :none, scope: :unchanged, c: :high, i: :low, a: :none, owasp_weight: 1.1 },
        'ios_ats_exception_minimum_tls_version' => { av: :network, ac: :low, pr: :none, ui: :none, scope: :unchanged, c: :high, i: :low, a: :none, owasp_weight: 1.1 },
        'ios_http_url_usage' => { av: :network, ac: :low, pr: :none, ui: :none, scope: :unchanged, c: :high, i: :low, a: :none, owasp_weight: 1.0 },
        'ios_privacy_permission_empty_description' => { av: :network, ac: :low, pr: :none, ui: :none, scope: :unchanged, c: :low, i: :none, a: :none, owasp_weight: 0.8 },
        'ios_pii_location' => { av: :local, ac: :low, pr: :low, ui: :none, scope: :unchanged, c: :low, i: :none, a: :none, owasp_weight: 0.8 },
        'ios_pii_contacts' => { av: :local, ac: :low, pr: :low, ui: :none, scope: :unchanged, c: :low, i: :none, a: :none, owasp_weight: 0.8 },
        'ios_pii_advertising_id' => { av: :local, ac: :low, pr: :low, ui: :none, scope: :unchanged, c: :low, i: :none, a: :none, owasp_weight: 0.8 },
        'ios_pie_disabled' => { av: :local, ac: :high, pr: :low, ui: :none, scope: :changed, c: :high, i: :high, a: :high, owasp_weight: 1.0 },
        'ios_arc_disabled' => { av: :local, ac: :high, pr: :low, ui: :none, scope: :changed, c: :high, i: :high, a: :high, owasp_weight: 1.0 },
        'ios_stack_canary_disabled' => { av: :local, ac: :high, pr: :low, ui: :none, scope: :changed, c: :high, i: :high, a: :high, owasp_weight: 1.0 },
        'ios_binary_not_encrypted' => { av: :local, ac: :low, pr: :none, ui: :none, scope: :unchanged, c: :high, i: :none, a: :none, owasp_weight: 1.0 },
        'ios_jailbreak_detection_missing' => { av: :local, ac: :low, pr: :low, ui: :none, scope: :changed, c: :low, i: :low, a: :none, owasp_weight: 0.8 },
        'ios_tampering_protection_missing' => { av: :local, ac: :low, pr: :low, ui: :none, scope: :changed, c: :low, i: :low, a: :none, owasp_weight: 0.8 },
        'ios_debug_symbols_present' => { av: :local, ac: :low, pr: :none, ui: :none, scope: :unchanged, c: :low, i: :none, a: :none, owasp_weight: 0.7 },
        'ios_symbols_not_stripped' => { av: :local, ac: :low, pr: :none, ui: :none, scope: :unchanged, c: :low, i: :none, a: :none, owasp_weight: 0.7 },
        'ios_anti_debugging_missing' => { av: :local, ac: :low, pr: :low, ui: :none, scope: :changed, c: :low, i: :low, a: :none, owasp_weight: 0.8 },
        'ios_verbose_logging_nslog_usage' => { av: :local, ac: :low, pr: :none, ui: :none, scope: :unchanged, c: :low, i: :none, a: :none, owasp_weight: 0.8 },
        'ios_verbose_logging_swift_print' => { av: :local, ac: :low, pr: :none, ui: :none, scope: :unchanged, c: :low, i: :none, a: :none, owasp_weight: 0.8 },
        'ios_verbose_logging_os_log_usage' => { av: :local, ac: :low, pr: :none, ui: :none, scope: :unchanged, c: :low, i: :none, a: :none, owasp_weight: 0.8 }
      }.freeze

      def self.score(finding_id, custom_vector = nil)
        vector = custom_vector || VULN_VECTORS[finding_id] || default_vector
        base = calculate_base_score(vector)
        hybrid = apply_owasp_weight(base, vector[:owasp_weight] || 1.0)
        {
          base_score:   base.round(1),
          hybrid_score: hybrid.round(1),
          severity:     classify(hybrid),
          vector_string: to_vector_string(vector),
          breakdown: {
            exploitability: calc_exploitability(vector).round(2),
            impact:         calc_impact(vector).round(2)
          }
        }
      end

      def self.score_chain(findings)
        return { chain_score: 0.0, severity: :none } if findings.empty?
        scores = findings.map { |f| score(f['id'] || f[:id])[:hybrid_score] }
        # Chain amplification: each additional vuln adds 15% of its score
        base = scores.max
        amplification = scores.reject { |s| s == base }.sum { |s| s * 0.15 }
        chain = [base + amplification, 10.0].min
        { chain_score: chain.round(1), severity: classify(chain), individual_scores: scores }
      end

      def self.classify(score)
        case score
        when 9.0..10.0 then :critical
        when 7.0...9.0 then :high
        when 4.0...7.0 then :medium
        when 0.1...4.0 then :low
        else :none
        end
      end

      private

      def self.default_vector
        { av: :network, ac: :low, pr: :none, ui: :none,
          scope: :unchanged, c: :low, i: :low, a: :none, owasp_weight: 1.0 }
      end

      def self.calculate_base_score(v)
        exp  = calc_exploitability(v)
        imp  = calc_impact(v)
        return 0.0 if imp.zero?
        scope = v[:scope] || :unchanged
        if scope == :unchanged
          roundup([(imp + exp), 10.0].min)
        else
          roundup([SCOPE_MULT[:changed] * (imp + exp), 10.0].min)
        end
      end

      def self.calc_exploitability(v)
        8.22 *
          (AV_SCORES[v[:av]] || 0.85) *
          (AC_SCORES[v[:ac]] || 0.77) *
          (PR_SCORES[v[:pr]] || 0.85) *
          (UI_SCORES[v[:ui]] || 0.85)
      end

      def self.calc_impact(v)
        isc = 1 - (1 - (C_SCORES[v[:c]] || 0)) *
                  (1 - (I_SCORES[v[:i]] || 0)) *
                  (1 - (A_SCORES[v[:a]] || 0))
        scope = v[:scope] || :unchanged
        if scope == :unchanged
          6.42 * isc
        else
          7.52 * (isc - 0.029) - 3.25 * ((isc - 0.02)**15)
        end
      end

      def self.apply_owasp_weight(base, weight)
        [base * weight, 10.0].min
      end

      def self.roundup(val)
        (val * 10).ceil / 10.0
      end

      def self.to_vector_string(v)
        av_map = { network: 'N', adjacent: 'A', local: 'L', physical: 'P' }
        ac_map = { low: 'L', high: 'H' }
        pr_map = { none: 'N', low: 'L', high: 'H' }
        ui_map = { none: 'N', required: 'R' }
        s_map  = { unchanged: 'U', changed: 'C' }
        c_map  = { none: 'N', low: 'L', high: 'H' }
        "CVSS:3.1/AV:#{av_map[v[:av]]}/AC:#{ac_map[v[:ac]]}/PR:#{pr_map[v[:pr]]}/UI:#{ui_map[v[:ui]]}/S:#{s_map[v[:scope]]}/C:#{c_map[v[:c]]}/I:#{c_map[v[:i]]}/A:#{c_map[v[:a]]}"
      end
    end
  end
end
